﻿﻿/**
 * @fileoverview Namespace 관리 객체.
 */
if (!JsNamespace)
{
	/**
	 * @namespace
	 * @name JsNamespace
	 * @memberof! <global>
	 */
	var JsNamespace = {
		/**
		 * 선언된 namespace cache
		 * @memberOf JsNamespace
		 * @private
		*/
		namespaceCache: {},
		
		/**
		 * 임시로 선언된 namespace cache
		 * @memberOf JsNamespace
		 * @private
		*/
		dummyNamespace: {},
		
		/**
		 * 주어진 name으로 namespace가 정의되어 있는지 확인한다.
		 * @param {string} name namespace 명칭
		 * @return {boolean} namespace 정의여부(true/false)
		 * @example
		 * trace(JsNamespace.exist('NX.Analyzer')); // exist => true
		 * @memberOf JsNamespace		 
		*/
		exist: function(name)
		{
			var pThis = this;
			if (typeof name != 'string')
			{
				throw new Error("100", "[JsNamespace.exist] Invalid name, must be a string");
			}
			var cache = pThis.namespaceCache;
			if (cache.hasOwnProperty(name))
			{
				return true;
			}
			return false;
		},
		
		/**
		 * 생성된 Object를 value로 전달하여 주어진 namespace로 선언한다.
		 * @param {string} name namespace 명칭
		 * @param {object} value namespace 정의
		 * @example
		 * JsNamespace.declare("Hello", {
		 *     'mesage':'Hello nexacro !!', 
		 *     'say': function() {alert(this.message);}
		 * });
		 * Hello.say();
		 * @memberOf JsNamespace		 	 
		*/
		declare: function(name, value)
		{
			if ( !value ) return;

			var pThis = JsNamespace;
			var obj = pThis.getGlobalContext(),
				cache = pThis.namespaceCache,
				dummyCache = pThis.dummyNamespace,
				names = name.split('.'),
				len = names.length - 1,
				leaf = names[len],
				i, nm, fullnm = "";

			for (i = 0; i < len; i++)
			{
				nm = names[i];
				if ( i == 0 ) fullnm += nm;
				else  fullnm += "." + nm;

				if (cache[fullnm])
				{
					obj = cache[fullnm];
				}
				else
				{
					if (!dummyCache[fullnm])
					{
						obj[nm] = {};
						pThis.dummyNamespace[fullnm] = obj[nm];
					}
					obj = obj[nm];
				}
			}
			if ( dummyCache[name] )
			{
				var prop, dummy = dummyCache[name];
				for ( prop in dummy )
				{
					if ( dummy.hasOwnProperty(prop) )
					{
						if ( !value.hasOwnProperty(prop) )
						{
							value[prop] = dummy[prop];
						}
					}
				}
				
				delete dummyCache[name];
				
			}
			
			obj[leaf] = value;
			pThis.namespaceCache[name] = value;

			value._className = name;

			if ( value.prototype !== undefined )
			{
				pThis.setDebugInfo(name, value);
				pThis.setDebugInfo(name, value.prototype, value);
			}
			else
			{
				pThis.setDebugInfo(name, value);
			}
			return obj[leaf];
		},

		/**
		 * 생성된 Object를 value로 전달하여 주어진 namespace 정보로<br>
		 * Object에 종속된 function들의 debug정보를 구성한다.<br><br>
		 * error, log, callstack 처리시에 실행된 function이<br>
		 * 이곳에 정의된 debug정보를 이용하여 출력하게 된다.
		 * @param {string} name
		 * @param {object} value
		 * @example
		 * JsNamespace.setDebugInfo('NX.Analyzer', arrayUtil);
		 * @memberOf JsNamespace	 
		 * @private
		*/
		setDebugInfo: function(name, value, owner)
		{
			if ( !value ) return;
			if ( !owner ) owner = value;
			var nm, type, prop;
			for (nm in value)
			{
				if (value.hasOwnProperty(nm))
				{
					prop = value[nm];
					type = typeof prop;
					if (type == "function")
					{
						if ( !prop._thisName ) prop._thisName = nm;
						if ( !prop._thisOwner ) prop._thisOwner = owner;
					}
				}
			}
		},
		
		/**
		 * global context를 반환하는 함수
		 * @return {Object} global context
		 * @memberOf JsNamespace
		*/
		getGlobalContext: function()
		{
			var context;
			
			if (nexacro.Browser == "Runtime")
			{
				context = _global_context;
			}
			else
			{
				if (window && (window._popup === true))
				{
					context = window;
				}
				else
				{
					context = _global_context;
				}
			}
			
			return context;
		}
		
	}
}

/**
 * @fileoverview NX 관리 객체.
 */
if ( !JsNamespace.exist("NX") )
{
    /**
     * @namespace
     * @name NX
     * @memberof! <global>
     * @author Dong-min Kim <hefaitos@tobesoft.com>
     */
	JsNamespace.declare("NX", {
		
		svrurl			: "",
		svrorigin		: "",
//		svrhost			: "",
		svrport			: "",
		svrpathname		: "",
		hostname		: "",
		
		isruntime		: nexacro.Browser == "Runtime",
		ismdi			: true,	// mainframe을 frameset으로 구성
		
		system			: "", 	// local(로컬), dev(개발), prod(운영)
		systemnm		: "",
		systemid		: "", 	// ANGS
		
		dataType		: 0,	// Default : 0 (0: XML타입, 1: 이진 타입, 2: SSV 타입)
		compress 		: false,
		
		crypto_key		: "",
		crypto_iv		: "",
		
		updatecontrol 	: false,
		rowtype			: "_rowtype",
		
		xpclass 		: null,
		
		// frame layout
		FRAME_VSET		: "",
		FRAME_HSET		: "",
		FRAME_LOGIN		: "",
		
		// additional frame layout(NX.setActiveFrame)
		FRAME_HSET2		: "",
		
		// form layout
		FRAME_MAIN		: "",
		FRAME_TOP		: "",
		FRAME_LEFT		: "",
		FRAME_RIGHT		: "",
		FRAME_BOTTOM	: "",
		FRAME_TAB		: "",
		FRAME_WORK		: "",	// not used in MDI(FRAME_WORKSET)
		
		FORM_MAIN 		: "M", 	// main
		FORM_TAB 		: "S",	// tab
		FORM_DIV 		: "D",	// division
		FORM_POP 		: "P",	// popup
		FORM_WORK 		: "W",	// work
		FORM_FRAME 		: "F",	// frame
		
		TFA_HOST_LIST	: [],
		
		FRAME_WIDTH		: 1916,
		FRAME_HEIGHT	: 925,		
		SYS_LOCAL		: "local",
		SYS_DEV			: "dev",
		SYS_PROD		: "prod",
		
		SYS_ANGS		: "angs",	// for desktop
		SYS_MANGS		: "mangs", 	// for tablet
		SYS_SANGS		: "sangs",	// for single frame
		
		DELIM1			: "^@1@^", // delimiter1
		DELIM2			: "^@2@^", // delimiter2
		DELIM3			: "^@3@^", // for signin
		DELIM_ERR_MSG 	: "|", // delimiter for error message
		
		FORM_URL_DELIM	: "::",		// file separator of url
		FORM_EXTENSION	: ".xfdl",	// form file extension of url
		
		FWD_DBL_SLASH	: "//",
		DEFAULT_SVC_URL	: "./",
		DEFAULT_SVC_GRP	: "svc",	// (*)svc group of typedefintion file
//		LOCAL_SVC_URL 	: "http://localhost.:8150/",
		LOCAL_SVC_URL 	: "http://sw.arex.or.kr/",
		
		FAV_MENU_PREFIX	: "favorite_menu_",
		SVC_PREFIX		: "svc_",

		EXT_COMMON		: null, 		// for runtime
		MSG100 			: "팝업차단 기능이 설정되어있습니다\n\n차단 기능을 해제(팝업허용)하거나 예외처리 후 이용해 주십시오.\n\n팝업차단 기능을 해제 또는 예외처리하지 않을경우 시스템을 정상적으로 사용하실 수 없습니다.",
		
		/**
		 * 오픈일자에 운영서버를 바라보도록 처리해야함(배포서버 사용:changeflow)
		 * 주석제거시 주의 : prod는 실운영서버 프로젝트 오픈일에 맞춰 제거
		 * @private
		 * @return N / A
		 * @example
		 * APPROVAL_WS_URL		: {local:"", dev:"", prod:""}, // http://dev.service.xxxxx.net/service/interface.asmx
         *	APPROVAL_SOAP_URL 	: {local:"", dev:"", prod:""}, // http://cbservice.xxxxx.net/Service/  
		 * @memberOf NX
		 */
		loadNX : function(o)
		{
			// in case popup : NX Library에 설정된 정보손실관련 처리 필요?			
		},
		
		/**
		 * MainFrame화면이 FullScreen 정보 반환
		 * @return FullScreen
		 * @memberOf NX
		 */
		requestFullscreen : function()
		{
			var oEle = document.getElementById("mainframe");
			if (oEle)
			{
				if (oEle.requestFullscreen)
					oEle.requestFullscreen();
				else if (oEle.mozRequestFullScreen)
					oEle.mozRequestFullScreen();
				else if (oEle.webkitRequestFullscreen)
					oEle.webkitRequestFullscreen();
				else if (oEle.msRequestFullscreen)
					oEle.msRequestFullscreen();
			}
		},

		/**
    	 * 브라우저 Out 라인 FullScreen 정보 반환
		 * @return FullScreen
		 * @memberOf NX
		 */
		exitFullscreen : function()
		{
			if (document.exitFullscreen)
				document.exitFullscreen();
			else if (document.mozCancelFullScreen)
				document.mozCancelFullScreen();
			else if (document.webkitExitFullscreen)
				document.webkitExitFullscreen();
			else if (document.msExitFullscreen)
				document.msExitFullscreen();
		},
		
		
		/**
		 * 현재 접속된 디바이스가 모바일인지 여부 반환
		 * @return {boolean} 모바일 : true / 모바일이 아니면 : false
		 * @memberOf NX
		 */ 
		isMobile : function()
		{
			return !nexacro._isDesktop();
		},
		
		/**
		 * application 객체 반환
		 * @return {object} application
		 * @memberOf NX
		 */
		getApp : function()
		{
			return application;
		},
		
		/**
		 * constructor 정보 반환
		 * @param {object} options options.type참조 (service / excel)
		 * @return {object} constructor 타입에 맞는 constructor 반환
		 * @memberOf NX
		 */
		getClass : function(options)
		{
			switch(options.type)
			{
				case "service" :
					this.xpclass = NX.Service.constructor;
					break;
					
				case "excel" :
					this.xpclass = NX.Excel.constructor;
					break;
			}
			return new this.xpclass(options.container);
		},
		
		/**
		 * Excel Object 반환 없으면 생성
		 * @param {object} o form오브젝트
		 * @return {object} excel 오브젝트
		 * @memberOf NX
		 */		
		getExcel : function(o)
		{
			// check whether container obtain NX.Excel
			if (o.__Excel)
				return o.__Excel;
			else
			{
				o.__Excel = new NX.Excel.concrete(o);
				return o.__Excel;
			}
		},
		
		/**
		 * Statusbar 있는지 여부 반환
		 * @return {boolean} Statusbar 있으면 : true / 없으면 : false
		 * @memberOf NX
		 */			
		isStatusbar : function()
		{
			return NX.isFrame() && NX.FRAME_BOTTOM;
		},
		
		/**
		 * Statusbar 있는지 여부 반환
		 * @return {boolean} Statusbar 있으면 : true / 없으면 : false
		 * @memberOf NX
		 */		
		isFrame : function()
		{
			return NX.getApp().gvIsLoadFrame === true;
		},
		
		/**
		 * system구분(로컬 / 개발 / 운영)을 비교한다.
		 * @return {boolean} 비교한시스템이 맞으면 : true / 아니면 : false
		 * @example 
		 * var rtn = NX.is.System("dev");
		 * @memberOf NX
		 */			
		isSystem : function(s)
		{
			return this.system == s;
		},

		/**
		 * 현재 적용된 system구분(로컬 / 개발 / 운영)을 반환한다.
		 * @return {string} 현재 적용된 시스템 구분 
		 * @example 
		 * var rtn = NX.is.System("dev");
		 * @memberOf NX
		 */			
		getSystem : function()
		{
			return this.system;
		},
		
		/**
		 * 적용한 URL기준으로 system구분(로컬 / 개발 / 운영)을 셋팅한다.
		 * @param {string} sUrl 셋팅할려는 URL 정보
		 * @return N / A
		 * @example 
		 * NX.is.System("http://dev.rm.arex.or.kr");
		 * @memberOf NX
		 */				
		setSystem : function(sUrl)
		{
			this.system 	= this.SYS_LOCAL;
			this.systemnm 	= "";
			this.systemid	= this.SYS_ANGS;
			
			if (sUrl.indexOf("sangs.xadl") > 0) // for single_frame
			{
				this.systemid	= this.SYS_SANGS;
			}
			
//			if (sUrl.indexOf("localhost") >= 0 || sUrl.indexOf("127.0.0.1") >= 0)
//			{
//				this.system 	= this.SYS_LOCAL;
//				this.systemnm 	= "로컬";
//			}

			var nDblSlashIdx = sUrl.indexOf(NX.FWD_DBL_SLASH);
			if (nDblSlashIdx >= 0)
			{
				
				if(sUrl.indexOf("/") > -1)
				{
					
					var aUrl = sUrl.split(":");
					
					if(aUrl.length > 2)
					{
						sUrl = sUrl.substring(0, sUrl.lastIndexOf(":"));	
					}
					else
					{
						sUrl = sUrl.substring(0, sUrl.length-1);	
					}
					
					var oApp = NX.getApp();
					
                    var oDs = oApp.gdsSvcUrl;
					
					var sSytem = oDs.lookup("svcUrl",sUrl,"sysCd");

					if(!Util.isNull(sSytem))
					{
						if(sSytem == this.SYS_PROD)
						{
							this.systemnm 	= "운영";
						}
						else
						{
							this.systemnm 	= "개발";
						}
						
						this.system 	=  sSytem;
					}
				
				}
			}
			

			
			/*
			if (sUrl.indexOf("dev.") >= 0)
			{
				this.system 	= this.SYS_DEV;
				this.systemnm 	= "개발";
			}
			else if (sUrl.indexOf("arex.") >= 0)
			{
				this.system 	= this.SYS_PROD;
				this.systemnm 	= "운영";
			}*/
			
			
		},
		
		/**
		 * 현재 적용된 시스템명을 반환한다. 
		 * @param {string} sUrl 셋팅할려는 URL 정보
		 * @return {string} 현재 적용된 시스템명
		 * @example 
		 * var sSystemNm = NX.getSystemNM(); // 개발이면 : 개발 , 운영이면 : 운영 , 로컬이면 : 빈값
		 * @memberOf NX
		 */			
		getSystemNm : function(sType)
		{
			if (this.isSystem(NX.SYS_PROD))
			{
				return "ANGS " + (this.systemnm ? "[" + this.systemnm + "]" : "");
			}
			else
			{
				switch (sType)
				{
					case "full" : 
						return this.systemid + (this.systemnm ? " [" + this.systemnm + "]" : "");
						
					default : 
						return this.systemnm ? "[" + this.systemnm + "]" : "";
				}
			}
		},
		
		/**
		 * 현재 적용된 시스템ID을 반환한다.  ( angs , sangs , mangs)
		 * @param {string} sUrl 셋팅할려는 URL 정보
		 * @return {string} 현재 적용된 시스템명
		 * @example 
		 * var sSystemNm = NX.getSystemNM(); // 개발이면 : 개발 , 운영이면 : 운영 , 로컬이면 : 빈값
		 * @memberOf NX
		 */			
		isSystemId : function(s)
		{
			return this.systemid == s;
		},
		
		/**
		 * 확장 파라미터
		 * @private
		 * @memberOf NX
		 */			
		_getExtraParam : function()
		{
			var oParam, sArgs = NX.getApp().gvArgs;
			// Json처리 -> delimiter 처리고려
			try
			{
				sArgs = decodeURIComponent(sArgs);
				if (sArgs) oParam = JSON.parse(sArgs);
			}
			catch(e){Util.trace("NX.js :: _getExtraParam() => " + e.message);}
			return oParam; 
		},
		
		/**
		 * UI지정 메시지
		 * @private
		 * @memberOf NX
		 */			
		_getUiMsg : function(sCode, aAlterMsg, oCfg)
		{
			var sMsg	= "";
			var oMsgDs	= NX.getApp()._gdsUiMsg;
			if (oMsgDs)
			{
				var nIdx = oMsgDs.findRow("msgId", sCode);
				if (nIdx >= 0)
				{
					sMsg = oMsgDs.getColumn(nIdx, "msgCtnt");
					if (aAlterMsg && !Array.isArray(aAlterMsg)) aAlterMsg = [aAlterMsg];
					if (aAlterMsg instanceof Array)
					{
						sMsg = Util.format(sMsg, aAlterMsg);
					}
				}
			}
			return sMsg;
		},
		
		/**
		 * Form정보를 반환한다.
		 * @param {string} sType 반환하고자 하는 타입에 해당하는 Form정보 반환
		 * @return N / A
		 * @example
		 * oForm = NX.getForm("work");
		 * @memberOf NX
		 */			
		getForm : function(sType)
		{
			if (sType == "work")
			{
				if (NX.ismdi)
				{
					return NX.FRAME_WORK.getActiveFrame() ? NX.FRAME_WORK.getActiveFrame().form : "";
				}
				else
				{
					return NX.FRAME_WORK;
				}
			}
			else
			{
				var oForm = null;
				switch (sType)
				{
					case "main" 	: oForm = NX.ismdi ? NX.FRAME_MAIN.form 	: NX.FRAME_MAIN; 	break;
					case "top" 		: oForm = NX.ismdi ? NX.FRAME_TOP.form 		: NX.FRAME_TOP;		break;
					case "left" 	: oForm = NX.ismdi ? NX.FRAME_LEFT.form 	: NX.FRAME_LEFT;	break;
					case "bottom" 	: oForm = NX.ismdi ? NX.FRAME_BOTTOM.form	: NX.FRAME_BOTTOM;	break;
				}
				return oForm && oForm.fvFormType ? oForm : null;
			}
		},
		
		/**
		 * 컴포넌트를 기준으로 해당컴포넌트가 속해 있는 Form정보를 반환한다.
		 * @param {object} c 컴포넌트
		 * @return N / A
		 * @example
		 * oForm = NX.getScriptForm(this.cal_month);
		 * @memberOf NX
		 */			
		getScriptForm: function(c)
		{
			var p = c;
			while (p)
			{
				if ( (p.url && p.url.length) || (p.parent instanceof ChildFrame) )
				{
					break;
				}
				p = p.parent;
			}
			return p;
		},	
		
		/**
		 * Service Url 반환
		 * @param {strng} sType 반환하고자 하는 타입 (editor,excel,file,http)
		 * @return {string} 서비스경로
		 * @example
		 * sSvcUrl = NX.getSvcUrl();
		 * @memberOf NX
		 */			
		getSvcUrl : function(sType)
		{
			switch (sType)
			{
				case "editor" : 
				case "excel" : 
				case "file" : 
					return NX.svrorigin;
				case "http"	: 
					return "http://" + NX.hostname + ":60000" + NX.svrpathname.substring(0, NX.svrpathname.lastIndexOf("/"));
				default		: 
					return NX.svrurl;
			}
		},
		
		/**
		 * Service Url 셋팅 접속한 Url을 기준으로 서비스 경로 자동 셋팅
		 * @return N / A
		 * @example
		 * NX.setSvrUrl();
		 * @memberOf NX
		 */			
		setSvrUrl : function()
		{
			if (!NX.svrurl)
			{
				if (NX.isruntime)
				{
					// TO DO. for runtime environment : NX.getApp().services["svc"] is "undefined" 
					var sHref 	= (nexacro.OS == "Android") ? NX.LOCAL_SVC_URL : NX.getApp().xadl;
					
					this.setSystem(sHref);
				}
				else
				{
					if (window.CryptoJS)
					{
						NX.crypto_key 	= CryptoJS.enc.Utf8.parse("TOBESOFT12345678");
						NX.crypto_iv	= CryptoJS.enc.Utf8.parse('1234567812345678');
					}
					
					try
					{
						var sHref 	= document.location.href;
						var nIdx 	= sHref.lastIndexOf("/");
									
						NX.svrport		= document.location.port;
						NX.svrpathname	= document.location.pathname;
						NX.svrurl 		= sHref.substring(0, nIdx);
						NX.svrorigin 	= document.location.origin || document.location.protocol + NX.FWD_DBL_SLASH + document.location.host;
						NX.svrhost		= document.location.host;
						NX.hostname 	= document.location.hostname;
						
						// define chart handler <- document에 정의한 후에 ADL에서 활성화form을 호출
						window._rMateChartReadyHandler = function(sChartId)
						{
							// 팝업화면 및 동일화면 오픈시 테스트 필요
							var oForm = NX.Comps._getChartForm(sChartId);
							if (oForm && oForm.fn_chartReadyHandler)
							{
								oForm.fn_chartReadyHandler(sChartId);
							}
						}
						
						window._rMate_dataTipJsFunction = function(sSeriesId, sSeriesName, nIndex, sXName, sYName, sData, sValues)
						{
							var sChartId = window._rMate_dataTipJsFunction.caller.arguments[0].chartItem.element.parentElement.id;
							var sFuncNm = "fn_dataTipJsFunction";
							// 팝업화면 및 동일화면 오픈시 테스트 필요
							var oForm = NX.Comps._getChartForm(sChartId);
							if (oForm && oForm[sFuncNm])
							{
								return oForm[sFuncNm](sChartId.substr(sChartId.lastIndexOf("_")+1), sSeriesId, sSeriesName, nIndex, sXName, sYName, sData, sValues);
							}
							
							return;
						}
						
						this.setSystem(sHref);
					}
					catch(e)
					{
						window.console.log("NX.xjs :: setSvrUrl() => " + e.message);
					}
					finally
					{
					}
					
					console.log("SVR URL : " + NX.svrurl + 
							"\r\nSVR ORIGIN : " + NX.svrorigin + 
//							"\r\nSVR HOST : " + NX.svrhost +
							"\r\nSVR PORT : " + NX.svrport + 
							"\r\nSVR PATHNAME : " + NX.svrpathname + 
							"\r\nSVR Hostname : " + NX.hostname + 
							"\r\nReferer : " + NX.getApp().gvReferer);
					
				}
			}
		},
		
		/**
		 * Service Url 셋팅 접속한 Url을 기준으로 서비스 경로 자동 셋팅
		 * @private
		 * @memberOf NX
		 */			
		_getSvcGrp : function(sSvrUrl)
		{
			// remove protocol & mobile domain(m.)
			var nDblSlashIdx = sSvrUrl.indexOf(NX.FWD_DBL_SLASH);
			if (nDblSlashIdx >= 0)
			{
				
				sSvrUrl = sSvrUrl.substring(nDblSlashIdx+2, sSvrUrl.length);
				if(sSvrUrl.indexOf("/") > -1)
				{
					sSvrUrl = sSvrUrl.substring(0, sSvrUrl.lastIndexOf("/"));	
				}
			}
			
			var aUrlGrp = sSvrUrl.split(".");
			var sUrlGrp = NX.isSystem(this.SYS_PROD) ? aUrlGrp[0] : aUrlGrp[1]; // 개발계 및 테스트계(http://dev.rm.arex.com) 1, 운영계(http://rm.arex.com) 0
			return sUrlGrp;
		},
		
		/**
		 * Service Url 셋팅 접속한 Url을 기준으로 서비스 경로 자동 셋팅
		 * @private
		 * @memberOf NX
		 */			
		_setDefaultSvcUrl : function()
		{
			NX.setSvrUrl();
			var oApp = NX.getApp();
			var sSvrUrl	= oApp.services[NX.DEFAULT_SVC_GRP].url;
			if (!NX.isFrame() && sSvrUrl == NX.DEFAULT_SVC_URL)
			{
				if (NX.isruntime)
				{
					sSvrUrl 		= NX.LOCAL_SVC_URL;
					
					var nSlashIdx	= sSvrUrl.indexOf(NX.FWD_DBL_SLASH)+2;
					var nPortIdx	= sSvrUrl.indexOf("/", nSlashIdx);
					
					NX.svrurl 		= sSvrUrl.substring(0, sSvrUrl.lastIndexOf("/"));
					NX.svrorigin 	= sSvrUrl.substring(0, nPortIdx);
//					NX.svrhost		= sSvrUrl.substring(nSlashIdx, nPortIdx); // different webpage(include port)
				}
				
				oApp.services[NX.DEFAULT_SVC_GRP].set_url(NX.svrorigin);
							   
			
				// redefine service group URL
				if (!NX.isSystem("local"))
				{
					var nSvcIndex, oDs = oApp.gdsSvcUrl;
					
					// 1.Url redefine to service group of biz 
					sSvrUrl = NX.svrurl; // http://rm.arex.com/angs
					
					var sUrl, sSvcUrl, sPrefixId, sPrefix = "", sDelimUrl = "./rbs/biz/";
					var sUrlGrp 	= NX._getSvcGrp(sSvrUrl);
					var sSvcPath 	= NX.svrpathname.substring(0, NX.svrpathname.lastIndexOf("/")); // "/angs"
					
		                    
                    if(Util.isNull(sSvcPath)) sSvcPath = "/angs";
                    
					/* smart업무 고려필요 http://m.dev.rm.arex.com, http://m.rm.arex.com ?
					 * 해당기분은 port가 다를경우 row단위 관리가 용이할 수 도 있음
					 * row단위가 아닌경우 url, port컬럼을 smart용을 추가하고 컬럼명을 변수로 관리
					 */					
					//alert("Connect System : " + sUrlGrp + " (" + sSvrUrl + ")");
					
					oDs.filter("sysCd=='" + NX.system + "'");

					for (var i=0, nCnt=oApp.services.length; i<nCnt; i++)
					{
						sUrl = oApp.services[i].url;
						sPrefixId = oApp.services[i].prefixid;
						
						if (sUrl.indexOf(sDelimUrl) >= 0 && (oApp.services[i].type == "form" || oApp.services[i].type == "js"))
						{
							sPrefix = (oApp.services[i].type == "form") ? sUrl.substr(sDelimUrl.length, 2) : sPrefixId.replace("lib_","");
							
							if (sPrefix != sUrlGrp) // 서브코드와 중복될경우 자리수 체크
							{
								nSvcIndex = oDs.findRow("svcGrp", sPrefix);
//								nSvcIndex = oDs.findRowExpr("sysCd=='" + NX.system + "' && svcGrp=='" + sPrefix + "'");
								if (nSvcIndex >= 0)
								{						
									sSvcUrl = Util.trim(oDs.getColumn(nSvcIndex, "svcUrl")) + ":" + Util.trim(oDs.getColumn(nSvcIndex, "svcPort")) + sSvcPath + sUrl.substr(1);
									oApp.services[i].set_url(sSvcUrl);
								}
								else
								{
									Util.trace("NX._setDefaultSvcUrl() :: not found service group => " + sPrefix + " / " + sUrl);
								}
							}
							
							Util.trace("(" + i + ") " + sPrefix + " : " + oApp.services[i].url);
						}
					}
					
					// 2.service group of [JSP]type create
					for (var i=0, nCnt=oDs.rowcount; i<nCnt; i++)
					{
						sPrefix = Util.trim(oDs.getColumn(i, "svcGrp"));
						sUrl =Util.trim(oDs.getColumn(i, "svcUrl")) + ":" + Util.trim(oDs.getColumn(i, "svcPort"));
						
						if (sPrefix && sUrl)
						{
							sPrefix = NX.SVC_PREFIX + sPrefix;
//							nexacro.ServiceItem = function (prefixid, type, url, cachelevel, codepage, language, version, communicationversion)
							nSvcIndex = oApp.services.add(sPrefix, new nexacro.ServiceItem(sPrefix, "JSP", sUrl, "none", null, "", 0, "0"));
							if (nSvcIndex < 0)
							{
								Util.trace("NX._setDefaultSvcUrl() :: cannot create service group => " + sPrefix + " / " + sUrl);
							}
						}
					}					
				}
				
				trace("Default Service URL : " + oApp.services[NX.DEFAULT_SVC_GRP].url);

			}
		},
		
		/**
		 * commonloader의 로딩조건체크후 boolean값 반환(class 개발시)
		 * @private
		 * @return {Boolean} 반환값
		 * @example
		 * trace(NX.applyloader()); // output : true
		 * 
		 * @memberOf NX
		 */
		_applyloader : function()
		{
			return true;
		},
		
		/**
		 * 브라우져 localStorage에 값을 저장
		 * @param {string} sKey 로컬 스토리지에 저장할 키
		 * @param {string} sVal 로컬 스토리지에 저장할 값
		 * @return N / A
		 * @example
		 * NX.setLocalItem("test","테스트데이터");
		 * @memberOf NX
		 */			
		setLocalItem : function(sKey, sVal)
		{
			var nCnt = 0, i, j;
			while(1)
			{
				try
				{
					if (!nCnt) window.localStorage.setItem(sKey, sVal);
					else
					{
						window.localStorage.setItem(sKey, "--" + nCnt);
						j = Math.ceil(sVal / nCnt); // length 체크
						for (i=0; i<nCnt; i++)
						{
							window.localStorage.setItem(sKey+"::"+i, sVal.substr(i*j, j));
						}
					}
					break;
				}
				catch(e)
				{
					nCnt++;
				}
			}
		},
		
		/**
		 * 브라우져 localStorage에 저장된 값을 가져온다.
		 * @param {string} sKey 로컬 스토리지에 저장된 키
		 * @return {string} 로컬 스토리지에 저장된 키를 기준으로 적용된 값 반환
		 * @example
		 * var sVal = NX.getLocalItem("test");
		 * @memberOf NX
		 */				
		getLocalItem : function(sKey)
		{
			var sData = Util.trim(window.localStorage.getItem(sKey)), sTemp, i, j;
			if (sData && sData.substr(0, 2) == "--")
			{
				for (sTemp="", i=0, j=parseInt(sData.substr(2)); i<j; i++)
				{
					sTemp += window.localStorage.getItem(sKey+"::"+i);
				}
				sData = sTemp;
			}
			return sData;
		},
		
		/**
		 * 브라우져 localStorage에 저장된 값을 삭제한다.
		 * @param {string} sKey 로컬 스토리지에 저장된 키
		 * @return N / A
		 * @example
		 *   NX.removeLocalItem("test");
		 * @memberOf NX
		 */			
		removeLocalItem : function(sKey)
		{
			var sData = Util.trim(window.localStorage.getItem(sKey)), i, j; 
			if (sData && sData.substr(0, 2) == "--")
			{
				for (i=0, j=parseInt(sData.substr(2)); i<j; i++)
				{
					window.localStorage.removeItem(sKey + "::" + i);
				}
			}
			window.localStorage.removeItem(sKey);
		},
		
		/**
		 * 브라우져 sessionStorage 값을 저장
		 * @param {string} sKey 로컬 스토리지에 저장할 키
		 * @param {string} sVal 로컬 스토리지에 저장할 값
		 * @return N / A
		 * @example
		 * NX.setSessionItem("test","테스트데이터");
		 * @memberOf NX
		 */			
		setSessionItem : function(sKey, sVal)
		{
			var nCnt = 0, i, j;
			while(1)
			{
				try
				{
					if (!nCnt) window.sessionStorage.setItem(sKey, sVal);
					else
					{
						window.sessionStorage.setItem(sKey, "--" + nCnt);
						j = Math.ceil(sVal / nCnt); // length 체크
						for (i=0; i<nCnt; i++)
						{
							window.sessionStorage.setItem(sKey+"::"+i, sVal.substr(i*j, j));
						}
					}
					break;
				}
				catch(e)
				{
					nCnt++;
				}
			}
		},
		
		/**
		 * 브라우져 getSessionItem 저장된 값을 가져온다.
		 * @param {string} sKey 로컬 스토리지에 저장된 키
		 * @return {string} 로컬 스토리지에 저장된 키를 기준으로 적용된 값 반환
		 * @example
		 * var sVal = NX.getSessionItem("test");
		 * @memberOf NX
		 */		
		getSessionItem : function(sKey)
		{
			var sData = Util.trim(window.sessionStorage.getItem(sKey)), sTemp, i, j;
			if (sData && sData.substr(0, 2) == "--")
			{
				for (sTemp="", i=0, j=parseInt(sData.substr(2)); i<j; i++)
				{
					sTemp += window.sessionStorage.getItem(sKey+"::"+i);
				}
				sData = sTemp;
			}
			return sData;
		},
		
		/**
		 * 브라우져 sessionStorage 저장된 값을 삭제한다.
		 * @param {string} sKey 로컬 스토리지에 저장된 키
		 * @return N / A
		 * @example
		 *   NX.removeSessionItem("test");
		 * @memberOf NX
		 */			
		removeSessionItem : function(sKey)
		{
			var sData = Util.trim(window.sessionStorage.getItem(sKey)), i, j; 
			if (sData && sData.substr(0, 2) == "--")
			{
				for (i=0, j=parseInt(sData.substr(2)); i<j; i++)
				{
					window.sessionStorage.removeItem(sKey + "::" + i);
				}
			}
			window.sessionStorage.removeItem(sKey);
		},
		
		/**
		 * ItemKey키를 반환한다.
		 * @private
		 * @memberOf NX
		 */			
		getItemKey : function(sKey)
		{
			return NX.getApp().key + NX.getApp().xadl + sKey;
		},
		
		/**
		 * getSerializeData를 반환한다.
		 * @private
		 * @memberOf NX
		 */			
		getSerializeData : function(o)
		{
			var sRtnStr = "";
			for (sProp in o) sRtnStr += sProp + NX.DELIM2 + Util.trim(o[sProp]) + NX.DELIM1;
			return sRtnStr;
		},
		
		/**
		 * prefix기준으로 사용하는 시퀀스를 반환한다.
		 * @param {object} form 적용기준 Form
		 * @param {string} prefix 프리픽스 문자열
		 * @return {number} prefix기준으로 한 시퀀스
		 * @example
		 *   var nSeq = NX.getSequenceId(this,"sample");
		 * @memberOf NX
		 */				
		getSequenceId: function(form, prefix)
		{
			
			var cache = form._sequenceIdCache;
			if ( Util.isNull(cache) )
			{
				cache = form._sequenceIdCache = {};
			}
			
			var sequence = cache[prefix];
			if (  Util.isNull(sequence) )
			{
				sequence = -1;
			}
			sequence++;
			
			cache[prefix] = sequence;
			
			return prefix + sequence;
		},
		
		/**
		 * uniqueId를 반환한다. (unique적용 아이디 + 적용할Form네임)
		 * @param {string} sName unique하게 적용할 키
		 * @param {object} form 적용기준 Form
		 * @return {string} 생성된 UniqueId
		 * @example
		 *   var sKey = NX.getUniqueId("sample",this);
		 * @memberOf NX
		 */			
		getUniqueId : function(sName, o)
		{
			return sName + o.name
		},
		
		/**
		 * Frame Width 사이즈를 반환한다.
		 * @param {string} sType sType top 또는 널값
		 * @return {number} prefix기준으로 한 시퀀스
		 * @example
		 *   var nFrmaeWidth = NX.getFrameWidth();
		 * @memberOf NX
		 */				
		getFrameWidth : function(sType)
		{
			switch (sType)
			{
				case "top" 	: return NX.FRAME_WIDTH - 50; 	break;
				default 	: return NX.FRAME_WIDTH;		break;			
			}			
		},
		
		/**
		 * Frame Height 사이즈를 반환한다.
		 * @param {string} sType sType top 또는 널값
		 * @return {number} prefix기준으로 한 시퀀스
		 * @example
		 *   var nFrmaeHeight = NX.getFrameHeight();
		 * @memberOf NX
		 */			
		getFrameHeight : function(sType)
		{
			switch (sType)
			{
				case "top" 	: return 50;				break;
				default		: return NX.FRAME_HEIGHT;	break; 
			}
		},
		
		// PopupDiv컴포넌트 호출후에 closePopup()함수가 sync로 동작하여 click이벤트가 마지막에 동작되는 부분관련 focus처리를 위해 사용
		// 메뉴호출하는 PopupDiv위에서 click이벤트에서 사용
		/**
		 * Frame Height 사이즈를 반환한다.
		 * @private
		 * @memberOf NX
		 */			
		setFocus : function(sFrame)
		{
			switch(sFrame)
			{
				case "work" :
					var oActiveFrame = NX.FRAME_WORK.getActiveFrame();
					if (oActiveFrame)
					{
						oActiveFrame.setFocus();
					}
					break;
			}
		},
		
		/**
		 * isActiveFrame (내부사용)
		 * @private
		 * @memberOf NX
		 */				
		isActiveFrame : function(sType)
		{
//			return sType == "mainform" ? NX.FRAME_HSET2.separatesize == "15,0,*" : NX.FRAME_HSET2.separatesize == "15,*,0"; 
			return sType == "mainform" ? NX.FRAME_HSET2.separatesize == "0,*" : NX.FRAME_HSET2.separatesize == "*,0";
		},
		
		/**
		 * isActiveSignin  (내부사용)
		 * @private
		 * @memberOf NX
		 */			
		isActiveSignin : function()
		{
			return NX.FRAME_HSET.separatesize == "*,0";
		},
		
		/**
		 * changeFrame  (내부사용)
		 * @private
		 * @memberOf NX
		 */				
		changeFrame : function()
		{
			if (NX.isMobile()) NX.FRAME_VSET.set_separatesize("0,50,*,30");
		},
		
		/**
		 * setLayout  (내부사용)
		 * @private
		 * @memberOf NX
		 */			
		setLayout : function()
		{
			Util.trace("setLayout !!!!!!!!!!!!!!!!!!!!!!");
			try
			{
				var oApp = NX.getApp();
				Util.trace("oApp.id :: " + oApp.id);
				Util.trace("oApp.mainframe.HFrameSet :: " + oApp.mainframe.HFrameSet);
				switch (oApp.id)
				{
					case NX.SYS_ANGS : 
						NX.FRAME_VSET		= oApp.mainframe.HFrameSet.VFrameSet;
						NX.FRAME_HSET		= oApp.mainframe.HFrameSet;
						NX.FRAME_LOGIN		= oApp.mainframe.HFrameSet.LoginFrame;			
						NX.FRAME_TOP		= oApp.mainframe.HFrameSet.VFrameSet.TopFrame;
						NX.FRAME_TAB		= oApp.mainframe.HFrameSet.VFrameSet.TabFrame;
						NX.FRAME_BOTTOM		= oApp.mainframe.HFrameSet.VFrameSet.BottomFrame;
						NX.FRAME_HSET2		= oApp.mainframe.HFrameSet.VFrameSet.HFrameSet2;
						NX.FRAME_WORK		= oApp.mainframe.HFrameSet.VFrameSet.HFrameSet2.FrameSet;
						NX.FRAME_VSET		= oApp.mainframe.HFrameSet.VFrameSet;
						break;
						
					case NX.SYS_MANGS :  
						NX.FRAME_HSET		= oApp.mainframe.HFrameSet;
						NX.FRAME_LOGIN		= oApp.mainframe.HFrameSet.LoginFrame;			
						NX.FRAME_TOP		= oApp.mainframe.HFrameSet.VFrameSet.TopFrame;
						NX.FRAME_WORK		= oApp.mainframe.HFrameSet.VFrameSet.WorkFrame;
						break;
						
					case NX.SYS_SANGS :
						NX.FRAME_WORK		= oApp.mainframe.WorkFrame;
						break;
				}
			}
			catch(e)
			{
				Util.trace("NX.js :: setLayout() Exception => " + e.message);
			}
		},
		
		/**
		 * setActiveFrame  (내부사용)
		 * @private
		 * @memberOf NX
		 */			
		setActiveFrame : function(sType)
		{
			switch (sType)
			{
				case "loginsucc" :
					NX.FRAME_HSET.set_separatesize("0,*");
					break;
				
				case "loginform" :
					NX.FRAME_HSET.set_separatesize("*,0");
					break;
			}
		}
	});
	
	
}
