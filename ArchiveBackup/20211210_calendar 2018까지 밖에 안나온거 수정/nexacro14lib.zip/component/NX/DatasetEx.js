﻿/**
 * @fileoverview Dataset관련 확장 공통함수.
 */
 
if (!JsNamespace.exist("DatasetEx"))
{
	/**
	 * @namespace
	 * @name DatasetEx
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("DatasetEx", {
		/**
		 * 체크박스컬럼(삭제용)
		 * @private
		 * @type string
		 * @memberOf DatasetEx
		 */
		_CHECKBOX_COLUMN : "_chk",

		/**
		 * Row상태컬럼
		 * @private
		 * @type string
		 * @memberOf DatasetEx
		 */
		_ROWTYPE_COLUMN : "_rowtype",

		/**
		 * Row상태 (정상)
		 * @public
		 * @type string
		 * @memberOf DatasetEx
		 */
		ROWTYPE_NORMAL : "", // "N" or "" or undefined(update to emptystring)
		/**
		 * Row상태 (신규)
		 * @public
		 * @type string
		 * @memberOf DatasetEx
		 */
		ROWTYPE_INSERT : "C",
		/**
		 * Row상태 (수정)
		 * @public
		 * @type string
		 * @memberOf DatasetEx
		 */
		ROWTYPE_UPDATE : "U",
		/**
		 * Row상태 (삭제)
		 * @public
		 * @type string
		 * @memberOf DatasetEx
		 */
		ROWTYPE_DELETE : "D"
	});

	/**
	 * Dataset Row상태의 이미지반환
	 * @param  {String} sRowType	Row상태문자
	 * @return n/a
	 * @example DatasetEx.getStatusImg("U");
	 */
	DatasetEx.getStatusImg = function(sRowType)
	{
		var sStatusImg = "";
		switch (sRowType)
		{
			case this.ROWTYPE_INSERT : sStatusImg = "URL('img::grd_Flg02.png')"; 	break;
			case this.ROWTYPE_UPDATE : sStatusImg = "URL('img::grd_Flg01.png')"; 	break;
			case this.ROWTYPE_DELETE : sStatusImg = "URL('img::grd_Flg03.png')"; 	break;
		}
		return sStatusImg;
	}

	/**
	 * Dataset Row상태갱신을 하는 공통이벤트 등록함수
	 * @param  {Object} pThis	Form
	 * @param  {Object} aDsLst	Dataset배열
	 * @return n/a
	 * @example DatasetEx.updateControl([dsList1, dsList2]);
	 */
	DatasetEx.updateControl = function(aDsLst, pThis)
	{
		var oDs, aDsLst = Array.isArray(aDsLst) ? aDsLst : [aDsLst];
		for (var i=0, nLen=aDsLst.length; i<nLen; i++)
		{
			oDs = aDsLst[i];
			if (oDs && oDs instanceof Dataset)
			{
				pThis = pThis || oDs.parent;
				oDs._autoupdate 	= true;
				this._checkRowType(oDs);

				oDs.addEventHandler("oncolumnchanged", DatasetEx._common_dataset_oncolumnchanged, pThis); // check for binding grid component
			}
			else
			{
				Util.trace("DatasetEx.xjs :: updateControl() Not found dataset => " + oDs);
			}
		}
	},

	/**
	 * Dataset Row상태갱신을 하는 공통이벤트 처리
	 * @private
	 * @return n/a
	 * @example DatasetEx._common_dataset_oncolumnchanged(obj, e);
	 */
	DatasetEx._common_dataset_oncolumnchanged = function(obj, e)
	{
		if (Util.trim(e.columnid).left(1) != "_")
		{
			var nRowType = DatasetEx.getRowType(obj, e.row);
			switch (nRowType)
			{
				case Dataset.ROWTYPE_NORMAL :
					obj.setColumn(e.row, NX.rowtype, DatasetEx.ROWTYPE_UPDATE);
					break;

				case Dataset.ROWTYPE_UPDATE :
					
					var newVal = e.newvalue;
					var newOrgVal = obj.getOrgColumn(e.row, e.columnid);
					
					newVal = (Util.isNull(newVal)) ? "" : newVal.toString();
					newOrgVal = (Util.isNull(newOrgVal)) ? "" : newOrgVal.toString();

					if (newVal == newOrgVal)
					{
						var bModified = false;
						for (var i=0, nColCnt=obj.colcount, sColId = ""; i<nColCnt; i++)
						{
							sColId = Util.trim(obj.getColID(i));
														
							if (sColId != e.columnid && sColId.indexOf("_") != 0)
							{
								var val = obj.getColumn(e.row, sColId);
								var orgVal = obj.getOrgColumn(e.row, sColId);
								
								val = (Util.isNull(val)) ? "" : val.toString();
								orgVal = (Util.isNull(orgVal)) ? "" : orgVal.toString();
								
								if (val != orgVal)
								{									
									bModified = true;
									break;
								}
							}
						}

						// rowtype이 "2"인경우 제외처리(for copy) : && !(obj.getRowType(e.row) == Dataset.Dataset.ROWTYPE_INSERT)
						if (!bModified)
						{
							obj.setColumn(e.row, NX.rowtype, DatasetEx.ROWTYPE_NORMAL);
						}
					}
					break;

				case Dataset.ROWTYPE_INSERT :
				case Dataset.ROWTYPE_DELETE :
					break;
			}
		}
	}

//	/**
//	 * NextKey방식의 output dataset의 조회건수를 설정위한 속성지정
//	 * @param  {Object} oDs	Dataset
//	 * @param  {Object} oGrid	조회건수를 표시할 Grid(Static컴포넌트를 검색시 사용)
//	 * @return n/a
//	 * @example nxDatset.bindGrid(this.dsListPage, this.grdList);
//	 */
//	DatasetEx.bindGrid = function(oDs, oGrid)
//	{
//		oDs.appendgrid = oGrid;
//	}

	/**
	 * Dataset _rowtype컬럼체크하여 컬럼추가(개발자사용금지)
	 * @private
	 * @param  {Object} oDs	: Dataset
	 * @return n/a
	 * @example nxDatset._checkRowType(this.dsList1);
	 */
	DatasetEx._checkRowType = function(oDs)
	{
		if (!NX.updatecontrol)
		{
			// NX.rowtype 컬럼확인
			if (!oDs.getColumnInfo(NX.rowtype))
			{
				oDs.set_enableevent(false);
				oDs.addColumn(NX.rowtype, "string");
				oDs.set_enableevent(true);
			}

			// 2017.12.11 공통팀요청으로 추가
			if (!oDs.getColumnInfo("_userId"))
			{
				oDs.set_enableevent(false);
				oDs.addColumn("_userId", "string");
				oDs.addColumn("_userIp", "string");
				oDs.set_enableevent(true);
			}
		}
	}

	/**
	 * Dataset에 filterstr 설정
	 * @param {Dataset} oDs	Dataset Object
	 * @param {String} sFilter	filter식
	 * @param {Boolean} bCurrent	지정속성(current, default)
	 * @return N/A
	 * @example DatasetEx.setFilter(oDs, "Column0='Column1'")
	 * @memberOf DatasetEx
	 */
	DatasetEx.setFilter = function(oDs, sFilter, bCurrent)
	{
		if (Util.isNull(bCurrent)) bCurrent = true;

		if (bCurrent)
		{
			oDs.filterstr_current = sFilter;
		}
		else
		{
			oDs.filterstr_default = sFilter;
			oDs.filterstr_current = sFilter;
		}
		oDs.set_filterstr(sFilter);
	}

	/**
	 * Dataset에 filterstr 설정
	 * @param {Dataset} oDs	Dataset Object
	 * @param {Boolean} bCurrent	지정속성(current, default)
	 * @return {String} filter식
	 * @example DatasetEx.getFilter(oDs)
	 * @memberOf DatasetEx
	 */
	DatasetEx.getFilter = function(oDs, bCurrent)
	{
		if (Util.isNull(bCurrent)) bCurrent = true;

		return Util.trim(bCurrent ? oDs.filterstr_current : oDs.filterstr_default);
	}

	/**
	 * Dataset에 keystring 설정
	 * @param {Dataset} oDs	Dataset Object
	 * @param {String} sKeystr	keystring식
	 * @param {Boolean} bCurrent 지정속성(current, default)
	 * @return N/A
	 * @example DatasetEx.setKeystr(oDs, "S:Column0,Column1")
	 * @memberOf DatasetEx
	 */
	DatasetEx.setKeystr = function(oDs, sKeystr, bCurrent)
	{
		if (Util.isNull(bCurrent)) bCurrent = true;

		if (bCurrent)
		{
			oDs.keystring_current = sKeystr;
		}
		else
		{
			oDs.keystring_default = sKeystr;
			oDs.keystring_current = sKeystr;
		}
		oDs.set_keystring(sKeystr);
	}

	/**
	 * Dataset에 keystring 설정
	 * @param {Dataset} oDs	Dataset Object
	 * @param {Boolean} bCurrent	지정속성(current, default)
	 * @return {String} keystring값
	 * @example DatasetEx.getKeystr(oDs)
	 * @memberOf DatasetEx
	 */
	DatasetEx.getKeystr = function(oDs, bCurrent)
	{
		if (Util.isNull(bCurrent)) bCurrent = true;

		return Util.trim(bCurrent ? oDs.keystring_current : oDs.keystring_default);
	}

	/**
	 * Dataset의 특정 컬럼의 중복을 제거(문자열 기준으로 비교)
	 * @param {Dataset} oDs	Dataset Object
	 * @param {String} sColId	Column List (여러 항목일 경우 ',' 로 구분)
	 * @param {Boolean} bCreate	중복제거결과를 Dataset으로 반환 (default : false)
	 * @return {Dataset} distinct data
	 * @example DatasetEx.distinctDs(oDs, "Column0,Column1")
	 * @memberOf DatasetEx
	 */
	DatasetEx.distinctDs = function(oDs, sColId)
	{
		var aColumns	= Util.trim(sColId).split(",");
		var sFilterExpr	= "";
		var sFindRowExpr= "";

		for (var i=0, nLength=aColumns.length; i<nLength; i++)
		{
			if (!oDs.getColumnInfo(aColumns[i])) continue;

			sFindRowExpr	+= !Util.isNull(sFindRowExpr) ? " && " : "";
			sFindRowExpr	+= "String(" + aColumns[i] + ")=='\" + " + aColumns[i] + " + \"'";
		}

		if (sFindRowExpr) sFilterExpr = "rowidx==dataset.findRowExpr(\"" + sFindRowExpr + "\")";

		oDs.set_enableevent(false);
		oDs.filter(sFilterExpr);
		var oTempDs = DatasetEx._get("_distinctDs_" + oDs.name, oDs.parent);
			oTempDs.clearData();
			oTempDs.copyData(oDs, true);
		oDs.filter("");
		oDs.set_enableevent(true);

		return oTempDs;
	}

	/**
	 * Dataset의 Null값이 아닌 중복된 Row를 반환
	 * @param {Dataset} oDs	중복체크하려는 Dataset
	 * @param {String} sColList	Key Column List(콤마로구분)
	 * @param {String} sCheckboxColId	체크박스 컬럼명(선택 : 설정시 해당체크박스)
	 * @return {Array} 중복 시 중복체크한 Row와 중복된 첫번째 Row (Array length 는 2)
	 *                 중복이 없으면 length가 0인 Array를 반환함
	 * @example DatasetEx.getDuplicateRow(ds_List, "Column0,Column1", sCheckboxColId)
	 * @memberOf DatasetEx
	 */
	DatasetEx.getDuplicateRow = function(oDs, sColList, sCheckboxColId)
	{
		var aColID 		= sColList.split(',');
		var aDupRow		= new Array();
		var bCheckCol 	= Util.isNull(sCheckboxColId) ? false : true;
        var sData       = "";
		// 마지막 Row는 체크할 필요가 없음.
		for (var i=0, nCnt=oDs.getRowCount()-1; i<nCnt; i++)
		{
			sData = "";
			if (bCheckCol)
			{
				var sValue = Util.trim(oDs.getColumn(i, sCheckboxColId));
				if (Util.isNull(sValue) || sValue == "0") continue;
			}

			var sExpr = "1==1";

			for (var j=0, nLen=aColID.length; j<nLen; j++)
			{
				 sExpr += Util.isNull( sExpr) ? "" : " && ";
				 sData = oDs.getColumn(i, aColID[j]);
				 if(Util.isNull(sData)) continue;
				 sExpr += aColID[j] + "=='" + sData + "'";
			}

			if (bCheckCol) sExpr += " && " + sCheckboxColId + " != '0'";

			var nRow = oDs.findRowExpr(sExpr, i+1);

			if (nRow >= 0)
			{
				aDupRow[aDupRow.length]	= i;
				aDupRow[aDupRow.length]	= nRow;
			}
		}

		return aDupRow;
	}

	/**
	* 지정한 Dataset에서 Expr(조건식)에 만족하는 Row를 return(개발자 사용금지:looping처리)
	* @private
	* @param {Dataset} oDs 		검색할 Dataset ID
	* @param {String} sColID 		검색할 Dataset의 Column ID
	* @param {String} sVal 		검색할 Dataset의 Column Value
	* @param {Number} nStartIdx		검색할 시작 레코드 Index. 시작 Index값은 0 이다.
	*            					nStartIdx가 0보다 작으면, 전체를 검색합니다.
									Default Value = 0
	* @param {Number} nEndIdx 		검색할 마지막 레코드 Index+1.
	*          						지정된 값보다 1 작은 레코드까지 검색합니다.
	*         						nEndIdx가 0보다 작으면 nStartIdx에서 끝까지 검색합니다.
	*         						Default Value = -1
	* @return {Array} 일치하는 레코드index
	* @example DatasetEx._findRowsExpr(oDs, sExpr, nStartIdx, nEndIdx)
	* @memberOf DatasetEx
	*/
	DatasetEx._findRowsExpr = function(oDs, sExpr, nStartIdx, nEndIdx)
	{
		var aIndex = [];

		if(Util.isNull(nStartIdx)) 	nStartIdx = 0;
		if(Util.isNull(nEndIdx)) 	nEndIdx = -1;

		var nNextIdx = nStartIdx;
		var nRow = -1;
		do {
			nRow = oDs.findRowExpr(sExpr, nNextIdx, nEndIdx);
			if (nRow >= 0)
			{
				aIndex.push(nRow);
				nNextIdx = nRow+1;
			}
		} while(nRow >= 0 && (nEndIdx < 0 || (nEndIdx >= 0 && nRow < nEndIdx)))

		return aIndex;
	}

	/**
	* sDatasetID Dataset의 sColID 값과 sVal의 값이 일치하는 레코드 Index를 모두 찾아 array로 리턴한다.
	* @param {Dataset} oDs 		검색할 Dataset ID
	* @param {String} sColID 		검색할 Dataset의 Column ID
	* @param {String} sVal 		검색할 Dataset의 Column Value
	* @param {Number} nStartIdx		검색할 시작 레코드 Index. 시작 Index값은 0 이다.
	*            					nStartIdx가 0보다 작으면, 전체를 검색합니다.
									Default Value = 0
	* @param {Number} nEndIdx 		검색할 마지막 레코드 Index+1.
	*          						지정된 값보다 1 작은 레코드까지 검색합니다.
	*         						nEndIdx가 0보다 작으면 nStartIdx에서 끝까지 검색합니다.
	*         						Default Value = -1
	* @return {Array} 일치하는 레코드index
	* @example DatasetEx.findRows(oDs, sColID, sValue, nStartIdx, nEndIdx)
	* @memberOf DatasetEx
	*/
	DatasetEx.findRows = function(oDs, sColID, sValue, nStartIdx, nEndIdx, bScope)
	{
		if (Util.isNull(nStartIdx)) nStartIdx = 0;
		if (Util.isNull(nEndIdx)) 	nEndIdx = oDs.getRowCount();

		var bBreakForScope = false, aRows = [];
		oDs.set_enableevent(false);
		for (var i=nStartIdx, nRowCnt=nEndIdx; i<nRowCnt; i++)
		{
			if (Util.trim(oDs.getColumn(i, sColID)) == sValue)
			{
				aRows.push(i);
				if (bScope === true) bBreakForScope = true;
			}
			else
			{
				if (bScope && bBreakForScope)
				{
					break;
				}
			}
		}
		oDs.set_enableevent(true);
		return aRows;
	}

	/**
	* sDatasetID Dataset의 sColID 값과 sVal의 값을 포함하는 레코드 Index를 모두 찾아 array로 리턴한다.
	* @param {Dataset} oDs 		검색할 Dataset ID
	* @param {String} sColID 	검색할 Dataset의 Column ID
	* @param {String} sVal 		검색할 Dataset의 Column Value
	* @param {Number} nStartIdx	검색할 시작 레코드 Index. 시작 Index값은 0 이다.
	*            				nStartIdx가 0보다 작으면, 전체를 검색합니다.
								Default Value = 0
	* @param {Number} nEndIdx 	검색할 마지막 레코드 Index+1.
	*          					지정된 값보다 1 작은 레코드까지 검색합니다.
	*         					nEndIdx가 null이면 끝까지 검색합니다.
	*         					Default Value = null
	* @return {Array} 일치하는 레코드index
	* @example DatasetEx.findRowsAs(oDs, sColID, sValue, nStartIdx, nEndIdx)
	* @memberOf DatasetEx
	*/
	DatasetEx.findRowsAs = function(oDs, sColID, sValue, nStartIdx, nEndIdx)
	{
		if(Util.isNull(nStartIdx)) 	nStartIdx = 0;
		if(Util.isNull(nEndIdx)) 	nEndIdx = oDs.getRowCount();

		var aRows = [];
		oDs.set_enableevent(false);
		for (var i=nStartIdx, nRowCnt=nEndIdx+1; i<nRowCnt; i++)
		{
			if (Util.trim(oDs.getColumn(i, sColID)).indexOf(sValue) >= 0) aRows.push(i);
		}
		oDs.set_enableevent(true);

		return aRows;
	}

	/**
	* 특정 데이터셋의 행(row)을 현재 데이터셋의 지정한 행의 위치에 복사하는 함수
	* 행관리컬럼을 유지하는 경우 "_"로 시작하는 컬럼은 복사에서제외됨(_rowtype, _chk)
	* @param {Dataset} 	oDstDs 		목표Dataset ID
	* @param {String} 	nToRow 		목표Dataset의 rowposition
	* @param {Dataset} 	oSrcDs 		원본Dataset ID
	* @param {String} 	nFromRow 	원본Dataset의 rowposition
	* @param {Boolean} 	bInit 		목표Dataset의 rowtype초기화(true지정시 rowtype 및 _rowtype normal로 변경)
	* @param {Object} 	oCfg		(optional) 복사처리시 설정옵션(colinfo, rowinit)
	* 				  				colinfo 복사할 조건식(Dataset의 copyRow함수와 동일 : F1 도움말참고)
	* @example DatasetEx.copyRow(this.dsList1, 2, this.dsList, nFromRow);
	* @memberOf DatasetEx
	*/
	DatasetEx.copyRow = function(oDstDs, nToRow, oSrcDs, nFromRow, bRowInit, oCfg)
	{
		if (!oCfg) oCfg = {};

		var sColInfo = oCfg.colinfo || "";

		DatasetEx._checkRowType(oDstDs); // 2017.12.11 공통요청으로 추가

		if (NX.updatecontrol === false)
		{
			if (!sColInfo) sColInfo = DatasetEx._getColInfoForCopy(oSrcDs, oDstDs);
		}

		oDstDs.copyRow(nToRow, oSrcDs, nFromRow, sColInfo);

		if (bRowInit === true)
		{
			DatasetEx.setRowType(oDstDs, nToRow, DatasetEx.ROWTYPE_NORMAL);
			oDstDs.applyChange();
		}
	}

	/**
	 * Dataset복사시 컬럼정보 반환(특정컬럼을 제외하기위해사용)
	 * @private
	 * @param  {Object} oSrcDs 원본Dataset
	 * @param  {Object} oDstDs 대상Dataset
	 * @return {String} 	복사컬럼정보
	 * @example DatasetEx._getColInfoForCopy(this.dsScr, this.dsDst)
	 * @memberof DatasetEx
	 */
	DatasetEx._getColInfoForCopy = function(oSrcDs, oDstDs)
	{
		var sColId, sColInfo = "";
		for (var i=0, nCnt=oDstDs.getColCount(); i<nCnt; i++)
		{
			sColId = oDstDs.getColID(i);
			if (sColId.indexOf("_") == 0) continue;

			if (oSrcDs.getColumnInfo(sColId))
			{
				sColInfo += sColId + "=" + sColId + ",";
			}
		}
		return sColInfo;

	}

	/**
	 * 데이터셋에서 지정한 행(row)을 원하는 위치(RowPosition)로 이동하는 메소드
	 * @param  {Object} oDs 대상Dataset
	 * @param  {Number} nOldRow Old행
	 * @param  {Number} nNewRow New행
	 * @return {Number} 	이동한 위치
	 * @example DatasetEx.moveRow(this.dsList, 1, 4)
	 * @memberof DatasetEx
	 */
	DatasetEx.moveRow = function(oDs, nOldRow, nNewRow)
	{
		var nRow = -1;
		if (oDs)
		{
			DatasetEx._checkRowType(oDs);
			var nRow = oDs.moveRow(nOldRow, nNewRow);
			if (!NX.updatecontrol && nRow >= 0)
			{
				DatasetEx.setRowType(oDs, nOldRow, DatasetEx.ROWTYPE_UPDATE);
				DatasetEx.setRowType(oDs, nNewRow, DatasetEx.ROWTYPE_UPDATE);
			}
		}
		return nRow;
	}

	/**
	 * Dataset의 마지막에 행을 추가
	 * @param  {Object} oDs 대상Dataset
	 * @return {Number} 	추가한 위치
	 * @example DatasetEx.addRow(this.dsList)
	 * @memberof DatasetEx
	 */
	DatasetEx.addRow = function(oDs)
	{
		var nRow = -1;
		if (oDs)
		{
			DatasetEx._checkRowType(oDs);
			var nRow = oDs.addRow();
			if (!NX.updatecontrol) DatasetEx.setRowType(oDs, nRow, DatasetEx.ROWTYPE_INSERT);
		}
		return nRow;
	}


	/**
	 * Dataset에 행을 추가
	 * @param  {Object} oDs 대상그리드
	 * @param  {Boolean} bDown 현재행+1위치에 추가 (default:현재Row에 추가)
	 * @return {Number} 추가된Row Index
	 * @example DatasetEx.insertRow(this.dsList)
	 * @memberof DatasetEx
	 */
	DatasetEx.insertRow = function(oDs, bDown)
	{
		var nRow;
		if (oDs)
		{
			DatasetEx._checkRowType(oDs);

			var iRow = bDown === true ? oDs.rowposition+1 : oDs.rowposition;
			nRow = oDs.insertRow(iRow == -1 ? 0 : iRow);

			if (!NX.updatecontrol) DatasetEx.setRowType(oDs, nRow, DatasetEx.ROWTYPE_INSERT);
		}
		return nRow;
	}

	/**
	* Dataset의 행을 삭제(체크박스 컬럼존재 유무에 따라 구분하여 처리)
	* @param  {Grid} oDs 대상Dataset(필수)
	* @param  {Ojbect} checkbox : 체크박스 바인딩 컬럼이 다른경우, rows : Dataset의 삭제할 rowposition배열
	* @return {Object} 삭제index (체크박스/다건 : 배열, 단건 : 삭제Index)
	* @example DatasetEx.deleteRow(oGrid, oCfg)
	* @memberof DatasetEx
	*/
	DatasetEx.deleteRow = function(oDs, oCfg)
	{
		if (oDs)
		{
			oCfg = oCfg || {};

			var _this = oDs.parent;
			DatasetEx._checkRowType(oDs);

			var sDelMsg 	= this.DELMSG_TEXT;
			var aRow		= -1;
			var aDelRow     = [];
			var sChkColId 	= oCfg.checkbox || DatasetEx._CHECKBOX_COLUMN;
			var oColInfo 	= oDs.getColumnInfo(sChkColId);
			if (oColInfo || oCfg.rows)
			{
				aRow = oColInfo ? DatasetEx.findRows(oDs, sChkColId, 1) : oCfg.rows;

				if (aRow.length == 0) // return array
				{
					//return _this.gfn_msgBox("M", NX._getUiMsg("UI023"), {restrict:true}); // "삭제 할 행을 체크하세요."
					return _this.gfn_msgBox("M",Util.getComMsg("I.ZZ.ZZ.0004"), {restrict:true}); // "삭제 할 행을 체크하세요."
				}
				else
				{
					if (NX.updatecontrol)
					{
						oDs.deleteMultiRows(aRow);
					}
					else
					{
						
						oDs.set_enableevent(false);
						for (var i=aRow.length-1; i>=0; i--)
						{
							
							// 2018.03.15 삭제된 상태에서 추가삭제시 Org값으로 원복처리 요청
//							if (DatasetEx.getRowType(oDs, aRow[i]) == Dataset.ROWTYPE_INSERT)
//							{
//								oDs.deleteRow(aRow[i]);
//							}
//							else
//							{
//								DatasetEx.setRowType(oDs, aRow[i], DatasetEx.ROWTYPE_DELETE);
//								if (oColInfo) oDs.setColumn(aRow[i], sChkColId, "0");
//							}

							switch (DatasetEx.getRowType(oDs, aRow[i]))
							{
								case Dataset.ROWTYPE_INSERT :
									//oDs.deleteRow(aRow[i]);
									aDelRow[aDelRow.length] = aRow[i]; // 2018.09.05 삭제시 이벤트를 수행하기 위해 삭제정보를 배열로 담아 이벤트가 활성화 된 이후에 삭제수행 처리
									break;

								case Dataset.ROWTYPE_DELETE :
									// retreieve -> update -> delete : update 수정된 컬럼값 유지됨(2018.03.19 공통팀요청)
									//oDs.setColumn(aRow[i], DatasetEx._ROWTYPE_COLUMN, oDs.getOrgColumn(aRow[i], DatasetEx._ROWTYPE_COLUMN))
									
									for(var k=0; k<oDs.colcount; k++)
									{
										var sCurData = oDs.getColumn(aRow[i], k);
										var sOrgData = oDs.getOrgColumn(aRow[i], k);

										if(sCurData != sOrgData) oDs.setColumn(aRow[i], k, oDs.getOrgColumn(aRow[i], k));							
									}
									//if (oColInfo) oDs.setColumn(aRow[i], sChkColId, "0");
									break;

								default :
									DatasetEx.setRowType(oDs, aRow[i], DatasetEx.ROWTYPE_DELETE);
									if (oColInfo) oDs.setColumn(aRow[i], sChkColId, "0");
									break;
							}
						}
						oDs.set_enableevent(true);
						
						// 2018.09.05 삭제시 이벤트를 수행하기 위해 삭제정보를 배열로 담아 이벤트가 활성화 된 이후에 삭제수행 처리
						if(aDelRow.length > 0) oDs.deleteMultiRows(aDelRow);
					}
				}
			}
			else
			{
				var nCurRow = oDs.rowposition;
				if (NX.updatecontrol)
				{
					if (oDs.deleteRow(nCurRow))
					{
						aRow = nCurRow;
					}
				}
				else
				{

					if (DatasetEx.getRowType(oDs, nCurRow) == Dataset.ROWTYPE_INSERT)
					{
						oDs.deleteRow(nCurRow);
					}
					else
					{
						oDs.set_enableevent(false);
						switch (DatasetEx.getRowType(oDs, nCurRow))
						{										
							case Dataset.ROWTYPE_DELETE : 
								// retreieve -> update -> delete : update 수정된 컬럼값 유지됨(2018.03.19 공통팀요청)
								for(var k=0; k<oDs.colcount; k++)
								{
									var sCurData = oDs.getColumn(nCurRow, k);
									var sOrgData = oDs.getOrgColumn(nCurRow, k);

									if(sCurData != sOrgData) oDs.setColumn(nCurRow, k, oDs.getOrgColumn(nCurRow, k));							
								}						

								break;
						
							default :
								DatasetEx.setRowType(oDs, nCurRow, DatasetEx.ROWTYPE_DELETE);
								break;									
						}
						
						oDs.set_enableevent(true);						
					}
					aRow = nCurRow;
				}
			}
		}

		return aRow;
	}

/**
	* 조건에 만족하는 원본Dataset의 Row를 목적Dataset에 복사하여 붙여넣기(복사시 행추가되어 상태는 "C"로 설정됨)
	* 행관리컬럼을 유지하는 경우 "_"로 시작하는 컬럼은 복사에서제외됨(_rowtype, _chk)
	* @param {Dataset} 	oSrcDs	검색할 Dataset ID
	* @param {Dataset} 	oDstDs	복사될 Dataset ID(원본Dataset과 구조동일해야함)
	* @param {String} 	sColID 	검색할 Dataset의 Column ID
	* @param {String} 	sVal 	검색할 Dataset의 Column Value
	* @param {Object} 	oCfg 	(optional) 	colinfo : 복사할 컬럼조건 (형식: ToColumnID=FromColumnID,ToColumnID1=FromColumnID1)
	* 										clear : false지정시 clearData()미처리
	* @return {Boolean} 성공여부
	* @memberOf DatasetEx
	*/
	DatasetEx.copyRows = function(oSrcDs, oDstDs, sColID, sValue, oCfg)
	{
		var bSucc = null;
		if (!oCfg) oCfg = {};
		if (!(oCfg.clear === false)) oDstDs.clearData();

		var nAddRow, sColInfo = oCfg.colinfo || "";
		var aRowIdx = DatasetEx.findRows(oSrcDs, sColID, sValue);
		if (NX.updatecontrol === false)
		{
			if (!sColInfo) sColInfo = DatasetEx._getColInfoForCopy(oSrcDs, oDstDs);
		}

		for (var i=0, nCnt=aRowIdx.length; i<nCnt; i++)
		{
			nAddRow = DatasetEx.addRow(oDstDs);
			bSucc = oDstDs.copyRow(nAddRow, oSrcDs, aRowIdx[i], sColInfo);
		}

		return bSucc;
	}

//	/**
//	 * [Runtime전용] 데이터셋을 CSV 형식으로 변환합니다.
//	 * @param {Dataset} oDs 데이터셋 오브젝트
//	 * @param {String} sFileName CSV 파일 경로
//	 * @param {String} sHeadFlag 컬럼 정보 포함 여부(true : 컬럼 정보 삭제 후 처리)
//	 * @param {String} sColumnId 컬럼 정보, 콤마로 구분한 컬럼 정보 (col01,col02,col03...)
//	 * @param {Boolean} bCommaYN 각 레코드 끝에 콤마 추가(true : 콤마 추가, false : 콤마 추가 없음)
//	 * @memberOf DatasetEx
//	 */
// 		ds2Csv = function(oDs, sFileName, sHeadFlag, sColumnId, bCommaYN)
// 		{
// 			var oExtCommon	= new ExtCommon();
// 				oExtCommon.ds2Csv(oDs, sFileName, sHeadFlag, sColumnId, bCommaYN);
//
// 				oExtCommon	= null;
// 		}

	/**
	* Dataset의 변경(Update) 여부 확인
	* @param {Dataset} dsObj	확인할 Dataset ID
	* @return {Boolean} true/false
	* @example DatasetEx.isUpdate(this.dsList)
	* @memberOf DatasetEx
	*/
	DatasetEx.isUpdate = function(oDs)
	{
		if (oDs.getRowCount() < 1 ) return false;
		if (NX.updatecontrol && oDs.getDeletedRowCount() > 0) return true;

		var nRowType = "";
		for (var i=0, nRowCnt=oDs.getRowCount(); i<nRowCnt; i++)
		{
			nRowType = NX.updatecontrol ? oDs.getRowType(i) : DatasetEx.getRowType(oDs, i);
			// check for insert column value
	// 		if (nRowType == Dataset.ROWTYPE_INSERT)
	//		{
	// 			for(var j=0; j<oDs.getColCount(); j++)
	//			{
	// 				if (!Util.isNull(oDs.getColumn(i, j))) return true;
	// 			}
	// 			continue;
	//		}
			if (nRowType != Dataset.ROWTYPE_NORMAL && nRowType != Dataset.ROWTYPE_GROUP)
			{
				return true;
				break;
			}
		}
		return false;
	}

	/**
	 * Dataset의 nRow상태를 반환하는 함수
	 * @param {Dataset}	oDs		확인 할 Dataset ID
	 * @param {Number}	nRow	확인 할 Dataset rowposition
	 * @return {Number} 현재Row의 상태(초기:1, 추가:2, 수정:4, 삭제:8)
	 * @example DatasetEx.getRowType(this.dsList, 4)
	 * @memberOf DatasetEx
	 */
	DatasetEx.getRowType = function(oDs, nRow)
	{
		if (NX.updatecontrol)
		{
			return oDs.getRowType(nRow);
		}
		else
		{
			if (oDs.getColumnInfo(NX.rowtype))
			{
				if (nRow < 0) return "";
				if (oDs.getRowCount() < 1) return "";
				if (oDs.getColumnInfo(NX.rowtype) < 0) return "";

				var nRowType;
				var sRowType = Util.trim(oDs.getColumn(nRow, NX.rowtype)) || DatasetEx.ROWTYPE_NORMAL; // "N"
				switch (sRowType)
				{
					case this.ROWTYPE_INSERT : 	nRowType = Dataset.ROWTYPE_INSERT;	break;
					case this.ROWTYPE_UPDATE :	nRowType = Dataset.ROWTYPE_UPDATE;	break;
					case this.ROWTYPE_DELETE :	nRowType = Dataset.ROWTYPE_DELETE;	break;
					case this.ROWTYPE_NORMAL :	nRowType = Dataset.ROWTYPE_NORMAL;	break;
					default  :	nRowType = Dataset.ROWTYPE_NORMAL;	break;
				}

				return nRowType;
			}
		}
	}

	/**
	 * Dataset의 nRow상태를 설정하는 함수
	 * @param {Dataset} oDs			Dataset ID
	 * @param {Number} nRow			Dataset rowposition
	 * @param {String} sType		상태(초기:1, 추가:2, 수정:4, 삭제:8 또는 C : DatasetEx.ROWTYPE_INSERT, U : DatasetEx.ROWTYPE_UPDATE, D : DatasetEx.ROWTYPE_DELETE, N : DatasetEx.ROWTYPE_NORMAL)
	 * @return {Number} 현재Row의 상태
	 * @example DatasetEx.setRowType(ds_list, 4, DatasetEx.ROWTYPE_UPDATE)
	 * @memberOf DatasetEx
	 */
	DatasetEx.setRowType = function(oDs, nRow, sType)
	{
		if (NX.updatecontrol)
		{
			return oDs.setRowType(nRow);
		}
		else
		{
			if (oDs.getColumnInfo(NX.rowtype))
			{
				if (nRow < 0) return "";
				if (oDs.getRowCount() < 1) return "";

				if (nexacro.isNumeric(sType))
				{
					switch(sType)
					{
						case 1 : sType = DatasetEx.ROWTYPE_NORMAL; break;
						case 2 : sType = DatasetEx.ROWTYPE_INSERT; break;
						case 4 : sType = DatasetEx.ROWTYPE_UPDATE; break;
						case 8 : sType = DatasetEx.ROWTYPE_DELETE; break;
					}
				}

				return oDs.setColumn(nRow, NX.rowtype, sType);
			}
		}
	}

	/**
	* 특정 데이터셋의 상태컬럼을 "Normal"로 변경하는 함수
	* @param {Dataset} 	oDs 		목표Dataset
	* @param {Object} 	oCfg		(optional) 초기화 설정옵션
	* @example DatasetEx.applyChange(this.dsList1);
	* @memberOf DatasetEx
	*/
	DatasetEx.applyChange = function(oDs)
	{
		var bSucc;
		if (NX.updatecontrol)
		{
			bSucc = oDs.applyChange();
		}
		else
		{
			if (oDs.getColumnInfo(NX.rowtype)) // 컬럼유무
			{
				oDs.set_enableevent(false);
				for (var i=0, nCnt=oDs.rowcount; i<nCnt; i++)
				{
					oDs.setColumn(i, NX.rowtype, DatasetEx.ROWTYPE_NORMAL);
				}
				oDs.set_enableevent(true);
				bSucc = oDs.applyChange();
			}
		}
		return bSucc;
	}

	/**
	 * Dataset의 nRow로우가 수정됐는지 확인하는 함수
	 * @param {Dataset} dsObj		확인할 Dataset ID
	 * @param {Number} nRow			확인할 Dataset rowposition
	 * @param {Object} aSkipColLst	제외할 Dataset 체크컬럼명 리스트(default:_chk)
	 * @return {Boolean} true/false
	 * @example DatasetEx.isUpdateRow(ds_list, 4, "name")
	 * @memberOf DatasetEx
	 */
	DatasetEx.isUpdateRow = function(oDs, nRow, aSkipColLst)
	{
		// 컬럼명이 "_"로 시작하는 경우 체크에서 제외
		var nRowType = NX.updatecontrol ? oDs.getRowType(nRow) : DatasetEx.getRowType(oDs, nRow);
		switch (nRowType)
		{
			case Dataset.ROWTYPE_INSERT :
			case Dataset.ROWTYPE_DELETE : return true;

			case Dataset.ROWTYPE_UPDATE :
				for (var i=0, nSize=oDs.getColCount(); i<nSize; i++)
				{
					var aColLst = Array.isArray(aSkipColLst) ? aSkipColLst : [aSkipColLst];
					var sColNm 	= oDs.getColID(i);
					if (aColLst.indexOf(sColNm) >= 0 || sColNm.indexOf("_") == 0) continue;

					if (Util.toString(oDs.getColumn(nRow, sColNm)) != Util.toString(oDs.getOrgColumn(nRow, sColNm)))
					{
						return true;
					}
				}
				return false;

			default: return false;
		}
	}

	/**
	 * 원본Dataset의 지정한nRow의 컬럼과 목적Dataset의 컬럼값이 다른지를 확인하는 함수(비교함수 : Util.trim())
	 * @param {Dataset} oSrcDs		원본 Dataset ID (컬럼 및 rowtype 기준)
	 * @param {Number} nSrcRow		원본 Dataset rowposition
	 * @param {Dataset} oDstDs		목적 Dataset ID
	 * @param {Number} nDstRow		목적 Dataset rowposition
	 * @param {Object} aSkipColLst	제외할 Dataset 체크컬럼명 리스트(default:_chk)
	 * @return {Boolean} true/false
	 * @example DatasetEx.isCompareRow(ds_list3, 4, ds_list3dst, 2);
	 * @memberOf DatasetEx
	 */
	DatasetEx.isCompareRow = function(oSrcDs, nSrcRow, oDstDs, nDstRow, aSkipColLst)
	{
		if (oSrcDs && oDstDs)
		{
			for (var i=0, nSize=oSrcDs.getColCount(); i<nSize; i++)
			{
				var aColLst = Array.isArray(aSkipColLst) ? aSkipColLst : [aSkipColLst];
				var sColNm 	= oSrcDs.getColID(i);
				if (aColLst.indexOf(sColNm) >= 0 || sColNm.indexOf("_") == 0) continue;

				if (Util.trim(oSrcDs.getColumn(nSrcRow, sColNm)) != Util.trim(oDstDs.getColumn(nDstRow, sColNm)))
				{
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Dataset 에 선택된 상태의 Row 수를 얻어오는 함수(for multirow)
	 * @param {Dataset} oDs	선택된 Row 수를 얻어올 Dataset
	 * @return {Number} 선택된 Row 수
	 * @example DatasetEx.getSelectedRowCount(ds_List1)
	 * @memberOf DatasetEx
	 */
	DatasetEx.getSelectedRowCount = function(oDs)
	{
		return oDs.getCaseCount("getSelect(rowidx)==true");
	}

	/**
	 * Dataset 에 선택된 상태의 첫번째 Row 를 얻어오는 함수(for multirow)
	 * @param {Dataset} oDs	선택된 Row 를 얻어올 Dataset
	 * @return {Number} 첫번째 선택된 Row
	 * @example DatasetEx.getSelectedFirstRow(ds_List1)
	 * @memberOf DatasetEx
	 */
	DatasetEx.getSelectedFirstRow = function(oDs)
	{
		return oDs.findRowExpr("getSelect(rowidx)==true");
	}


	// Dataset current Row Object형식으로 넘기기
	DatasetEx.getDsRowToJsonStr = function(oDs, nRow)
	{
		var sJsonStr = "", nRow = nRow || oDs.rowposition;
		for (var i=0, nRowCnt=oDs.getColCount(); i<nRowCnt; i++)
		{
			var sColId = oDs.getColID(i);
			sJsonStr += (i>0 ? "," : "") + '"' + sColId + '":"' + oDs.getColumn(nRow, sColId) + '"';
		}
		return "{" + sJsonStr + "}";
	}

	DatasetEx.getCSV = function(o)
	{
//		return o.saveCSV();
	}

	DatasetEx.getXmlForWS = function(obj, oCfg)
	{
// 			if (!oCfg) oCfg = {};
//
// 			var sTagNm = oCfg.tagname || "ITEMS";
// 			var sXML = "<" + sTagNm + ">\n";
//
// 			for (var i=0, nRowCnt=obj.rowcount; i<nRowCnt; i++)
// 			{
// 				sXML += "<ITEM>\n";
// 				for (var j=0, nColCnt=obj.colcount; j<nColCnt; j++)
// 				{
// 					sXML += "<" + obj.getColID(j) + "><![CDATA[" + obj.getColumn(i, j) + "]]]]]]><![CDATA[><![CDATA[></" + obj.getColID(j) + ">\n";
// //					sXML += "<" + obj.getColID(j) + ">" + obj.getColumn(i, j) + "</" + obj.getColID(j) + ">\n";
// 				}
// 				sXML += "</ITEM>\n";
// 			}
// 			sXML += "</" + sTagNm + ">\n";
// 			return sXML;
	}

	/**
	 * Dataset의 공통기능 적용속성을 clear처리
	 * @private
	 * @param {Grid} oGrid	대상그리드
	 * @param {Dataset} oOutDs	대상Dataset
	 * @example DatasetEx._clearProperty(this.grdList, this.dsList)
	 * @memberOf DatasetEx
	 */
	DatasetEx._clearProperty = function(oGrid, oOutDs)
	{
		var bClrFilterStr = false, bClrKeyString = false, bFixedGrid = oOutDs._clearfixgrid, bNodataGrid = oOutDs._nodatagrid;
		var sCurFilterStr = DatasetEx.getFilter(oOutDs);
		var sDftFilterStr = DatasetEx.getFilter(oOutDs, false);
		if (sCurFilterStr)
		{
			bClrFilterStr = sCurFilterStr != sDftFilterStr;
			if (bClrFilterStr) DatasetEx.setFilter(oOutDs, sDftFilterStr);  // default
		}

		var sCurKeystring = DatasetEx.getKeystr(oOutDs);
		var sDftKeystring = DatasetEx.getKeystr(oOutDs, false);
		if (sCurKeystring)
		{
			bClrKeyString = sCurKeystring != sDftKeystring;
			if (bClrKeyString) DatasetEx.setKeystr(oOutDs, sDftKeystring); // default
		}

		oOutDs._rowfilterxml	= ""; // 컬럼필터링  처리시 정보저장
		oOutDs._keystrxml 		= ""; // 소트/그룹핑 처리시 정보저장
		oOutDs._cmmsfilter 		= "";

		if (bClrFilterStr || bClrKeyString || bFixedGrid || bNodataGrid) // initalize header string
		{
			if (bFixedGrid === true)
			{
				GridEx.clearFix(oGrid);
				oOutDs._clearfixgrid = false;
			}

			if (bNodataGrid === true)
			{
//				oClrGrd.set_nodataimage("");
//				oClrGrd.set_nodatatext("");
				oOutDs._nodatagrid = false;
			}

			if (bClrFilterStr || bClrKeyString)
			{
				if (oGrid && oGrid.visible)
				{
					if (bClrKeyString) GridEx._clearSortMark(oGrid);
					if (bClrFilterStr) GridEx._clearFilterMark(oGrid);
				}
			}
		}
	},

	/**
	 * Dataset을 destory하는 함수[화면연계시 동적생성 Dataset대상]
	 * @private
	 * @param {Grid} oGrid	대상그리드
	 * @example DatasetEx._destroy(this.grdList)
	 * @memberOf DatasetEx
	 */
	DatasetEx._destroy = function(o)
	{
		try
		{
			o.destroy();
			o = null;
		}
		catch(e)
		{
			Util.trace("[DatasetEx.destory] `Exception : " + e.message);
		}
	}

	/**
	 * 지정한 DatasetName으로 Dataset을 생성하거나 반환하는 함수
	 * @private
	 * @param {String} sDsId	DatasetId
	 * @param {Object} o	대상컨테이너(Form)
	 * @example DatasetEx._get("dsTest", this)
	 * @memberOf DatasetEx
	 */
	// 공통코드 조회 등에서 사용할 Dataset을 생성하는 함수
	DatasetEx._get = function(sDsId, o, oCfg)
	{
		var pThis = o;
		var oDs = pThis.objects[sDsId];
		if (oDs)
		{}
		else
		{
			oDs = new Dataset();
			oDs.set_name(sDsId);
			pThis.addChild(sDsId, oDs);

			if (oCfg && oCfg.formatds)
			{
				oDs.copyData(oCfg.formatds);
				oDs.clearData();
			}
		}
		return oDs;
	}
}
