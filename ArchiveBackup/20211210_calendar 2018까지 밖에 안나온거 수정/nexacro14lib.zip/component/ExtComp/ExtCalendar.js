﻿if (!nexacro.ExtCalendar) 
{
    // ==============================================================================
    // nexacro.ExtCalendar
    // ==============================================================================
   
    nexacro.ExtCalendar = function(id, position, left, top, width, height, right, bottom, parent) 
    {
		//alert("start~~~~~~~~~~~~~~~~~~~~~");
        nexacro.Div.call(this, id, position, left, top, width, height, right, bottom, parent);
        this._draw = true;
		this.reDraw();
          
    };

	var _pExtCalendar = nexacro._createPrototype(nexacro.Div);
    nexacro.ExtCalendar.prototype = _pExtCalendar;
    _pExtCalendar._type = "ExtCalendar";
    _pExtCalendar._type_name = "ExtCalendar";
	_pExtCalendar.reDraw = function() 
	{
	    this.value = "";
	    this.title = "";
	    this._CHANGE_EVENT;
		/*
           지역선택 영역 생성
		*/
		var oCal = new Calendar();  
		oCal.init("cal_date","absolute", 0, 0, null, null, 0, 0);
		this.addChild("cal_date", oCal); 
		oCal.set_style("align:left middle");
		oCal.set_dateformat("yyyy-MM-dd");
		oCal.set_editformat("yyyy-MM-dd");
		oCal.addEventHandler("onkeyup", this.cal_onkeyup, this);
		oCal.addEventHandler("onkillfocus", this.cal_onkillfocus, this);
//		oEditLoc.set_tooltiptext(this.tooltiptext);
//		oEditLoc.set_value("전체");
		oCal.show();
	
		//월력달력 오픈버튼 생성
		var oBtnCal = new Button();  
		oBtnCal.init("btn_cal","absolute", null, 2, 25, null,2,2);
		this.addChild("btn_cal", oBtnCal);
		oBtnCal.set_cssclass("btn_WF_Cal");
		oBtnCal.addEventHandler("onclick", this.btn_cal_onclick, this);
		oBtnCal.show(); 

        //원력달력 팝업 생성
		var oPopupDiv = new PopupDiv();  
		oPopupDiv.init("pdp_calYear", "absolute", 0, 0, 304, 387,null,null);
		this.addChild("pdp_calYear", oPopupDiv); 
		oPopupDiv.set_url("com::com_calendar_ext.xfdl");
		oPopupDiv.style.set_border( "1 solid #2b3753ff ");
		oPopupDiv.addEventHandler("oncloseup", this.pdp_yearClose, this);
		oPopupDiv.show();
 
	};

	
	/**
	 * Bind 대상 Properties 설정
	 */   
	_pExtCalendar.on_getBindableProperties = function () {
		return "value";
	}

	/**
	 * 데이터셋이 변경될때 값 변경처리
	 */ 
	_pExtCalendar.on_change_bindSource = function (propid, pSendDataset, rowIdx, colIdx, colArrayIdx) {
		if (propid !== "value" || !pSendDataset || rowIdx < -1 || colIdx < -1) {
			return false;
		}

		var value = pSendDataset.getColumn(rowIdx, colIdx);

		if (this.value == value) {
			return true;
		}

		//if(!this._valiateDt(value)) return false;

 	    this.value = value;

        this.cal_date.set_value(this.value);

		return true;
	};

	_pExtCalendar.cal_onkeyup = function(obj,e)
	{
	    if(e.keycode == 13)
	    {
	    	this._setValue(this.cal_date.value);
	    	
			if(!Util.isNull(this.__callFunc))
			{
				var oTopFrom = NX.getScriptForm(this);
				
	            try{
	               oTopFrom[this.__callFunc]();
				}catch(ex){}			
			}		    	
	    }
	};
	
	_pExtCalendar.cal_onkillfocus = function(obj,e)
	{
		this._setValue(this.cal_date.value);
	}
	
	_pExtCalendar._valiateDt = function(sVal)
    {
        if(Util.isNull(sVal)) return false;

        if(!comBase.isString(sVal)) return false;
        
        if(sVal.length > 4) return false;

		return true;
	}

	/**
	 * 멀티콤보 데이터 셋팅
	 */ 
    _pExtCalendar.set_value = function(sVal)
	{
		//if(this._valiateDt(sVal))
		//{
            this.value = sVal; 
			this.cal_date.set_value(this.value);
            this.applyto_bindSource("value", this.value);
		//}		
	};

	/**
	 * 카렌다 선택 이벤트
	 */    
	_pExtCalendar.btn_cal_onclick = function(obj,  e)
	{
        var oCal = this.cal_date;  
		var oPopupDiv = this.pdp_calYear;

        oPopupDiv.set_init(this.value);

		oPopupDiv.trackPopupByComponent(oCal,0,21);

	};



	/**
	 * 드랍다운 화면 닫힐때 이벤트
	 */    
    _pExtCalendar.pdp_yearClose = function(obj, e)
	{
	     var sValue = obj.fv_selecteDt;

         this._setValue(sValue);
         
		 if(!Util.isNull(this.__callFunc))
		 {
			if(obj._KEY_ENTER) 
			{			
				obj._KEY_ENTER = false;
			    var oTopFrom = NX.getScriptForm(this);
				
			     try{
			          oTopFrom[this.__callFunc]();
				}catch(ex){}
			}
		 }	         
	};
	
	
	_pExtCalendar._setValue = function(sValue)
	{

		 //if(Util.isNull(sValue)) return;
		 if(this.value == sValue) return;

		 this.value = sValue;
		 
         this.cal_date.set_value(this.value);

		 this.applyto_bindSource("value", this.value);

		 if(!Util.isNull(this._CHANGE_EVENT)) 
		 {
			var oTopFrom = NX.getScriptForm(this);
			
            try{
               oTopFrom[this._CHANGE_EVENT](this.name);
			}catch(ex){}
		 }
		 	
	}
	
	/**
	 * 선택변경시 호출 함수
	 */ 
    _pExtCalendar.set_changeEvent = function(sVal)
	{
        this._CHANGE_EVENT = sVal;
	}

	/**
	 * 필수체크시 타이틀 설정
	 */	
	_pExtCalendar.set_requiredtitle = function(sTitle)
	{
		if(!Util.isNull(sTitle))
		{
             this.title = sTitle;
	    }
	}

	/**
	 * 필수표시여부
	 */ 
    _pExtCalendar.set_required = function(sAct)
	{
		var bAct = (sAct == "true") ? true : false;

		if(bAct)
		{
		   var sValidTitle = (Util.isNull(this.title)) ? "일자" : this.title;
		   var sValidExpr = "title:"+sValidTitle+",required:true";
		   
           this.cal_date.set_cssclass("point");
		   this.cal_date.validate = sValidExpr;
		   this.btn_cal.set_cssclass("btn_WF_Cal_P");
		}
		else
		{
           this.cal_date.set_cssclass("");
           this.cal_date.validate = "";
           this.btn_cal.set_cssclass("btn_WF_Cal");
		}
	};

    delete _pExtCalendar;
}