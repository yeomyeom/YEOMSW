﻿if (!nexacro.ExtMonthCalendar) 
{
    // ==============================================================================
    // nexacro.ExtMonthCalendar
    // ==============================================================================
   
    nexacro.ExtMonthCalendar = function(id, position, left, top, width, height, right, bottom, parent) 
    {
		//alert("start~~~~~~~~~~~~~~~~~~~~~");
        nexacro.Div.call(this, id, position, left, top, width, height, right, bottom, parent);
        this._draw = true;
		this.reDraw();
          
    };

	var _pExtMonthCalendar = nexacro._createPrototype(nexacro.Div);
    nexacro.ExtMonthCalendar.prototype = _pExtMonthCalendar;
    _pExtMonthCalendar._type = "ExtMonthCalendar";
    _pExtMonthCalendar._type_name = "ExtMonthCalendar";
	_pExtMonthCalendar.reDraw = function() 
	{
	    this.value = "";
	    this.title = "";
	    this._CHANGE_EVENT;
		/*
           지역선택 영역 생성
		*/
		var oCal = new Calendar();  
		oCal.init("cal_date","absolute", 0, 0, null, null, 0, 0);
		this.addChild("cal_date", oCal); 
		oCal.set_style("align:left middle");
		oCal.set_dateformat("yyyy-MM");
		oCal.set_editformat("yyyy-MM");
		oCal.addEventHandler("onkeyup", this.cal_onkeyup, this);
		oCal.addEventHandler("onkillfocus", this.cal_onkillfocus, this);
//		oEditLoc.set_tooltiptext(this.tooltiptext);
//		oEditLoc.set_value("전체");
		oCal.show();
	
		//월력달력 오픈버튼 생성
		var oBtnCal = new Button();  
		oBtnCal.init("btn_cal","absolute", null, 2, 25, null,2,2);
		this.addChild("btn_cal", oBtnCal);
		oBtnCal.set_cssclass("btn_WF_Cal");
		oBtnCal.addEventHandler("onclick", this.btn_cal_onclick, this);
		oBtnCal.show(); 

        //원력달력 팝업 생성
		var oPopupDiv = new PopupDiv();  
		oPopupDiv.init("pdp_calMonth", "absolute", 0, 0, 229, 307,null,null);
		this.addChild("pdp_calMonth", oPopupDiv); 
		oPopupDiv.set_url("com::com_calendar_month_ext.xfdl");
		oPopupDiv.style.set_border( "1 solid #2b3753ff ");
		oPopupDiv.addEventHandler("oncloseup", this.pdp_monthClose, this);
		oPopupDiv.show();
 
	};

	
	/**
	 * Bind 대상 Properties 설정
	 */   
	_pExtMonthCalendar.on_getBindableProperties = function () {
		return "value";
	}

	/**
	 * 데이터셋이 변경될때 값 변경처리
	 */ 
	_pExtMonthCalendar.on_change_bindSource = function (propid, pSendDataset, rowIdx, colIdx, colArrayIdx) {
		if (propid !== "value" || !pSendDataset || rowIdx < -1 || colIdx < -1) {
			return false;
		}

		var value = pSendDataset.getColumn(rowIdx, colIdx);

		if (this.value == value) {
			return true;
		}

		//if(!this._valiateDt(value)) return false;

 	    this.value = value;

        this.cal_date.set_value(this.value);

		return true;
	};

	_pExtMonthCalendar.cal_onkeyup = function(obj,e)
	{
	    if(e.keycode == 13)
	    {
	    	this._setValue(this.cal_date.value);
	    	
			if(!Util.isNull(this.__callFunc))
			{
				var oTopFrom = NX.getScriptForm(this);
				
	            try{
	               oTopFrom[this.__callFunc]();
				}catch(ex){}			
			}	    	
	    }
	};
	
	_pExtMonthCalendar.cal_onkillfocus = function(obj,e)
	{
		this._setValue(this.cal_date.value);
	}
	
	_pExtMonthCalendar._valiateDt = function(sVal)
    {
        if(Util.isNull(sVal)) return false;

        if(!comBase.isString(sVal)) return false;
        
        if(sVal.length > 4) return false;

		return true;
	}

	/**
	 * 멀티콤보 데이터 셋팅
	 */ 
    _pExtMonthCalendar.set_value = function(sVal)
	{
		//if(this._valiateDt(sVal))
		//{
            this.value = sVal; 
			this.cal_date.set_value(this.value);
            this.applyto_bindSource("value", this.value);
		//}		
	};

	/**
	 * 카렌다 선택 이벤트
	 */    
	_pExtMonthCalendar.btn_cal_onclick = function(obj,  e)
	{
        var oCal = this.cal_date;  
		var oPopupDiv = this.pdp_calMonth;

        oPopupDiv.fnSetMonthCalendar(this.value);

		oPopupDiv.trackPopupByComponent(oCal,0,21);

	};



	/**
	 * 드랍다운 화면 닫힐때 이벤트
	 */    
    _pExtMonthCalendar.pdp_monthClose = function(obj, e)
	{
	     var sValue = obj.fvSelecteYm;

         this._setValue(sValue);
         
		 if(!Util.isNull(this.__callFunc))
		 {
			 if(obj._KEY_ENTER) 
			 {			 
				 obj._KEY_ENTER = false;
			    var oTopFrom = NX.getScriptForm(this);
					
			     try{
			          oTopFrom[this.__callFunc]();
				}catch(ex){}
			 }			 			
		 }         
	};
	
	
	_pExtMonthCalendar._setValue = function(sValue)
	{

		 //if(Util.isNull(sValue)) return;
		 if(this.value == sValue) return;

		 this.value = sValue;
		 
         this.cal_date.set_value(this.value);

		 this.applyto_bindSource("value", this.value);

		 if(!Util.isNull(this._CHANGE_EVENT)) 
		 {
			var oTopFrom = NX.getScriptForm(this);
			
            try{
               oTopFrom[this._CHANGE_EVENT](this.name);
			}catch(ex){}
		 }
		 	
	}
	
	/**
	 * 선택변경시 호출 함수
	 */ 
    _pExtMonthCalendar.set_changeEvent = function(sVal)
	{
        this._CHANGE_EVENT = sVal;
	}

	/**
	 * 필수체크시 타이틀 설정
	 */	
	_pExtMonthCalendar.set_requiredtitle = function(sTitle)
	{
		if(!Util.isNull(sTitle))
		{
             this.title = sTitle;
	    }
	}

	/**
	 * 필수표시여부
	 */ 
    _pExtMonthCalendar.set_required = function(sAct)
	{
		var bAct = (sAct == "true") ? true : false;

		if(bAct)
		{
		   var sValidTitle = (Util.isNull(this.title)) ? "일자" : this.title;
		   var sValidExpr = "title:"+sValidTitle+",required:true";
		   
           this.cal_date.set_cssclass("point");
		   this.cal_date.validate = sValidExpr;
		   this.btn_cal.set_cssclass("btn_WF_Cal_P");
		}
		else
		{
           this.cal_date.set_cssclass("");
           this.cal_date.validate = "";
           this.btn_cal.set_cssclass("btn_WF_Cal");
		}
	};


    delete _pExtMonthCalendar;
}