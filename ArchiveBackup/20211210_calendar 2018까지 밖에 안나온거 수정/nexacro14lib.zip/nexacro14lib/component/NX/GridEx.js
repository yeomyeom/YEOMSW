﻿/**
 * @fileoverview GRID와 관련된 함수.
 */

if (!JsNamespace.exist("GridEx"))
{
	/**
	 * @namespace
	 * @name GridEx
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("GridEx", {
		
		BODY_ROW_HEIGHT  : 24,
		
		_FIX_COL_PREFIX_ : "staVertical_",
		_FIX_ROW_PREFIX_ : "staHorizontal_",
		_EXCEL_ROW_DELIMITER_ : "\n",
		_EXCEL_COL_DELIMITER_ : "	",
		/**
		 * 소트마크(ascending)
		 * @private
		 * @type string
		 * @memberOf GridEx
		 */
		_CONST_ASC_MARK : "▲",		// sort mark(asc)
		/**
		 * 소트마크(descending)
		 * @private
		 * @type string
		 * @memberOf GridEx
		 */
		_CONST_DESC_MARK : "▼",	// sort mark(desc)
		/**
		 * 필터마크
		 * @private
		 * @type string
		 * @memberOf GridEx
		 */
		_CONST_FILTER_MARK : "▶",	// filter mark
		
		_CONST_SORT_IMG : "URL('img::img_WF_TopDown.png')",
	
		_CONST_ASC_IMG :  "URL('img::img_WF_Top.png')",
		
	    _CONST_DESC_IMG :  "URL('img::img_WF_Down.png')",
	    
		DELETE_CFM_PROP : "_DELETE_CFM_INFO", // infomation property for delete row 
		NODATA_TEXT	: "데이터가 없습니다.",	// message
		DELMSG_TEXT : "선택하신 내용이 삭제됩니다.\n삭제 후 재조회시 입력 후 저장하지 않은 데이터는 손실될 수 있습니다.\n계속하시겠습니까?"
		
	});
	
	/**
	 * 그리드의 행을 추가
	 * @param  {Object} oGrid 대상그리드
	 * @param  {Boolean} bDown 현재행+1위치에 추가 (default:현재Row에 추가)
	 * @return {Number} 추가된Row Index
	 * @example GridEx.insertRow(oGrid)
	 * @memberof GridEx
	 */
	GridEx.insertRow = function(oGrid, bDown)
	{
		var nRow;
		var oDs = oGrid.getBindDataset();
		if (oDs)
		{
			nRow = DatasetEx.insertRow(oDs, bDown);			
			if (oGrid.selecttype == "multirow") 
			{
				oDs.clearSelect();
				oDs.set_rowposition(nRow);
				oDs.selectRow(nRow);
			}
		}
		else
		{
			Util.trace("GridEx.js :: insertRow() => not found bind dataset : " + oDs);
		}
		return nRow;
	}

	/**
	 * 그리드의 마지막에 행을 추가
	 * @param  {Object} oGrid 대상그리드
	 * @return {Number} 추가한 위치
	 * @example GridEx.addRow(oGrid)
	 * @memberof GridEx
	 */
	GridEx.addRow = function(oGrid)
	{
		var nRow;
		var oDs = oGrid.getBindDataset();
		if (oDs)
		{
			nRow = DatasetEx.addRow(oDs);
			if (oGrid.selecttype == "multirow")
			{
				oDs.clearSelect();
				oDs.set_rowposition(nRow);
				oDs.selectRow(nRow);
			}
		}
		else
		{
			Util.trace("GridEx.js :: addRow() => not found bind dataset : " + oGrid);
		}
		
		return nRow;
	}

	/**
	* 그리드의 행을 삭제
	* @param  {Grid} oGrid 대상그리드(필수)
	* @param  {Ojbect} checkbox : 체크박스 바인딩 컬럼이 다른경우, skipmsg : 메시지제외처리(선택)
	* @return {Object} 삭제index (체크박스 : 배열/ 단건 : 삭제Index)
	* @example GridEx.deleteRow(oGrid, oCfg)
	* @memberof GridEx
	*/
	GridEx.deleteRow = function(oGrid, oCfg)
	{
		// for html5
		if (NX.isruntime)
		{
			GridEx._deleteRow(oGrid, oCfg);
		}
		else
		{
			var oDs = oGrid.getBindDataset();
			if (oDs)
			{
				oCfg = oCfg || {};
				var _this 	= oDs.parent;
				if (oCfg.skipmsg === false)
				{
					oCfg.skipmsg = true;
					this[this.DELETE_CFM_PROP] = {grid:oGrid, config:oCfg};
					_this.gfn_msgBox("C", this.DELMSG_TEXT, {popupid:this.DELETE_CFM_PROP, callback:GridEx._deleteRowCallback});
				}
				else
				{
					GridEx._deleteRow(oGrid, oCfg);
				}
			}
		}
	},
	
	/**
	 * 데이터셋에서 지정한 행(row)을 원하는 위치(RowPosition)로 이동하는 메소드
	 * @param  {Object} oGrid 대상그리드
	 * @param  {Number} nOldRow Old행
	 * @param  {Number} nNewRow New행
	 * @return {Number} 	이동한 위치
	 * @example GridEx.moveRow(this.grdList, 1, 4)
	 * @memberof GridEx
	 */
	GridEx.moveRow = function(oGrid, nOldRow, nNewRow)
	{
		var nRow;
		var oDs = oGrid.getBindDataset();
		if (oDs)
		{
			nRow = DatasetEx.moveRow(oDs, nOldRow, nNewRow);
			if (oGrid.selecttype == "multirow")
			{
				oDs.clearSelect();
				oDs.set_rowposition(nRow);
				oDs.selectRow(nRow);
			}
		}
		else
		{
			Util.trace("GridEx.js :: moveRow() => not found bind dataset : " + oGrid);
		}
		
		return nRow;
	}

	
  /**
	* 그리드의 행삭제 메시지Callback함수
	* @private
	* @param  {Grid} sPopupId 메시지창ID
	* @param  {Ojbect} sRtn 반환메지시(버튼index)
	* @example _deleteRowCallback(sPopupId, sRtn)
	* @memberof GridEx
	*/
	GridEx._deleteRowCallback = function(sPopupId, sRtn)
	{
		if (sRtn == 0)
		{
			var oInfo = GridEx[sPopupId];
			GridEx._deleteRow(oInfo.grid, oInfo.config);			
		}		
		delete GridEx[sPopupId];
	}
	
	/**
	* 그리드의 행을 삭제(체크박스 컬럼존재 유무에 따라 구분하여 처리)
	* @private
	* @param  {Grid} oGrid 대상그리드(필수)
	* @param  {Ojbect} checkbox : 체크박스 바인딩 컬럼이 다른경우, skipmsg : 메시지제외처리(선택)
	* @return {Object} 삭제index (체크박스/다건 : 배열, 단건 : 삭제Index)
	* @example GridEx._deleteRow(oGrid, oCfg)
	* @memberof GridEx
	*/
	GridEx._deleteRow = function(oGrid, oCfg)
	{
		var oDs = oGrid.getBindDataset();
		if (oDs)
		{
			oCfg = oCfg || {};
			
			var _this = oDs.parent;
			DatasetEx._checkRowType(oDs);
			
			var sDelMsg 	= this.DELMSG_TEXT;
			var aRow		= -1;
			var aDelRow     = [];
			var sChkColId 	= oCfg.checkbox || DatasetEx._CHECKBOX_COLUMN;
			
			var bSkipMsg 	= oCfg.skipmsg !== false;
			var nChkIndex 	= oGrid.getBindCellIndex("body", sChkColId);
			
			if (nChkIndex >= 0)
			{
				aRow = DatasetEx.findRows(oDs, sChkColId, 1);
				if (aRow.length == 0) // return array
				{
					//return _this.gfn_msgBox("M", NX._getUiMsg("UI023"), {restrict:true}); // "삭제 할 행을 체크하세요."
					return _this.gfn_msgBox("M", Util.getComMsg("I.ZZ.ZZ.0004"), {restrict:true}); // "삭제 할 행을 체크하세요."
				}
				else
				{
					if (bSkipMsg || _this.gfn_msgBox("C", sDelMsg))
					{
						// Dataset 이벤트처리 : disableevent시 Scrollbar생성후 last rowpositon위치 rendering
						// 다건처리를 위한 함수제공 : deleteMultiRows
						if (NX.updatecontrol)
						{
							oDs.deleteMultiRows(aRow);
						}
						else
						{
							oDs.set_enableevent(false);
							for (var i=aRow.length-1; i>=0; i--)
							{
//								if (DatasetEx.getRowType(oDs, aRow[i]) == Dataset.ROWTYPE_INSERT)
//								{
//									oDs.deleteRow(aRow[i]);
//								}
//								else
//								{
//									DatasetEx.setRowType(oDs, aRow[i], DatasetEx.ROWTYPE_DELETE);
//									oDs.setColumn(aRow[i], sChkColId, "0");
//								}
								
								// 2018.03.15 삭제된 상태에서 추가삭제시 Org값으로 원복처리 요청
								switch (DatasetEx.getRowType(oDs, aRow[i]))
								{
									case Dataset.ROWTYPE_INSERT : 
										//oDs.deleteRow(aRow[i]); // 2018.09.05 삭제시 이벤트를 수행하기 위해 삭제정보를 배열로 담아 이벤트가 활성화 된 이후에 삭제수행 처리
										aDelRow[aDelRow.length] = aRow[i];
										break;
										
									case Dataset.ROWTYPE_DELETE : 
										// retreieve -> update -> delete : update 수정된 컬럼값 유지됨(2018.03.19 공통팀요청)
										for(var k=0; k<oDs.colcount; k++)
										{
											var sCurData = oDs.getColumn(aRow[i], k);
											var sOrgData = oDs.getOrgColumn(aRow[i], k);

											if(sCurData != sOrgData) oDs.setColumn(aRow[i], k, oDs.getOrgColumn(aRow[i], k));							
										}										
										//oDs.setColumn(aRow[i], DatasetEx._ROWTYPE_COLUMN, oDs.getOrgColumn(aRow[i], DatasetEx._ROWTYPE_COLUMN))
										//oDs.setColumn(aRow[i], sChkColId, "0");
										break;
								
									default :
										DatasetEx.setRowType(oDs, aRow[i], DatasetEx.ROWTYPE_DELETE);
										oDs.setColumn(aRow[i], sChkColId, "0");
										break;									
								}
							}
							oDs.set_enableevent(true);
							
							// 2018.09.05 삭제시 이벤트를 수행하기 위해 삭제정보를 배열로 담아 이벤트가 활성화 된 이후에 삭제수행 처리
							if(aDelRow.length > 0) oDs.deleteMultiRows(aDelRow);
						}
						
						var bChecked = oGrid.getCellText(-1, nChkIndex);
						if (bChecked) oGrid.setCellProperty("head", nChkIndex, "text", "0");
					}
					// for fire event
	// 				if (oDs.onrowposchanged.length > 0) {
	// 					var eventinfo = new DSRowPosChangeEventInfo;
	// 						eventinfo.oldrow = -1;
	// 						eventinfo.newrow = oDs.rowposition;
	// 					oDs.onrowposchanged.fireEvent(oDs, eventinfo);
	// 				}
				}
			}
			else
			{
				//Util.trace("GridEx.xjs :: deleteRow() => 그리드 사용에 대한 체크박스여부를 확인하세요.");
				if (bSkipMsg || _this.gfn_msgBox("C", sDelMsg))
				{
					if (oGrid.selecttype == "multirow")
					{
						aRow = oGrid.getSelectedDatasetRows();
						if (NX.updatecontrol)
						{
							oDs.deleteMultiRows(aRow);
						}
						else
						{
							oDs.set_enableevent(false);
							for (var i=aRow.length-1; i>=0; i--)
							{
								// 2018.03.15 삭제된 상태에서 추가삭제시 Org값으로 원복처리 요청
								switch (DatasetEx.getRowType(oDs, aRow[i]))
								{
									case Dataset.ROWTYPE_INSERT : 
										//oDs.deleteRow(aRow[i]);
										aDelRow[aDelRow.length] = aRow[i];
										break;
										
									case Dataset.ROWTYPE_DELETE : 
										// retreieve -> update -> delete : update 수정된 컬럼값 유지됨(2018.03.19 공통팀요청)
										for(var k=0; k<oDs.colcount; k++)
										{
											var sCurData = oDs.getColumn(aRow[i], k);
											var sOrgData = oDs.getOrgColumn(aRow[i], k);

											if(sCurData != sOrgData) oDs.setColumn(aRow[i], k, oDs.getOrgColumn(aRow[i], k));							
										}										
										break;
								
									default :
										DatasetEx.setRowType(oDs, aRow[i], DatasetEx.ROWTYPE_DELETE);
										break;									
								}
							}							
							oDs.set_enableevent(true);
							
							if(aDelRow.length > 0) oDs.deleteMultiRows(aDelRow);
						}
					}
					else
					{
						var nCurRow = oDs.rowposition;
						if (NX.updatecontrol)
						{
							if (oDs.deleteRow(nCurRow))
							{
								aRow = nCurRow;
							}
						}
						else
						{
							
							if(DatasetEx.getRowType(oDs, nCurRow) == Dataset.ROWTYPE_INSERT)
							{
								oDs.deleteRow(nCurRow);
							}
							else
							{
								oDs.set_enableevent(false);
								switch (DatasetEx.getRowType(oDs, nCurRow))
								{										
									case Dataset.ROWTYPE_DELETE : 
											// retreieve -> update -> delete : update 수정된 컬럼값 유지됨(2018.03.19 공통팀요청)
											for(var k=0; k<oDs.colcount; k++)
											{
												var sCurData = oDs.getColumn(nCurRow, k);
												var sOrgData = oDs.getOrgColumn(nCurRow, k);
	
												if(sCurData != sOrgData) oDs.setColumn(nCurRow, k, oDs.getOrgColumn(nCurRow, k));							
											}	
										break;
								
									default :
										DatasetEx.setRowType(oDs, nCurRow, DatasetEx.ROWTYPE_DELETE);
										break;									
								}
								
								oDs.set_enableevent(true);
							}

							aRow = nCurRow;
						}
					}
				}
			}
		}
		else
		{
			Util.trace("GridEx.js :: deleteRow() => not found bind dataset : " + oDs);
		}
		
		return aRow;
	}

//	GridEx.restoreRow = function(oGrid, sChkColNm)
//	{
//		var oDs = oGrid.getBindDataset();
//		if (oDs)
//		{
//			var _this = oDs.parent;
//			var sChkColId = sChkColNm || DatasetEx._CHECKBOX_COLUMN;
//			
//			DatasetEx._checkRowType(oDs);
//			
//			// 해당Dataset에 s_chk 컬럼 존재여부 확인 (Binding정보에는 없는 경우는 제외처리)
//			var nChkIndex = oGrid.getBindCellIndex("body", sChkColId);
//			if (nChkIndex >= 0)
//			{
//				// 체크박스 체크하여 처리
//				aRow = DatasetEx.findRows(oDs, sChkColId, 1);					
//				if (aRow == -1)
//				{
//					return this.gfn_msgBox("M", NX._getUiMsg("UI023"), {restrict:true}); // "삭제 할 행을 체크하세요."
////					_this.alert("삭제 할 행을 체크하세요.");
//				}
//				else
//				{
//					var nRowCnt = oDs.getRowCount();
//					var nColCnt = oDs.getColCount();
//					var nRow = -1;
//					for (var i=0, nLen=aRow.length; i<nLen; i++) 
//					{
//						nRow = aRow[i];
//						for (var j=0; j<nColCnt; j++) 
//						{
//							if (oDs.getOrgColumn(nRow,j) != oDs.getColumn(nRow,j))
//							{
//								oDs.setColumn(nRow, j, oDs.getOrgColumn(nRow,j));
//							}
//						}
//						
//						if (!NX.updatecontrol) DatasetEx.setRowType(oDs, nRow, DatasetEx.ROWTYPE_NORMAL);
//					}
//				}
//			}
//			else
//			{
//			}
//		}
//		else
//		{
//			Util.trace("GridEx.js :: restoreRow() => not found bind dataset : " + oDs);
//		}
//	}

	/**
	* 그리드의 삭제행 복원 (수정된 컬럼에 대한 정보는 제외)
	* @param  {object} oGrid 대상그리드 
	* @param  {Dataset} objDsGrid 대상그리드에 바인드된 Dataset
	* @return {Number} 	복원한 건수
	* @example restoreRows(oGrid)
	* @memberof GridEx
	*/
// 		GridEx.restoreRows = function(oGrid)
// 		{
// 			var _this = NX.Analyzer.form(oGrid);
// 			var oDs = _this[oGrid.binddataset];
// 			if (oDs)
// 			{
// 				var nRowCnt = oDs.getRowCount();
// 				var nColCnt = oDs.getColCount();
// 				
// 				for (var i=0; i<nRowCnt; i++) 
// 				{
// 					for (var j=0; j<nColCnt; j++) 
// 					{
// 						if (oDs.getOrgColumn(i,j) != oDs.getColumn(i,j))
// 						{
// 							oDs.setColumn(i, j, oDs.getOrgColumn(i,j));
// 						}
// 					}
// 				}
// 				
// 				for (var i=nRowCnt; i>=0; i--) 
// 				{
// 					if (oDs.getRowType(i) == 2) oDs.deleteRow(i);
// 				}
// 			}
// 		}

	/**
	 * 그리드 소트 및 그룹핑 처리함수
	 * @param {object} o 대상그리드(Grid,Dataset}
	 * @example GridEx.setKeystr(objDs, "S:column0+column0")
	 * @memberof GridEx
	 */ 
	GridEx.setKeystr = function(o, sKeystr, bCurrent)
	{
		var oDs = o.getBindDataset();
		if (oDs) DatasetEx.setKeystr(oDs, sKeystr, bCurrent);
	}

	/**
	 * 그리드와 바인딩된 Dataset의 keystring값을 반환
	 * @param {objects} o 대상그리드(Grid,Dataset}
	 * @param {Boolean} bCurrent 대상그리드(option -> default:true)
	 * @return {String} keystring속성값
	 * @example GridEx.getKeystr(grdList)
	 * @memberof GridEx
	 */ 
	GridEx.getKeystr = function(o, bCurrent)
	{
		return DatasetEx.getKeystr(o.getBindDataset(), bCurrent);
	}

	/**
	 * 그리드 특정cell에 바인딩된 컬럼ID를 얻어오는 함수 (getBindCellIndex())
	 * 단 text -> Expr을 사용하거나, expr 속성의 값은 처리에서 제외
	 * @param {object} o 대상그리드
	 * @example GridEx.getBindColId(this.grdList, 2)
	 * @memberof GridEx
	 */ 
	GridEx.getBindColId = function(o, nCell)
	{
		var sText = Util.trim(o.getCellProperty("body", nCell, "text"));
		return sText.indexOf("bind:") >= 0 ? sText.slice(5) : "";
	}
	
	/**
	 * 그리드밴드의 높이를 구하는 함수
	 * @param {object} obj 	높이를 구할 Grid
	 * @param {String} strBand	text로 저장할 DataSet
	 * @return {Number} 해당밴드의 높이
	 * @example GridEx.getBandHeight(grid,"body")
	 * @memberof GridEx
	 */
	GridEx.getBandHeight = function(o, sBand)
	{
		var aRow = this.getBandRowCount(o, sBand);
		var nHeight	= 0;

		for(var i=0, nLen=aRow.length; i<nLen; i++)
		{
			nHeight += o.getFormatRowSize(aRow[i]);
		}
		return nHeight;
	}

	/**
	 * 그리드밴드에 설정된 현재 Format의 Rows 내 Row 갯수를 배열로 반환하는 함수
	 * @param {object} obj	높이를 구할 Grid
	 * @param {String} strBand	Grid의 밴드
	 * @return {Array} row index를 포함한 배열
	 * @example GridEx.getBandRowCount(grid,"body")
	 * @memberof GridEx
	 */
	GridEx.getBandRowCount = function(o, sBand)
	{
		var nRowCnt = o.getFormatRowCount();
		var aRow	= [];

		for(var i=0, nCnt=o.getFormatRowCount(); i<nCnt; i++)
		{
			if (o.getFormatRowProperty(i, "band") == sBand)
			{
				aRow[aRow.length] = i;
			}
		}
		return aRow;
	}		
	
	/**
	 * 그리드 초기화 함수(서비스호출후 기존결과에 Append처리)
	 * @param {Object} o	대상Grid
	 * @return N/A
	 * @example GridEx.initGrid(grdList)
	 * @memberof GridEx
	 */
	GridEx.initGrid = function(o)
	{
		var oDs = o.getBindDataset();
		if (oDs)
		{
			var bClrKeyString = false, bClrFilterStr = false;
			var sCurKeystring = DatasetEx.getKeystr(oDs);
			var sDftKeystring = DatasetEx.getKeystr(oDs, false);
			if (sCurKeystring != sDftKeystring) 
			{
				bClrKeyString = true;
				DatasetEx.setKeystr(oDs, sDftKeystring);
			}

			var sCurFilterStr = DatasetEx.getFilter(oDs);
			var sDftFilterStr = DatasetEx.getFilter(oDs, false);
			if (sCurFilterStr)
			{
				if (sCurFilterStr != sDftFilterStr) 
				{
					bClrFilterStr = true;
					DatasetEx.setFilter(oDs, sDftFilterStr);
				}
			}
			
//				if (oDs.getColumnInfo("s_chk")) this.clearCheck(obj);
			if (bClrKeyString) 	this.clearSortMark(obj);
			if (bClrFilterStr)
			{
				o._cmmsfilter = "";
				this._clearFilterMark(o);
			}
		}
	}
	
	/**
	* 그리드헤더의 라인수를 리턴하는 함수
	* @param  {Object} 	oGrid	대상그리드객체 배열
	* @return {String} 	그리드 헤더에 대한 csv데이터
	* @example GridEx.getGridMaxRow(arrObjGrid, aTitle)
	* @memberof GridEx
	*/
	GridEx.getGridMaxRow = function(oGrid)
	{
		var nMaxRow = 0;
		for (var i=0; i<oGrid.getCellCount("head"); i++)
		{
			var nCurRow = nexacro.toNumber(oGrid.getCellProperty("head", i, "row"));
			if (nMaxRow < nCurRow) nMaxRow = nCurRow;
		}
		return nMaxRow;
	}

	/**
	 * OrgGrid의 Col사이즈와 동일하게 설정
	 * @private
	 * @memberof GridEx
	 */
	GridEx._setCurColSize = function(oGrid, oOrgGrid)
	{
		var nColCnt = oGrid.getFormatColCount();
		for (var i=0; i<nColCnt; i++)
		{
			// RealColSize수정후 Format변경시 원복
			oGrid.setFormatColProperty(i, "size", oOrgGrid.getRealColSize(i));
		}
	}


	/**
	* 그리드의 현재 format을 반환(공통에서만 사용 : 개발자 사용금지)
	* @private
	* @param  {Object} 	oGrid	그리드객체(필수)
	* @example GridEx._getCurFormatString(oGrid)
	* @memberof GridEx
	*/
	GridEx._getCurFormatString = function(oGrid, sFormatId)
	{
		return "<Formats>" + oGrid.getCurFormatString() + "</Formats>";
// 			var sXML = "<xml version='1.0'>" + oGrid.formats + "</xml>";
// 			var oDom = $.parseXML(sXML);
// 			var oElement = oDom.getElementById(sFormatId);
// 				oElement.setAttribute("id", "default"); // formatId 제거
// 			return "<Formats>" + oElement.outerHTML + "</Formats>";
	}
	
	/**
	 * 그리드 row/col값에 해당하는 cell값을 구하는 함수
	 * @param {Object} 	oGrid 대상그리드object
	 * @param {Number} 	nRow 그리드의 subrow값(default:0)
	 * @param {Number} 	nCol 	그리드의 col값
	 * @param {String} 	sBand cell값을 구할 band(default:body)
	 * @return {Number} Grid의 cell값
	 * @example GridEx.getCellIndex(grd_List, 1, 4, "body")
	 * @memberof GridEx
	 */
	GridEx.getCellIndex = function(oGrid, nRow, nCol, sBand)
	{
		if(Util.isNull(nRow)) nRow = 0;
		if(Util.isNull(sBand)) sBand = "body";
		
		var nCell, nCurRow, nColspan, nCell, nCellCnt=oGrid.getCellCount(sBand);
		for (nCell=0; nCell<nCellCnt; nCell++)
		{
			nCurRow = oGrid.getCellProperty(sBand, nCell, "row");
			if (nCurRow == nRow) break;
		}

		for (var i=0; i<nCol; i+=parseInt(oGrid.getCellProperty(sBand, nCell, "colspan")))
		{
			nCell++;
		}
		
		return nCell;
	}
	
	/**
	 * 그리드헤더이벤트에 대한 바디Cell정보 반환 
	 * 2라인이상의 Header, Body인경우 처리에 대해서 보완해야함.
	 * @private
	 * @param {Object} oGrid 대상그리드
	 * @param {event} e 그리드이벤트객체
	 * @return {Number} CellIndex
	 * @example getBodyCellFromHeadEvent(oGrid, e)
	 * @memberof GridEx
	 */
	GridEx._getBodyCellFromHeadEvent = function(obj, e) 
	{ 
		var nCell = -1;
		var nHeadCellCnt = obj.getCellCount("head"); 
		var nBodyCellCnt = obj.getCellCountr("body"); 
		var nBandGap 	= nHeadCellCnt - nBodyCellCnt;
		var nHeadRowCnt = obj.getCellProperty("head", nHeadCellCnt-1, "row"); 
		var nBodyRowCnt = obj.getCellProperty("body", nBodyCellCnt-1, "row"); 
   
		if (nBandGap < 0) 
		{
			return nCell; 
		}
		
		var nHeadRow = obj.getCellProperty("head", e.cell, "row"); 
		var nHeadCol = obj.getCellProperty("head", e.cell, "col"); 
		for (var i=nBodyCellCnt; i>=0;) 
		{ 
			nBodyRow = obj.getCellProperty("body", i, "row"); 
			nBodyCol = obj.getCellProperty("body", i, "col"); 
			if (nHeadCol == nBodyCol) 
			{
				if (nBandGap == 0 || (nBandGap > 0 && nBodyRow < nHeadRow)) 
				{ 
					nCell = i; 
					break; 
				} 
			}
		}
	}

	/**
	 * 그리드헤더 부분에 대해서 틀고정처리하는 함수
	 * 2라인이상의 Header, Body인경우 처리에 대해서 보완해야함.
	 * @param {Object} oGrid 대상그리드
	 * @param {Number} nCell 그리드cell index
	 * @param {Number} nRow 그리드row index
	 * @return {Array} 반환값
	 * @example GridEx.fixGrid(oGrid, 4)
	 * @memberof GridEx
	 */
	GridEx.fix = function(oGrid, oCfg)
	{
		if (oGrid)
		{
			var sType = oCfg.fixtype || "col";
			switch (sType)
			{
				case "col" : 
					this._fixCol(oGrid, oCfg); 
					GridEx._setFixLine(oGrid, oCfg, {fixtype:sType});
					break;
					
				case "row" : 
					GridEx._setFixLine(oGrid, oCfg, {fixtype:sType});
					this._fixRow(oGrid, oCfg);
					break;
			}
		
			var oDs = oGrid.getBindDataset();
			if (oDs) oDs._clearfixgrid = true;
		}
	}
	
	GridEx._fixRow = function(oGrid, oCfg)
	{
		oGrid.setFixedRow(oCfg.row);
	}

	GridEx._fixCol = function(oGrid, oCfg)
	{
		oGrid.set_enableevent(false);
		oGrid.set_enableredraw(false);
		
		var nCell = oCfg.cell;
		var nEvntCol = oGrid.getCellProperty("head", nCell, "col");
		var nEvntRow = oGrid.getCellProperty("head", nCell, "row");
		if (nEvntRow == 0)
		{
			var iPos = oGrid.getCellProperty("head", nCell, "col");
				iPos = iPos + nexacro.toNumber(oGrid.getCellProperty("head", nCell, "colspan")) - 1;

// 				for (var i=0, nCellCnt=oGrid.getCellCount("head"); i<nCellCnt; i++) 
// 				{
// 					if (nexacro.toNumber(oGrid.getCellProperty("head", i, "col")) <= iPos)
// 					{
// 						oGrid.setCellProperty("head", i, "background", "lightgrey");
// 					}
// 				}
			
			for (var i=0; i<=iPos; i++)
			{
				oGrid.setFormatColProperty(i, "band", "left");
			}
			
			oGrid._fixcol = iPos;
		}
		else 
		{
			for (var i=0; i<=nEvntCol; i++)
			{
				oGrid.setFormatColProperty(i, "band", "left");
			}

//				var iCell = 0, iCol	= 0, iColL = 0;
// 				for (var i=0; i<=nCell; i++)
// 				{
// 					iCell 		= i;
// 					iCol 		= oGrid.getCellProperty("head", i, "col");
// 					iColSpan 	= oGrid.getCellProperty("head", i, "colspan");
// 					iColL 		= iCol + (iColSpan - 1);
// 					if (nEvntCol >= iCol) oGrid.setCellProperty("head", iCell, "background", "lightgrey");
// 				}
			
			oGrid._fixcol = nEvntCol;
		}
		
// 			oGrid._cellsizebandtype = oGrid.cellsizebandtype;
// 			oGrid.set_cellsizebandtype("allband");

		oGrid.set_enableevent(true);
		oGrid.set_enableredraw(true);
	}
	
	// 틀고정 그리드 여부 반환
	GridEx.isFixedGrid = function(obj)
	{
		return  obj._fixed_height > 0 || !Util.isNull(obj._fixcol);
	}
	
	// 틀고정(행)여부 체크
	GridEx.isFixedRow = function(obj)
	{
		return obj._fixed_height > 0;
	}
	
	// 트리셀포함여부 반환
	GridEx.isTreeGrid = function(obj)
	{
		return obj._hasTree;
	}
	
	// 틀고정전 clear처리시 nCell에 값설정
	GridEx.clearFix = function(obj, oCfg)
	{
		if (!oCfg) oCfg = {};
		var sType = oCfg.fixtype || "both";
		switch (sType)
		{
			case "col" 	: 
			case "both" :
				obj.set_enableevent(false);
				obj.set_enableredraw(false);
				
				var nLeftBand = -1;
				for (var i=0, nCnt=obj.getCellCount("head"); i<nCnt; i++)
				{
					var sBand = Util.trim(obj.getFormatColProperty(i, "band")).toLowerCase();
					if (sBand == "left")
					{
						nLeftBand = i;				
//							obj.setCellProperty("head", i, "background", "");
					}
				}

				var oOrgSizeInfo = {};
				var oBandIdxInfo = {};
				for (var i=obj.getFormatColCount()-1; i>=0; i--)
				{
					var nCurColSize = obj.getRealColSize(i); 	// false인자 설정시 반환값 오류
					var nOrgColSize = obj.getFormatColSize(i);

					if (nLeftBand >= 0 && nLeftBand >= i) oBandIdxInfo[i] = "body";
					if (nOrgColSize != nCurColSize)	oOrgSizeInfo[i] = nCurColSize;
				}
				
				// setRealColSize()설정시 ColSize가 원복됨, setFormatColProperty()함수호출시 변경된사이즈 Org값으로 설정(redraw와 무관)
//					for (var i in oOrgSizeInfo)	obj.setFormatColProperty(i, "size", oOrgSizeInfo[i]);
				for (var i in oBandIdxInfo)	obj.setFormatColProperty(i, "band", oBandIdxInfo[i]);
				
				obj.set_enableredraw(true);
				obj.set_enableevent(true);
				
// 					if (obj._cellsizebandtype)
// 					{
// 						obj.set_cellsizebandtype(obj._cellsizebandtype);
// 						obj._cellsizebandtype = "";
// 					}
				
				obj._fixcol = "";
//					break;
			
			case "row" 	: 
			case "both" :
				obj.setFixedRow(-1);
				break;
		}
		
		var oDs = obj.getBindDataset();
		if (oDs) oDs._clearfixgrid = false;
		
		GridEx._clearFixLine(obj, {fixtype:sType});
	}

	/**
	 * 그리드 헤더를 클릭했을때 소트처리기능을 구현해주는 함수
	 * 소트순서 : 오름차순 -> 내림차순 -> default Sort처리
	 * @param {Object} obj	높이를 구할 Grid
	 * @param {event} e	Grid클릭이벤트정보
	 * @example GridEx.sort(grid00, e)
	 * @memberof GridEx
	 */
	
	GridEx.sort = function(obj, e)
	{
		var oDs = obj.getBindDataset();
		var nHorizonPos = obj.hscrollbar ? obj.hscrollbar.pos : 0;
		var sHeaderTitle = Util.trim(obj.getCellProperty("head", e.cell, "text"));

		if (Util.isNull(sHeaderTitle)) sHeaderTitle = "";

		//  해당하는 셀의 헤더의 소트마크를 추가 또는 변경.
		var sFlag 	= "+";
		var bMerge	= obj.getCellProperty("head", e.cell, "colspan") > 1 ? true : false;
		var bShow   = obj.getCellProperty("head", e.cell, "expandshow") == "show"  ? true : false;
		var sMark 	= obj.getCellProperty("head", e.cell, "expandimage");
		
		if(!bShow) return; 
		if (sHeaderTitle == "" && e.cell == 0) return;
		
		switch (sMark)
		{
			case GridEx._CONST_ASC_IMG 	: sFlag = "-"; 	break;
			case GridEx._CONST_DESC_IMG 	: sFlag = "_"; 	break;
			case GridEx._CONST_SORT_IMG 	: sFlag = "+"; 	break;
		}
		
		GridEx._clearSortMark(obj);
		
		if(!Util.isNull(oDs._keystrxml))
		{
			oDs._keystrxml = "";
			sFlag 	= "+";
		}
		
		switch (sFlag)
		{
			case "-" :
				obj.setCellProperty("head", e.cell, "expandimage",GridEx._CONST_DESC_IMG);
				break;
			case "+" :
				obj.setCellProperty("head", e.cell, "expandimage",GridEx._CONST_ASC_IMG);
				break;
			case "_" :
				obj.setCellProperty("head", e.cell, "expandimage",GridEx._CONST_SORT_IMG);
				break;				
		}
		
		//updateSortGroup() 메소드를 수행하면 onrowsetchanged() 이벤트가 발생.
	// 	if (strInitHeader == "") {
	// 		obj.setCellProperty("head", 0, "background", "URL('theme::menu_icon02.png') center middle");
	// 	}
		var sKeystring = "";
		
		if (sFlag == "_")
		{
			sKeystring = Util.trim(oDs.keystring_default);
		}
		else {
			if (bMerge)
			{
				var nSortSpan 	= obj.getCellProperty("head", e.cell, "colspan");
				var nSortCol	= obj.getCellProperty("head", e.cell, "col");
				var nBodyCnt	= obj.getCellCount("body");

				for (var i=0; i<nBodyCnt; i++)
				{
					if ((obj.getCellProperty("body", i, "col") >= nSortCol) && 
						 obj.getCellProperty("body", i, "col") < (Math.abs(nSortCol) + Math.abs(nSortSpan)))
					{
						if (obj.getCellProperty("body", i, "text").length > 0) 
						{
							var sColId = obj.getCellProperty("body", i, "text");
							if (strColId.indexOf("bind:") < 0) continue;
							strColId = sColId.slice(5);
							sKeystring += sFlag + sColId;
						}
					}
				}
			}
			else
			{
				var sColId = String(obj.getCellProperty("body", e.col, "text"));
				if (sColId.indexOf("bind:") >= 0)
				{
					sColId = sColId.slice(5); // binding컬럼ID
					sKeystring = sFlag + sColId;
				}
			}
		}
		
		// for initialize about multisorting info
		// 유지정보에 filter와 같이 정보를 저장하지는 않았음. sort의 경우 조회데이터의 결과가 변경되지 않기때문
//			oDs._keystrxml = "";
		
		obj.set_enableevent(false);
		oDs.set_enableevent(false);

		DatasetEx.setKeystr(oDs, "S:" + sKeystring, true);
		//oDs._keystrxml = "S:" + sKeystring;
		
		obj.set_enableevent(true);
		oDs.set_enableevent(true);

		// Sort처리후 Position위치 설정: 이벤트 발생(Master/Detail Grid)
		if (obj.selecttype == "multirow")
		{
			oDs.clearSelect();
			oDs.set_rowposition(0);
			oDs.selectRow(0);
		}
		else
		{
			oDs.set_rowposition(0);
		}
		
		if (obj.hscrollbar && (obj.hscrollbar.pos != nHorizonPos)) obj.hscrollbar.set_pos(nHorizonPos);
	}
    
	
	GridEx._clearSortMark = function(obj)
	{
		for (var i = 0; i < obj.getCellCount("head"); i++) 
		{
			obj.setCellProperty("head", i, "expandimage", this._CONST_SORT_IMG);
		}
	}

	GridEx._clearFilterMark = function(obj)
	{
		for (var i = 0; i < obj.getCellCount("head"); i++) 
		{
			sHeaderTitle = new String(obj.getCellProperty("head", i, "text"));
			if (sHeaderTitle.indexOf(this._CONST_FILTER_MARK) >= 0)
			{
				// filter의 경우 동일컬럼을 여러번 사용가능하기 때문에 mark를 전체clear후 누적하여 표기
				sHeaderTitle = sHeaderTitle.replace(/▶/g, "");
				obj.setCellProperty("head", i, "text", sHeaderTitle);
			}
		}
	}

	/**
	 * Grid 체크박스를 이용한 전체선택/해제(현재값 기준으로 반대로 처리)
	 * @param {Object} obj Grid Object
	 * @param {Array} nCell 그리드 체크박스 헤더Cell Index값(cellmovingtype속성 "col"인경우 주의)
	 * @example GridEx.clearCheck(grdList, [0,2,3])
	 * @memberof GridEx
	 */
	GridEx.clearCheck = function(obj, aCellIndex)
	{
		if (obj.readonly) return;			
		if (!aCellIndex)
		{
			var nCell = obj.getBindCellIndex("body", DatasetEx._CHECKBOX_COLUMN);
			if (nCell >= 0)
			{
				var sCellType = Util.toString(obj.getCellProperty("head", nCell, "displaytype"));
				if (sCellType.toUpperCase() == "CHECKBOX") obj.setCellProperty("head", nCell, "text", false);
			}
		}
		else
		{
			for (var i=0, nCnt=aCellIndex.length; i<nCnt; i++)
			{
				var sCellType = Util.toString(obj.getCellProperty("head", i, "displaytype"));
				if (sCellType.toUpperCase() == "CHECKBOX") obj.setCellProperty("head", aCellIndex[i], "text", false);
			}
		}
	}
	 
	/**
	 * Grid 체크박스를 이용한 전체선택/해제(현재값 기준으로 반대로 처리)
	 * @param {Object} obj				Grid Object
	 * @param {Number} nCell 			체크박스 cell index값
	 * @param {Boolean} sDefaultValue 	체크박스 전체를 설정할 값(option) "0" 또는 "1"로 지정
	 * @param {Object} oCfg 			처리조건(option : datasetevent)
	 *                                  datasetevent 여부를 boolean값으로 설정
	 * @example GridEx.setCheckAll(obj, e)
	 * @memberof GridEx
	 */
	GridEx.setCheckAll = function(obj, nCell, sDefaultValue, oCfg)
	{
		if (nCell < 0) return;
		if (obj.readonly) return;
		
		if (Util.isNull(oCfg)) oCfg = {};
		if (Util.isNull(nCell))	nCell = obj.getBindCellIndex("body", DatasetEx._CHECKBOX_COLUMN);
		
		var bDatasetEvent = oCfg.datasetevent === false ? false : true;
		var bSkipCellType = oCfg.skipcelltype === true;
		var sCellType = Util.toString(obj.getCellProperty("head", nCell, "displaytype"));
		if (!bSkipCellType && sCellType.toUpperCase() != "CHECKBOX") return;
		
		var isCheckAll 	= obj.getCellText(-1, nCell);
		var oBindDs 	= obj.getBindDataset();
		var nTargetCell = oCfg.targetcell || nCell;
		var sColId 		= obj.getCellProperty("body", nTargetCell, "text");
		if (sColId.indexOf("bind:") >= 0)
		{
			sColId		= sColId.slice(5);
			isCheckAll 	= sDefaultValue == undefined ? (Util.isTrue(isCheckAll) ? "0" : "1") : sDefaultValue;

			obj.set_enableevent(false);
			if (!bDatasetEvent) oBindDs.set_enableevent(bDatasetEvent);
			for (var i=0, nRowCnt=oBindDs.getRowCount(); i<nRowCnt; i++)
			{
				oBindDs.setColumn(i, sColId, isCheckAll);
			}
			obj.setCellProperty("head", nCell, "text", isCheckAll);
			if (!bDatasetEvent) oBindDs.set_enableevent(true);
			obj.set_enableevent(true);
		}
	}


	/**
	 * 그리드 컬럼필터링 관련 처리함수(X)
	 * @private
	 * @param {Object} oGrid 대상그리드
	 * @param {Dataset} objDsFilter 필터링관련정보 Dataset
	 * @return N/A
	 * @example GridEx.setGridFilter(oGrid, objDs)
	 * @memberof GridEx
	 */
	GridEx._setColFilter = function(oGrid, oDsFilter)
	{
		for (var i=1, nCellCnt=oGrid.getCellCount("body"); i<nCellCnt; i++) 
		{
			var nRow = oDsFilter.findRow("grid_index", i);
			if (nRow < 0)
			{
				oGrid.setRealColSize(i, 0);
			}
			else
			{
				var nOrgSize = oGrid.getFormatColSize(i);
				oGrid.setRealColSize(i, nOrgSize);
			}
		}
		
		oGrid.colfilter = "Y"; // userproperty
	}

	/**
	 * 그리드 컬럼필터링 관련 초기화함수(chk_kdm)
	 * @param {Object} oGrid 대상그리드
	 * @return N/A
	 * @example GridEx.initColFilter(oGrid)
	 * @memberof GridEx
	 */
	GridEx.initColFilter = function(oGrid)
	{
		for (var i=1, nCellCnt=oGrid.getCellCount("body"); i<nCellCnt; i++)
		{
			var nSize = oGrid.getRealColSize(i, 0);
			if (nSize == 0)
			{
				var nOrgSize = oGrid.getFormatColSize(i);
				oGrid.setRealColSize(i, nOrgSize);
			}
		}
		
		oGrid.colfilter = ""; // userproperty
	}
	
	/**
	 * 내부clipboard dataset에서 값반환
	 * @private
	 * @example GridEx._getClipboardData()
	 * @memberof GridEx
	 */
	GridEx._getClipboardData = function()
	{
		var sRtnData = "";
		if (NX.isruntime)
		{
			sRtnData = String(system.getClipboard("CF_UNICODETEXT").replace(",", ""));
		}
		else
		{
			var oDs = NX.getApp().gdsStorage;
			var nRow = oDs.findRow("type", "clipboard");
			if (nRow >= 0) sRtnData = oDs.getColumn(nRow, "value");
		}
		return sRtnData;
	}
	
	/**
	 * 내부clipboard dataset에서 값설정
	 * @private
	 * @param {String} 	 value	저장하려는값 
	 * @example GridEx._setClipboardData(grd_list, objDs, "PASTE")
	 * @memberof GridEx
	 */
	GridEx._setClipboardData = function(value)
	{
		if (NX.isruntime)
		{
			system.clearClipboard();
			system.setClipboard("CF_UNICODETEXT", value);
		}
		else
		{
			var oDs = NX.getApp().gdsStorage;
			var nRow = oDs.findRow("type", "clipboard");
			if (nRow >= 0)
			{
				oDs.setColumn(nRow, "value", value);
			}
			else
			{
				nRow = oDs.addRow();
				oDs.setColumn(nRow, "type", "clipboard");
				oDs.setColumn(nRow, "value", value);
			}
		}
	}

	GridEx.__getCopyData = function(obj)
	{
		var sClip = "";
		var nStartRow = parseInt(obj.selectstartrow);
		var nEndRow = parseInt(obj.selectendrow);
		var nStartCol = parseInt(obj.selectstartcol);
		var nEndCol = parseInt(obj.selectendcol);
		
		for (var i=nStartRow; i<=nEndRow; i++)
		{
			for (var j=nStartCol; j<=nEndCol; j++)
			{
				sClip += Util.trim(obj.getCellValue(i,j)) + (j<obj.selectendcol ? GridEx._EXCEL_COL_DELIMITER_ : "");
			}
			
			if (i < obj.selectendrow)
			{
				sClip += GridEx._EXCEL_ROW_DELIMITER_;
			}
		}
		sClip += "\r\n";
		return sClip;
	}

	/**
	 * 그리드 COPY&PASTE 기능(제한사용)
	 * @private
	 * @param {Grid} 	obj		대상그리드
	 * @param {String} 	sType	처리구분값 ("copy","cut","paste") 
	 * @param {Object}  oCfg	설정값(속성:editcheckskip) : {editcheckskip:false}
	 * @example GridEx.copy2paste(this.grdList, "paste")
	 * @memberof GridEx
	 */
	GridEx._copy2paste = function(obj, sType, oCfg)
	{
		var oDs = obj.getBindDataset();
		if (!oCfg) oCfg = {};
		
		switch (sType.toLowerCase())
		{
			case "copy" : 
				var sClip = GridEx.__getCopyData(obj);
				GridEx._setClipboardData(sClip);
				break;
				
			case "cut" : 
				var sClip = "", sText;
				for (var i=obj.selectstartrow; i<=obj.selectendrow; i++)
				{
					for (var j=obj.selectstartcol; j<=obj.selectendcol; j++)
					{
						sClip += obj.getCellValue(i,j) + (j<obj.selectendcol ? GridEx._EXCEL_COL_DELIMITER_ : "");
						sText = Util.trim(obj.getCellProperty("body", j, "text"));
						if (sText.indexOf("bind:") >= 0)
						{
							oDs.setColumn(i, sText.slice(5), "");
						}
						else
						{
							obj.setCellPos(j);
							obj.showEditor(true);
							obj.setEditText("");
							obj.showEditor(false);
						}				
						oDs.set_rowposition(i);
					}
					
					if (i < obj.selectendrow) sClip += GridEx._EXCEL_ROW_DELIMITER_;
				}
				
				sClip += "\r\n";
				GridEx._setClipboardData(sClip);
				break;
				
			case "paste" : 
			    //IE 브라우저인 경우 클립보드 사용으로 인한 에디터박스 자체에서 붙여넣기가 되는 경우에는 중복 붙여넣기 현상이 있기 때문에 에디터박스가 활성화 되어있는 경우에는 공통에서 붙여넣기 기능 사용안함 (2018.12.28)
			    if (nexacro.Browser == "Edge" || nexacro.Browser == "IE") 
				{
                     var nCaret = obj.getEditCaret();
	                 if(!Util.isNull(nCaret)) return;                        				
				}				
				
				var bAddrow 	= (obj.pasteAddrow == "false") ? false : true;
				var nGrdCellCnt = obj.getCellCount("body");
				var nGrdCellPos = obj.getCellPos();
				var nRowPos 	= parseInt(obj.selectstartrow);//oDs.rowposition == -1 ? 0 : oDs.rowposition;
				var nDsRowCnt 	= oDs.getRowCount();
				var sText 		= GridEx._getClipboardData();
				var aText 		= sText.split(GridEx._EXCEL_ROW_DELIMITER_);
				
				var isEditChkSkip = oCfg.editcheckskip || false;
				
				// 마지막 라인구분자에 대한 보정을 위해서 length-1처리
				var nDataCnt	= 0;
				var aColText 	= [];
				var sColText    = "";
				for (var i=0; i<aText.length; i++)
				{
					sColText = aText[i];
					if(Util.isNull(sColText)) continue;
					aColText = sColText.split(GridEx._EXCEL_COL_DELIMITER_);
					
					// Dataset row count보다 현재rowposition이 작은 경우
					if (nRowPos > nDsRowCnt-1 || nDsRowCnt <= 0) // nDsRowCnt
					{
						if(!bAddrow) continue;
						var nAddrow = DatasetEx.addRow(oDs);//oDs.addRow();
						oDs.set_rowposition(nAddrow);
						nDsRowCnt++;
					}
					else
					{
						oDs.set_rowposition(nRowPos);
					}
					
					var nLoopCnt = (nGrdCellPos + (aColText.length - 1)); // split함수 반환값관련 감산처리
					if (nLoopCnt > nGrdCellCnt) nLoopCnt = nGrdCellCnt;
					
					for (var j=nGrdCellPos; j<=nLoopCnt; j++)
					{
						var sBinding  = Util.trim(obj.getCellProperty("body", j, "text"));
						var sEdittype = Util.trim(obj.getCellProperty("body", j, "edittype"));
						var sDisplaytype = Util.trim(obj.getCellProperty("body", j, "displaytype"));

						if ((sEdittype == "" || sEdittype == "none") && !isEditChkSkip) continue;

						if (sBinding.indexOf("bind:") >= 0)
						{
							var sColId = sBinding.slice(5);
							if(sDisplaytype == "combo")
							{
							   var sCombodataset = obj.getCellProperty("body", j, "combodataset");
							   var sComboCodeCol = obj.getCellProperty("body", j, "combocodecol");
							   var sComboDataCol = obj.getCellProperty("body", j, "combodatacol");

							   var oTopFrom = NX.getScriptForm(obj);

			  			       var oComDataset = oTopFrom.objects[sCombodataset];
							   var sText = aColText[nDataCnt];

							   if(Util.isNull(sText)) continue;
							   
							   sText = sText.trim();

							   sValue = oComDataset.lookup(sComboDataCol,sText,sComboCodeCol);

							   if(Util.isNull(sValue))  sValue = sText;
							} else if(sDisplaytype == "number")
							{
								sValue = aColText[nDataCnt];
								if(sValue.indexOf("," > -1)) sValue = nexacro.replaceAll(sValue,",","");
							}
						    else
						    {
						        sValue = aColText[nDataCnt];
								sValue = Util.rtrim(sValue);
						    }
							oDs.setColumn(oDs.rowposition, sColId, sValue);

							nDataCnt++;
						}
					}
					nRowPos++;
					nDataCnt = 0;
				}
				return true;
				break;
		}
	}
	
	/**
	 * Grid의 Row를 Select 하는 함수(for multirow selecttype)
	 * @param {Grid} oGrid	Select 하는 Grid
	 * @param {Number/Array} nRow	Select 하려는 Row or Row Array
	 * @param {Boolen} bClear	기존 Select 해제 여부(Default true)
	 * @return {void}
	 * @example GridEx.selectRows(grd_Detail, [1,5], true)
	 * @memberof GridEx
	 */
	GridEx.selectRows = function(oGrid, nRow, bClear)
	{
		if (oGrid.selecttype == "multirow")
		{
			var oDs = oGrid.getBindDataset();
			if (oDs)
			{
				if (bClear != false) oDs.clearSelect();

				if (typeof nRow == "number")
				{
					if ((oDs.getRowCount()-1) >= nRow)
					{
						oGrid.selectRow(nRow);
						oDs.set_rowposition(nRow);
					}
				}
				else
				{
					nRow.sort();	// Array 정렬
					for (var i=0; i<nRow.length; i++)
					{
						if ((oDs.getRowCount()-1) >= nRow[i])
						{
							oGrid.selectRow(nRow[i]);
							if (i == 0) oDs.set_rowposition(nRow[i]);
						}
					}
				}
			}
		}
	}
	
	/**
	 * Grid의 선택된 Body Column index의 해당하는 Header의 CellIndex를 반환
	 * @param {Grid} oGrid	Select 하는 Grid
	 * @param {Number} nBodyCol	Body밴드의 컬럼index
	 * @param {Number} nBodyCol	Body밴드의 RowIndex
	 * @return {Number} Header cell의 index
	 * @example GridEx.getHeadCell(grd_Detail, 2, 2)
	 * @memberof GridEx
	 */
	GridEx.getHeadCell = function(oGrid, nBodyCol, nBodyRow)
	{
		var nHeadCellCnt 	= oGrid.getCellCount("head");
		var nBodyCellCnt 	= oGrid.getCellCount("body");
		var nHeadLstRow		= parseInt(oGrid.getCellProperty("head", nHeadCellCnt-1, "row"));
		var nBodyLstRow 	= parseInt(oGrid.getCellProperty("body", nBodyCellCnt-1, "row"));
		var nCellIndex 		= -1;
		for (var i=0; i<nHeadCellCnt; i++)
		{
			var nCol = oGrid.getCellProperty("head", i, "col");
			var nHeadRow = oGrid.getCellProperty("head", i, "row");
			
			if (nHeadLstRow == nBodyLstRow) // Head, Body라인이 동일한 경우
			{
				if (nHeadRow > nBodyRow) break;
			}
			else if (nHeadLstRow > nBodyLstRow) // Head가 Body라인보다 많은경우
			{
				// 전체Head라인 - 현재검색중인 Body라인 < 현재Head라인
				if (nHeadLstRow - (nBodyLstRow - nBodyRow) < nHeadRow) break;
			}
			else 
			{
				Util.trace("GridEx.xjs :: getHeadCell() 예외상황발생 확인요 Grid Name = " + oGrid.name); // 해당경우가 발생할 경우 제한사항 추가해야함
			}
			
			if (nCol == nBodyCol) nCellIndex = i;
		}
		
		return nCellIndex; // 헤드부분이 Merage된 형태의 셀에 대한 처리는 제외
	}
	
	GridEx._isMergeCell = function(obj, nFixCol, oCfg)
	{
		var bMerge = true, nSvRow, nCol, nColspan;
		for (var i=0, nCellCnt=obj.getCellCount("head"); i<nCellCnt; i++)
		{
			nCol = obj.getCellProperty("head", i, "col");
			nRow = obj.getCellProperty("head", i, "row");
			nColspan = obj.getCellProperty("head", i, "colspan");
			
			if (i == 0) nSvRow = nRow;
			// TODO. merge되는 cell중에 마지막cell의 경우 가능 [col+colspan == col]
			if (nFixCol == nCol && nColspan == 1) bMerge = false;
			if (nSvRow != nRow && bMerge == true) return bMerge;
			
			nSvRow = nRow;
		}
		
		return bMerge;
	}
	
	/**
	 * Grid의 Line처리를한 Static를 반환
	 * @private
	 * @param {Grid} obj 대상Grid
	 * @param {String} sType	LineType
	 * @return {Object} Static객체
	 * @example GridEx._getFixSeparator(grd_Detail, "row")
	 * @memberof GridEx
	 */
	GridEx._getFixSeparator = function(obj, sFixType)
	{
		return sFixType ? obj.parent.components[(sFixType == "row" ? GridEx._FIX_ROW_PREFIX_ : GridEx._FIX_COL_PREFIX_) + obj.name] : "";
	}

	/**
	 * Grid의 Line처리를한 Static동적 생성&반환
	 * @private
	 * @param {Grid} obj 대상Grid
	 * @param {Object} oCfg	속성객체(type:optional)
	 * @return {Object} Static객체
	 * @example GridEx._getFixSeparator(grd_Detail, "horizontal")
	 * @memberof GridEx
	 */
	GridEx._genFixSeparator = function(oSrc, oCfg)
	{
		var sType = oCfg.fixtype || "row";
		var pThis = oSrc.parent;
		var oComp = GridEx._getFixSeparator(oSrc, sType);
		if (!oComp)
		{
			if (sType == "row")
			{
				oComp = new Static(GridEx._FIX_ROW_PREFIX_ + oSrc.name, "absolute", oSrc.getPixelLeft(), oSrc.getPixelTop(), oSrc.getPixelWidth(), 1, oSrc.getPixelRight(), null);
				pThis.addChild(oComp.name, oComp);
				oComp.show();
				oComp.style.set_background("#988068");
			}
			else
			{
				oComp = new Static(GridEx._FIX_COL_PREFIX_ + oSrc.name, "absolute", oSrc.left, oSrc.top, 1, oSrc.height, null, oSrc.bottom);
				pThis.addChild(oComp.name, oComp);
				oComp.show();
				oComp.style.set_background("#988068");
			}
		}
		return oComp;
	}
	
	/**
	 * Grid의 틀고정Line invisible처리
	 * @private
	 * @param {Grid} obj 대상Grid
	 * @example GridEx._clearFixLine(grd_Detail, "horizontal")
	 * @memberof GridEx
	 */
	GridEx._clearFixLine = function(obj, oCfg)
	{
		var sType = oCfg.fixtype || "both";
		switch (sType)
		{
			case "col" 	:
			case "both" :
				if (obj.__fixedcolline)
				{
					var oVLine = GridEx._getFixSeparator(obj, "col");
					if (oVLine)
					{
						oVLine.set_visible(false);
						obj.__fixedcolline = "";
					}
				}
//					break;
		
			case "row" 	:
			case "both" :
				if (obj.__fixedrowline)
				{
					var oHLine = GridEx._getFixSeparator(obj, "row");
					if (oHLine)
					{
						oHLine.set_visible(false);
						obj.__fixedrowline = "";
					}
				}
				break;
		}
	}

	/**
	 * Grid의 틀고정Line 설정
	 * @private
	 * @param {Grid} obj 대상Grid
	 * @param {Object} e 이벤트객체
	 * @param {Object} oCfg	속성객체(type:optional)
	 * @example GridEx._clearFixLine(grd_Detail, "horizontal")
	 * @memberof GridEx
	 */
	GridEx._setFixLine = function(obj, e, oCfg)
	{
		var sType = oCfg.fixtype;			
		switch (sType)
		{
			case "row" 	: 
			case "both" : 
				var nVscrollWidth = obj.vscrollbar && obj.vscrollbar.visible ? parseInt(obj.vscrollbar.width) : 0;
				var pThis = obj.parent;
				if (pThis)
				{
					var oLine = GridEx._genFixSeparator(obj, {fixtype:"row"});
					if (oLine)
					{
						var oRect = obj.getCellRect(e.row, e.cell);
						if (oRect)
						{
							obj.__fixedrowline = e.row;
							oLine.set_left(obj.getOffsetLeft());
							if(!Util.isNull(obj.getPixelRight())) oLine.set_right(obj.getPixelRight() + nVscrollWidth);
							if(!Util.isNull(obj.getPixelWidth()))  oLine.set_width(obj.getPixelWidth() - nVscrollWidth);
							oLine.set_top(obj.getOffsetTop() + oRect.bottom); // scroll관련 position변경됨
//								oLine.set_top(obj.getOffsetTop() + (oRect.bottom - (obj._toprowpos[0] * obj.getFormatRowSize(0)))); // scroll관련 position변경됨
//								oLine.set_height(1);
							oLine.set_visible(true);
						}
					}
				}
				break;
				
			case "col" 	:
			case "both" : 
				var nHscrollHeight = obj.hscrollbar && obj.hscrollbar.visible ? parseInt(obj.hscrollbar.height) : 0;
				var pThis = obj.parent;
				if (pThis)
				{
					var oLine = GridEx._genFixSeparator(obj, {fixtype:"col"});
					if (oLine)
					{
						var oRect = obj.getCellRect(e.row, e.cell);
						if (oRect)
						{
							obj.__fixedcolline = e.col;
							oLine.set_left(obj.getOffsetLeft() + oRect.right);
							oLine.set_top(obj.top);
							
							if (obj.bottom)
							{
								oLine.set_bottom(parseInt(obj.bottom) + nHscrollHeight);
							}
							else
							{
								oLine.set_height(parseInt(obj.height) - nHscrollHeight);
							}
							
//								oLine.set_width(1);
							oLine.set_visible(true);
						}
					}
				}
				break;
		}
	} 
	
	/**
	 * Grid의 displaytype 속성이 'normal', 'text', 'number', 'currency'일 경우에 edit의 형태를 출력할지 여부를 설정
	 * @param {Grid} obj 대상Grid
	 * @param {String} sDisplayType 출력형태(default : edit)
	 * @example GridEx.setEditDisplay(this.grdList, "display")
	 * @memberof GridEx
	 */
	GridEx.setEditDisplay = function(obj, sDisType)
	{
		if (Util.isNull(sDisType)) sDisType = "edit";
		
		var sEditType, sProp;
		for (var i=0, nCellCnt = obj.getCellCount("body"); i<nCellCnt; i++)
		{
			sEditType = Util.trim(obj.getCellProperty("body", i, "edittype"));
			if (sEditType != "none")
			{
				obj.setCellProperty("body", i, "editdisplay", sDisType);
				if (sEditType.indexOf("calendar") >= 0) obj.setCellProperty("body", i, "calendardisplay", sDisType);
				if (sEditType.indexOf("combo") >= 0) 	obj.setCellProperty("body", i, "combodisplay", sDisType);
			}
		}
	}
	
	GridEx.isLastOver = function (obj, e)
	{
		return e.type.indexOf("lastover") >= 0;		
	}
	
	GridEx.adjustHeight = function(obj, nRowCnt)
	{
		var nHeadHeight = obj.getRealRowFullSize("head");
		var nBodyHeight = nRowCnt * obj.getRealRowSize(0);
		var nSummHeight = obj.getRealRowFullSize("summ");
		
		var bHorizonScrl = obj.hscrollbar.visible;
		if (bHorizonScrl === true)
		{
			nSummHeight += (obj.hscrollbar.height + 2);
		}
		
		obj.set_enableredraw(false);
		obj.setOffsetHeight(nHeadHeight + nBodyHeight + nSummHeight);
		obj.set_enableredraw(true);
		
		obj.parent.resetScroll();
	}
	
	/**
	 * Grid Current Row Object형태 return (특수문자 사용금지)
	 * @param {Grid} 대상 Grid
	 * @return {String} 그리드 Row정보를 문자열로 반환
	 * @see GridEx.rowToStr(this.grdList);
	 */
	GridEx.rowToStr = function(obj)
	{
		if (obj != null) {
			var dsObj = obj.getBindDataset();
			for (var i = 0; i < dsObj.getColCount(); i++) {
				var sId = dsObj.getColID(i);
				var sTmp = dsObj.getColumn(0, i);
					if (!Util.isNull(sTmp) && Util.isString(sTmp) && sId != "imgData") {
					dsObj.setColumn(0, i, nexacro.replaceAll(sTmp, '"', '&quot;'));
				}
			}
		}
		return DatasetEx.getDsRowToJsonStr(obj.getBindDataset());
	}
	
	/**
	 * Json String을 객체로 변환하는 함수(GridEx.rowToStr()와 pair로 동작함)
	 * @param {String} sJsonStr 대상 문자열
	 * @return {Object} Key에 해당하는 Value값으로 구성된 객체
	 * @see GridEx.strToObj("~~~");
	 */
	 GridEx.strToObj = function(sJsonStr)
	 {
		var oRtn = Util.decodeJson(sJsonStr);
		if (oRtn != null) {
			for (p in oRtn) {
				var sTmp = oRtn[p];
				if (!Util.isNull(sTmp) && Util.isString(sTmp) && p != "imgData") {
					oRtn[p] = nexacro.replaceAll(sTmp, '&quot;', '"');
				}
			}
		}
		return oRtn
	 }
	
	/**
	 * (미사용)Grid의 데이터를 XML(결재용)데이터로 구성
	 * @private
	 * @param {Object} obj 대상그리드(Dataset가능)
	 * @param {Object} oCfg 속성(tagname : 다건처리시 상위tag지정)
	 * @example GridEx._getXmlForWS(this.grdList)
	 * @memberof GridEx
	 */
	GridEx._getXmlForWS = function(obj, oCfg)
	{
//		if (!oCfg) oCfg = {};
//		
//		var sXML = "", sTagNm = oCfg.tagname || "ITEMS";
//		switch (NX.Analyzer._typeof(obj))
//		{
//			case "grid" :
//				sXML += "<" + sTagNm + ">\n";
//				for (var i=0, nRowCnt=obj.rowcount; i<nRowCnt; i++)
//				{
//					sXML += "<ITEM>\n";
//					for (var j=0, sColID="", nCellCnt=obj.getCellCount("body"); j<nCellCnt; j++)
//					{
//						sColID = Util.trim(obj.getCellProperty("body", j, "text"));
//						if (sColID.indexOf("bind:") == 0)
//						{
//							sColID = sColID.slice(5);
//							sXML += "<" + sColID + "><![CDATA[" + obj.getCellText(i, j) + "]]]]]]><![CDATA[><![CDATA[></" + sColID + ">\n";
////								sXML += "<" + sColID + ">" + obj.getCellText(i, j) + "</" + sColID + ">\n";
//						}
//					}
//					sXML += "</ITEM>\n";
//				}
//				sXML += "</" + sTagNm + ">\n";
//				break;
//				
//			case "dataset" : 
//				sXML = DatasetEx.getXmlForWS(obj, oCfg);
//				break;			
//		}
//		return sXML;
	}
	
	/**
	 * 그리드의 현재rowposition에 대한 vscrollbar보정처리(NX.Service에서 사용)
	 * @private
	 * @param {Object} obj 대상그리드(Dataset가능)
	 * @param {Object} oCfg 설정객체(currow:임의지정, container:그리드의 container를 지정)
	 * @example GridEx._adjustScroll(this.grdList)
	 * @memberof GridEx
	 */
	GridEx._adjustScroll = function(oGrid, oCfg)
	{
		var nRow, oDs = oGrid.getBindDataset();
		if (oDs)
		{
			if (!oCfg) oCfg = {};
			if (!oCfg.currow) nRow = oDs.rowposition;

			oDs.set_rowposition(-1);
			oDs.set_rowposition(nRow);
			
			DatasetEx._clearProperty(oGrid, oDs); // 공통기능 초기화
		}
	}
	
	/**
	 * 그리드의 현재format값을 초기화
	 * @param {Object} oGrid 대상그리드(Dataset가능)
	 * @example GridEx.clearFormat(this.grdList)
	 * @memberof GridEx
	 */
	GridEx.clearFormat = function(oGrid)
	{
		oGrid.set_formats("<Formats><Format id='default'></Format></Formats>");
	}
	
	/**
	 * 그리드의 지정한 0부터 지정한 컬럼index까지의 현재너비를 반환 (band미적용)
	 * @private
	 * @param {Object} oGrid 대상그리드
	 * @param {Number} nToColIdx 컬럼Index(0부터~)
	 * @example GridEx._getRealColSize(this.grdList, 6)
	 * @memberof GridEx
	 */
	GridEx._getRealColSize = function(oGrid, nToColIdx)
	{
		var nColIdx, nColSpan, nRowIdx, nAddSize = 0;
		for (var i=0, nCnt=oGrid.getCellCount("body"); i<nCnt; i++)
		{
			nRowIdx 	= oGrid.getCellProperty("body", i, "row");
			nColIdx 	= oGrid.getCellProperty("body", i, "col");
			nColSpan 	= oGrid.getCellProperty("body", i, "colspan");
			
			if (nRowIdx >= 2 || parseInt(nToColIdx) < nColIdx) break;
			
			nAddSize += oGrid.getRealColSize(i);

			if (nColSpan >= 2)
			{
				for (var j=1; nColSpan>j; j++) nAddSize += oGrid.getRealColSize(i+j);
			}
		}
		return nAddSize;
	}
	
	/**
	 * 그리드의 셀에 Text 속성에 지정한 값의 포함여부를 확인후 index반환
	 * (바인딩을 설정한 Dataset컬럼값으로 그리드 Col index값을 획득할수 있음)
	 * @param {Object} oGrid 대상그리드
	 * @param {String} sColumnId 그리드와 바인딩한 Dataset컬럼ID
	 * @example GridEx.getColByText(this.grdList, "Column0")
	 * @memberof GridEx
	 */
	GridEx.getColByText = function(oGrid, sText)
	{
		for (var i=0, nCellCnt=oGrid.getCellCount("body"); i<nCellCnt; i++)
		{
			if (Util.trim(oGrid.getCellProperty("body", i, "text")).indexOf(sText) >= 0)
			{
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * 그리드의 특정컬럼Index에 hscrollbar를 위치하게함
	 * @param {Object} oGrid 대상그리드
	 * @param {Number} nToColIdx 스크롤바를 위치시킬 컬럼Index
	 * @example GridEx.setColPos(this.grdList, 2)
	 * @memberof GridEx
	 */
	GridEx.setColPos = function(oGrid, nColIdx)
	{
		var oHscrollbar = oGrid.hscrollbar;
		if (oHscrollbar.visible)
		{
			var nWidth = oGrid.getOffsetWidth();
			var nColSize = GridEx._getRealColSize(oGrid, nColIdx);
			var nFullSize = oGrid.getRealColFullSize("body");
			var nPos = parseInt(nColSize / nFullSize * oHscrollbar.max);
			
			if (nWidth/2 >= nColSize)
			{
				nPos = 0;
			}
			else if (nFullSize - nColSize < nWidth/2)
			{
				nPos = oHscrollbar.max;
			}
			
			oHscrollbar.set_pos(nPos);
		}
	}
	
	/**
	 * 트리그리드의 특정행에 대한 부모Row에 대한 배열반환
	 * @private
	 * @param {Object} oGrid 대상그리드
	 * @param {Number} nIdx 특정Row
	 * @example GridEx._getTreeParent(this.grdList, 2)
	 * @memberof GridEx
	 */
	GridEx._getTreeParent = function (obj, nIdx)
	{
		var nRow, aIdx = [];
			aIdx[0] = nIdx;
		for(;;)
		{ 
			nRow = obj.getTreeParentRow(aIdx[aIdx.length-1]);
			if (nRow < 0) return aIdx;
			aIdx.push(nRow);
		}
	}
	
	/**
	 * 트리그리드 특정Row의 Expand처리
	 * @param {Object} oGrid 대상그리드
	 * @param {Number} nRow Expand대상Row
	 * @example GridEx.setTreeStatus(this.grdList, 12)
	 * @memberof GridEx
	 */
	GridEx.setTreeStatus = function(obj, nRow)
	{
		var aRow = GridEx._getTreeParent(obj, nRow);
		for (var i=aRow.length; i>=0; i--)
		{
			if (i==0)
			{
				obj.getBindDataset().set_rowposition(aRow[i]);
			}
			else
			{
				obj.setTreeStatus(obj.getTreeRow(aRow[i]), true);
			}
		}
	}
	
	GridEx.setHidden = function(obj,nColIdx)
	{
        var aHiddenCol = (Util.isNull(obj._hiddenCol)) ? [] : obj._hiddenCol;
        var nWidth = 0;
		
		if(obj.selecttype == "area" || obj.selecttype == "multiarea")
		{
			var nStartCol = parseInt(obj.selectstartcol);
			var nEndCol = parseInt(obj.selectendcol);

			if(nStartCol == nEndCol)
			{
				nWidth = obj.getFormatColProperty(nStartCol,"size");
				if((Util.isNull(nWidth)) || nWidth == 0)
				{
					nWidth = obj.getFormatColProperty(nColIdx,"size");
					
					if(nWidth > 0)
					{
						aHiddenCol[aHiddenCol.length] = {colidx:nColIdx,colwidth:nWidth};
						
						obj.setFormatColProperty(nColIdx,"size",0);							
					}
				}
				else
				{
					aHiddenCol[aHiddenCol.length] = {colidx:nStartCol,colwidth:nWidth};
					
					obj.setFormatColProperty(nStartCol,"size",0);					
				}
			}
			else
			{
				for (var i=nStartCol; i<=nEndCol; i++)
				{
					nWidth = obj.getFormatColProperty(i,"size");
					if(nWidth == 0) continue;
					
					aHiddenCol[aHiddenCol.length] = {colidx:i,colwidth:nWidth};
					
					obj.setFormatColProperty(i,"size",0);
				}		
			}			
		}
		else
		{
			nWidth = obj.getFormatColProperty(nColIdx,"size");
			if(nWidth == 0) return;
			aHiddenCol[aHiddenCol.length] = {colidx:nColIdx,colwidth:nWidth};
			obj.setFormatColProperty(nColIdx,"size",0);
		}
		
		obj._hiddenCol = aHiddenCol;
			
	}
	
	GridEx.setHiddenCancel = function(obj)
	{
        var aHiddenCol = obj._hiddenCol;
        var nWidth = 0;
		var oColInfo;
		if(Util.isNull(aHiddenCol)) return;
		
		for (var i=0; i<aHiddenCol.length; i++)
		{
			oColInfo = aHiddenCol[i];
	        obj.setFormatColProperty(oColInfo.colidx,"size",oColInfo.colwidth);
			obj._hiddenCol = "";
		}				
	}	
}
