if (nexacro.Browser != "Runtime")
{
	try
	{
		//<link rel="shortcut icon" type="image/x-icon" href="./common/img/nexacro.ico" />
		var oFaviconLink = document.createElement("link");
			oFaviconLink.type = "image/x-icon";
			oFaviconLink.rel = "shortcut icon";
			oFaviconLink.href = "./common/img/nexacro.ico";
	  
		//<link rel="stylesheet" type="text/css" href="./common/img/chart/rMateChartH5.css">
		var oChartLink = document.createElement("link");
			oChartLink.type = "text/css";
			oChartLink.rel = "stylesheet";
			oChartLink.href = "./common/img/chart/rMateChartH5.css";
		var oHead   = document.getElementsByTagName("head")[0];
		var oScript = document.getElementsByTagName("script")[0];
		if (oHead && oScript)
		{
			oHead.insertBefore(oFaviconLink, oScript);
			oHead.insertBefore(oChartLink, oScript);
		}

	}
	catch(e)
	{
		trace("Link Css Exception : " + e.message); 
	}
}	