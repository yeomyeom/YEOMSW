﻿/**
 * @fileoverview 컴포넌트 초기화 및 이벤트 처리 관련
 */
if (!JsNamespace.exist("NX.Comps") )
{
	/**
	 * @namespace
	 * @name NX.Comps
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("NX.Comps", {
	
		COMBO_DISPLAY_ROWCOUNT 	: 15,
		COMBO_LIST_MIN_WIDTH 	: 150, 
		SINGLE_FILTER_LIMIT_CNT : 500, // limit count of single filter

		SINGLE_CHAR_WIDTH		: 13, 
		GRID_VSCROLLBAR_WIDTH	: 14, 
		
		GRID_RBUTTON_DS_PREFIX	: "_dsGridPopupenu",
		GRID_RBUTTON_PNM_PREFIX	: "_pmnGridPopupmenu",
		GRID_CTX_SORT_FUNC		: "_fn_sort",
		GRID_CTX_FILTER_FUNC	: "_fn_filter",
		GRID_CTX_EXPORT_FUNC	: "_fn_export",
		GRID_CTX_FIX_FUNC		: "_fn_fix",
		
		CALENDAR_POPUP_URL : "com::com_calendar_mobile.xfdl",
		CMMCODE_POPUP_URL : "com::com_cmmcode_mobile.xfdl",
		
		GRID_EXCEL_TEXTAREA_PREFIX : "_txaExcel_",
		
		TIMERID_LOGOUT : 9900,
		
		ADDROW_TEXT_ALL : "[전체]",
		ADDROW_TEXT_SELECT : "[선택]",
		ADDROW_TEXT_DIRECT : "[직접입력]",
		
		BTN_PRIFIX_R_AUTH : "btn_search", 
		BTN_PRIFIX_C_AUTH : "btn_insert",
		BTN_PRIFIX_U_AUTH : "btn_save",
		BTN_PRIFIX_D_AUTH : "btn_delete",
		BTN_PRIFIX_P_AUTH : "btn_report",
		BTN_PRIFIX_A_AUTH : "btn_approval",
		BTN_PRIFIX_F_AUTH : "btn_draft",
		
		/**
		 * 일치하는 정보의 컴포넌트 반환(없는경우 생성하여반환)
		 * @param  {Object} pThis 화면Form
		 * @param  {Object} o 화면정보
		 * @return n/a
		 * @example NX.Comps.getComponent(o);
		 * @memberOf NX.Comps
		 */
		getComponent : function(pThis, o)
		{
			var sCompNm = o.name;
			var oComp = pThis.components[sCompNm];
			if (oComp)
			{
			}
			else
			{
				var nLeft 	= o.left 	|| 0; 
				var nTop 	= o.top 	|| 0; 
				var nWidth 	= o.width 	|| 0;
				var nHeight = o.height 	|| 0;
				var nRight 	= o.right 	|| null;
				var nBottom = o.bottom 	|| null;
				switch (o.component)
				{
					case "WebBrowser" :
						oComp = new WebBrowser();
						break;			
				}
				
				oComp.init(sCompNm, "absolute", nLeft, nTop, nWidth, nHeight, nRight, nBottom);
				pThis.addChild(sCompNm, oComp);
				oComp.show();
			}
			return oComp;			
		},
		
		/**
		 * Unique한 컴포넌트id를 사용해서 넥사크로객체반환
		 * @private
		 * @param  {String} sId 객체의 html상 ID
		 * @return {Object} FORM객체
		 * @example NX.Comps.getCompById(o);
		 * @memberOf NX.Comps
		 */
		_getCompById : function(sId)
		{
			var oComp = null;
			
			if (NX.isFrame())
			{
				var sSepFORM 	= "_form_", sSepFRAMESET = "_FrameSet_";
				var sStartIdx 	= (sId.indexOf(sSepFRAMESET) > -1) ? sId.indexOf(sSepFRAMESET) + sSepFRAMESET.length : 0;
				var sEndIdx 	= sId.indexOf(sSepFORM);
				var sFrameId 	= sId.substring(sStartIdx, sEndIdx);
				
				var aFrameId =  sFrameId.split("_");
				
				var oFrame;
				switch(aFrameId.length)
				{
				    case 1 : //modeless popup
						var sPopupId = sFrameId;
						oFrame = application.popupframes[sPopupId];
						oComp = oFrame.form;				    	
				    break;
				    
				    case 2 : //work frame
						oFrame = NX.FRAME_WORK.frames[sFrameId];	
						oComp = oFrame.form.divWork;				    	
				    break;
				    
				    default : //modal popup
						var sPopupId = aFrameId[2];
						oFrame = application.popupframes[sPopupId];
						oComp = oFrame.form;				    	
				    break;
				}	
				
			}
			else
			{
				oComp = NX.getApp().mainframe.childframe.form;
			}
			
			return oComp;
		},
		
		/**
		 * 차트관련 부모form을 반환하는 함수
		 * @private
		 * @param  {String} sId 객체의 html상 ID
		 * @return {Object} FORM객체
		 * @example NX.Comps.getCompById(o);
		 * @memberOf NX.Comps
		 */
		_getChartForm : function(sChartId)
		{
			// 팝업화면 및 동일화면 오픈시 테스트 필요
			var sDivId 	= document.getElementById(sChartId).parentElement.id;
			return NX.Comps._getCompById(sDivId); // for quickview
		},
		 
		/**
		 * 열린화면 리스트 추가함수
		 * @param  {Object} o 화면정보(frameid, scrnid)
		 * @return n/a
		 * @example NX.Comps.addOpenList(o);
		 * @memberOf NX.Comps
		 */
		addOpenList : function(o)
		{
			var oDsLst = NX.getApp().gdsOpenList, nRow = oDsLst.addRow();
			if (nRow >= 0)
			{
				oDsLst.setColumn(nRow, "frameId", 	o.frameid);
				oDsLst.setColumn(nRow, "menuId", 	o.menuid);
				oDsLst.setColumn(nRow, "menuNm", 	o.menunm);
			}
		},
		
		/**
		 * 열린화면 리스트 삭제함수
		 * @param  {Object} o 화면정보(frameid, scrnid)
		 * @return n/a
		 * @example NX.Comps.deleteOpenList(o);
		 * @memberOf NX.Comps
		 */
		deleteOpenList : function(o)
		{
			var oDsLst = NX.getApp().gdsOpenList, nRow = oDsLst.findRow("frameId", o.frameid);
			if (nRow >= 0) oDsLst.deleteRow(nRow);
		},
		
		/**
		 * 컨테이너에 화면권한 설정(화면버튼권한 등 설정 용이하게 위해 설정 : 반복적으로 권한획득하는 부분 제거)
		 * @private
		 * @param  {Object} o Form
		 * @return n/a
		 * @example NX.Comps._setAuthority(o);
		 * @memberOf NX.Comps
		 */
		_setAuthority : function(pThis)
		{
			pThis._AUTHORITY_LIST = pThis.gfn_getScrnAuth();
		},
		
		/**
		 * 개발시 체크할 사항들에대해서 처리
		 * @private
		 * @param  {Object} obj Form객체
		 * @return n/a
		 * @example NX.Comps.developerSupport(this);
		 * @memberOf NX.Comps
		 */
		_developerSupport : function(pThis, obj)
		{
			// fvFormType 체크
			//	if (!this.fvFormType) this.gfn_msgBox("A", "this.fvFormType 변수 선언되었는지 확인하세요.");
		},

		
		/**
		 * oComposite에 포함된 Component의 기능을 약속된 기능으로 변경한다.
		 * @private
		 * @param  {Object} : Composite 컴포넌트(form, div, tab, tabpage)
		 * @return void
		 * @see    NX.Comps._interceptEvent(this, obj)
		 * @memberOf NX.Comps
		 */
		_interceptEvent : function(pThis, obj)
		{
			NX.Comps._retrieveComps(pThis, obj, NX.Comps._redefineComp);
			
			for (var i=0, nLen=pThis.objects.length; i<nLen; i++)
			{
				var oDs = pThis.objects[i];
				if (oDs instanceof Dataset)
				{
					if (oDs.keystring) DatasetEx.setKeystr(oDs, oDs.keystring, false);
					if (oDs.filterstr) DatasetEx.setFilter(oDs, oDs.filterstr, false);
				}
			}
		},
		
		/**
		 * oComposite에 해당하는 Component를 재귀적으로 호출한다.
		 * @private
		 * @param  {Object} oComps : Composite 컴포넌트(form, div, tab, tabpage)
		 * @param  {Object} oFunc	: 재귀적으로 호출하는 function (global의 nonamed funcion으로 인식하여 제거)
		 * @param  {Boolean} bIgnoreUrl	: URL Link 무시 여부
		 * @param  {Number} nLvl : component depth
		 * @return n/a
		 * @example    NX.Comps.retrieveComps(oComps, oFunc, bIgnoreUrl, nLvl)
		 * @memberOf NX.Comps
		 */
		_retrieveComps : function(pThis, oComps, oFunc, bIgnoreUrl, nLvl)
		{
			if (oComps == undefined || oComps == null) oComps = pThis;
			if (nLvl == undefined) nLvl = 1;
			if (bIgnoreUrl == undefined) bIgnoreUrl = true;

			for (var i=0, nLen=oComps.components.length; i<nLen; i++)
			{
				var oComp = oComps.components[i];
				oFunc.call(pThis, oComp, nLvl, oComps); // pThis,

				if (oComp instanceof Div)
				{
					if (bIgnoreUrl == true && Util.isNull(oComp.url) == false) continue;
					this._retrieveComps(pThis, oComp, oFunc, bIgnoreUrl, nLvl+1);
				}
				else if (oComp instanceof Tab)
				{
					this._retrieveComps(pThis, oComp, oFunc, bIgnoreUrl, nLvl+1);
				}
				else if (oComp instanceof Tabpage)
				{
					if (bIgnoreUrl == true && Util.isNull(oComp.url) == false) continue;
					this._retrieveComps(pThis, oComp, oFunc, bIgnoreUrl, nLvl+1);
				}
			}
		},
		

		/**
		 * Component에 대한 재정의함수를 호출
		 * @private
		 * @param	{Object} oComps : Composite 컴포넌트(Edit, Grid...)
		 * @return	n/a
		 * @example	NX.Comps._redefineComp(oComps)
		 * @memberOf NX.Comps
		 */
		_redefineComp : function(oComp)
		{
			switch (NX.Analyzer._typeof(oComp))
			{
				case "button" : 
					NX.Comps._defineButton(this, oComp);
					break;
				case "edit" : 
		// 			if (oComp.onrbuttondown.length > 0) oComp.usecontextmenu = false;
					NX.Comps._defineEdit(this, oComp);
					break;
				case "maskedit" : 
					if(NX.isMobile())
					{
						oComp.set_autoselect(false);
					}
					else
					{
						oComp.set_autoselect(true);
					}
					break;
				case "grid" :
		//			oComp.usecontrolkey = false; 		// MDI 창전환(for runtime)
					NX.Comps._defineGrid(this, oComp);
					break;
				case "combo" :
					NX.Comps._defineCombo(this, oComp);
					break;
				case "calendar" : 
					NX.Comps._defineCalendar(this, oComp);
					break;
				case "textarea" :
		//			oComp.usecontrolkey = false; 		// MDI 창전환(for runtime)
					break;
				case "tab" :
		//			oComp.usecontrolkey = false; 		// MDI 창전환(for runtime)
		//			oComp.set_selectchangetype("up");
					
					if (NX.getApp().enableaccessibility) // 접근성관련 설정
					{
						oComp.set_focusacceptable(true);
					}
					
//					var oTabPages 		= oComp.tabpages;
//					var nTabCount		= oTabPages.length;	// TabCount
//					var nActiveTabpage 	= oComp.tabindex;	// Current Tabindex
//					
//					oComp._isload_tabpage = {};
//					for (var i=0; i<nTabCount; i++)
//					{
//						if (oComp.preload == false && !Util.isNull(oTabPages[i].url))
//						{
//							oComp._isload_tabpage[i] = i == nActiveTabpage ? true : false;
//						}
//					}
//					
//					if (oComp.preload == false && !this.gfn_isFormType(NX.FORM_POP))
//					{
//						oComp.addEventHandler("onchanged", NX.Comps._tab_common_onchanged, this);
//					}
					break;
			}
			
			// component bottom position
		// 	if (oComp.visible && !(oComp instanceof Form))
		// 	{
		// 		var nBottom = oComp.getOffsetBottom();
		// 		if (this._gv_max_bottom < nBottom)
		// 		{
		// 			this._gv_max_bottom = nBottom;
		// 		}
		// 	}
		},
		
		/**
		 * TabPage의 onchanged 이벤트 정의
		 * @private
		 * @param  {Object} Tab컴포넌트
		 * @param  {Object}	TabIndexChangeEventInfo 이벤트객체 
		 * @return void
		 * @see    NX.Comps._pagetab_main_onchanged(obj, e)
		 * @memberOf NX.Comps
		 */ 
		_tab_common_onchanged : function(obj, e)
		{
			if (obj.preload == false && !obj._isload_tabpage[e.postindex])
			{
				obj._isload_tabpage[e.postindex] = true;
//				NX.Comps._procPostInitComp(this); // postload처리
			}
			
//			if (e.postindex >= 0) obj.tabpages[e.postindex].setFocus();
		},
		
		_isLoadTabpage : function(obj, nIdx)
		{
//			if (Util.isNull(nIdx)) nIdx = obj.tabindex;  
//			return obj._isload_tabpage[nIdx];
			
			return !Util.isNull(obj.tabpages[nIdx].fvFormType);
		},

		/*=================================================================================================
		 *	nexacroplatform 기본 Edit 의 재정의 된 Event Function (Start)
		 *=================================================================================================*/
		_defineButton : function(pThis, oComp)
		{
			var sAuthChar, sAuthList = pThis._AUTHORITY_LIST;
			// 업무영역의 권한획득후에 처리 <- 전역변수로 저장
			if (sAuthList && (pThis.fvFormType == NX.FORM_MAIN 	|| pThis.fvFormType == NX.FORM_TAB || pThis.fvFormType == NX.FORM_DIV 	|| pThis.fvFormType == NX.FORM_POP))
			{
				var sBtnNm = oComp.name;
				
				if(!oComp.visible) return; //보이지 않는 버튼은 권한처리 안함
				
				if (sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_R_AUTH) >= 0)
				{					
					oComp.set_visible(sAuthList.indexOf("R") >= 0);
				}
				else if(sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_C_AUTH) >= 0)
				{
					oComp.set_visible(sAuthList.indexOf("C") >= 0);
				}
				else if(sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_U_AUTH) >= 0)
				{
					oComp.set_visible(sAuthList.indexOf("U") >= 0);
				}
				else if(sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_D_AUTH) >= 0)
				{
					oComp.set_visible(sAuthList.indexOf("D") >= 0);
				}
				else if(sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_P_AUTH) >= 0)
				{
					oComp.set_visible(sAuthList.indexOf("P") >= 0);
				}
				else if(sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_A_AUTH) >= 0)
				{
					oComp.set_visible(sAuthList.indexOf("A") >= 0);
				}
				else if(sBtnNm.indexOf(NX.Comps.BTN_PRIFIX_F_AUTH) >= 0)
				{
					oComp.set_visible(sAuthList.indexOf("F") >= 0);
				}
			}	
		},
		
		/**
		 * Form Load 시 Edit 재정의 한다.
		 * @private
		 * @param  {Object} : Edit 컴포넌트
		 * @return void
		 * @see    NX.Comps._defineEdit(obj)
		 * @memberOf NX.Comps
		 */ 
		_defineEdit : function(pThis, oComp)
		{
			if(NX.isMobile()) 
			{
				oComp.set_autoselect(false); // 기본설정(Edit, Calendar)
			}
			
			/* 2019.01.07 IE에서 Editbox에 붙여넣기 하는 경우에 클립보드의 영향으로 인한 계속 autoselect가 되는 현상으로 인하여 주석처리
			else
			{
				oComp.set_autoselect(true);
			}
			*/
			
			// 코드입력에 대한 기본설정
			var sInputType = oComp.inputtype;
			if (sInputType == "english" || sInputType == "alpha" || sInputType == "numberandenglish")
			{
				oComp.set_inputmode("upper");
				oComp.set_imemode("alpha");
			}
			
			// userproperty _masktype에 대한 처리
			if (oComp._masktype)
			{
				oComp.addEventHandler("onsetfocus", pThis._gfn_edit_onsetfocus, pThis);
				oComp.addEventHandler("onkillfocus", pThis._gfn_edit_onkillfocus, pThis);
			}
		},

		/**
		 * mask적용 Eidt의 unmask값을 반환
		 * @param  {Object} oComp Edit컴포넌트
		 * @see    gfn_getUnmaskValue(obj)
		 * @memberOf NX.Comps
		 */
		getUnmaskValue : function(oComp)
		{
			if (oComp.__unmaskvalue) return oComp.__unmaskvalue;
		},

		/**
		 * mask적용 Eidt의 unmask값 설정
		 * @param  {Object} oComp Edit컴포넌트
		 * @param  {String} sValue unmaks값
		 * @see    gfn_setUnmaskValue(obj, "1234")
		 * @memberOf NX.Comps
		 */
		setUnmaskValue : function(oComp, sValue)
		{
			oComp.__unmaskvalue = sValue;
			
			if (oComp.readonly == false && this.getFocus() === oComp)
			{
				oComp.set_value(sValue);
			}
			else
			{
				oComp.set_value(Util.setMask(oComp.__unmaskvalue, oComp._masktype));
			}
		},

		/*=================================================================================================
		 *	nexacroplatform 기본 Edit 의 재정의 된 Event Function (End)
		 *=================================================================================================*/

		/*=================================================================================================
		 * 	nexacroplatform 기본 Calendar 의 재정의 된 Event Function (Start)
		 *=================================================================================================*/
		/**
		 * Form Load 시 Calendar를 재정의 한다.
		 * @private
		 * @param  {Object} Calendar 컴포넌트
		 * @return void
		 * @see    NX.Comps._defineCalendar(obj)
		 * @memberOf NX.Comps
		 */
		_defineCalendar : function(pThis, oComp)
		{
			// 기본설정사항
			if (NX.isMobile())
			{
				oComp.set_autoselect(false);
				oComp.set_readonly(true);
				oComp.style.set_popuptype("none");
				if (oComp.dropbutton)
				{
					oComp.dropbutton.addEventHandler("onlbuttonup", NX.Comps._calendar_dropbutton_onlbuttonup, pThis);
					oComp.dropbutton.addEventHandler("ontouchend", NX.Comps._calendar_dropbutton_onlbuttonup, pThis);
				}
				else
				{
					Util.trace("[Confirm] Calendar dropbutton not created : " + oComp.name);
				}
				
				if (oComp.calendaredit)
				{
					oComp.calendaredit.addEventHandler("onlbuttonup", NX.Comps._calendar_dropbutton_onlbuttonup, pThis);
					oComp.calendaredit.addEventHandler("ontouchend", NX.Comps._calendar_dropbutton_onlbuttonup, pThis);
				}
				else
				{
					Util.trace("[Confirm] Calendar calendaredit not created : " + oComp.name);
				}
			}
			else
			{
				oComp.set_autoselect(true);
				// 월 달력구현을 위한 이벤트 추가
				if (oComp.dateformat == "yyyy-MM" && oComp.editformat == "yyyy-MM")
				{
					oComp.style.set_popuptype("none");
					if (oComp.dropbutton)
					{
						oComp.dropbutton.addEventHandler("onlbuttonup", NX.Comps._calendar_dropbutton_onlbuttonup, pThis);
					}
					else
					{
						NX.Comps._setPostInitComp(pThis, oComp);
					}
				}
				else
				{
					if (oComp._biztype)
					{
						oComp.set_innerdataset("gdsTrDate");
						oComp.set_datecolumn("hdyDt");
						oComp.set_textcolorcolumn("colorCd");
//						oComp.set_backgroundcolumn("colorCd");
//						oComp.addEventHandler("canchange", pThis._gfn_calendar_canchange, pThis); // 업무별 달력
					}
				}
			}
		},
		
		_calendar_dropbutton_onlbuttonup : function(obj, e)
		{
			var oCal = obj.parent;
			if (!oCal.enable) return;
			
			if (NX.isMobile())
			{				
				var oTopFrom = NX.getScriptForm(obj);
				oTopFrom.gfn_popup(	"__com_calendar_mobile", 
								NX.Comps.CALENDAR_POPUP_URL, 
								{currentvalue:oCal.value}, 
								{callback:function(sPopupId, sRtn){
									if (sRtn)
									{
										var _pretext	= oCal.text;
										var _prevalue	= oCal.value;

										oCal.set_value(sRtn);
										
										var sEvtId	= "onchanged";
										var oFunc 	= oCal.getEventHandler(sEvtId, 0);
										if (oFunc)
										{
											var oEvt = {eventid:sEvtId, fromobject:oCal, pretext:_pretext, prevalue:_prevalue, posttext:oCal.text, postvalue:oCal.value};
											oFunc.call(NX.Analyzer.form(this.parent), oCal, oEvt);
										}	
									}
								}, style:"showtitlebar=false"});
			}
			else
			{
				if(oCal.readonly) return;
				var sDivID 	= "_pdiv_popupcal_" + oCal.name;
				var oPopdiv = this.components[sDivID];;	
				var nWidth 	= 197, nHeight = 192;
				
				if (oPopdiv)
				{}
				else
				{
					oPopdiv = new PopupDiv(sDivID, "absolute", 0, 0, nWidth, nHeight, null, null);
					oPopdiv.set_async(false);
					oPopdiv.set_tabstop(false);
					oPopdiv.set_scrollbars("none");
					oPopdiv.set_url("com::com_calendar_month.xfdl");
					this.addChild(sDivID, oPopdiv);
					oPopdiv.show();
					
					this._gfn_setPopupDiv(oPopdiv);
				}

				if (oPopdiv.isPopup())
				{
					oPopdiv.closePopup();
					return;
				}	

				// Synchronous XMLHttpRequest on the main thread is deprecated because of its detrimental effects to the end user's experience. -> async로 변경
				oPopdiv.fnSetMonthCalendar(Util.trim(oCal.value).substr(0, 6)); // -> onload event에서 처리
			//  calendar가 url값에 의해 대체되는 관계로 container에 user property 설정
			// 	oPdiv._calendar_date = Util.trim(oCal.value).substr(0, 6);
				oPopdiv._link_calendar = oCal;
				
				oPopdiv.trackPopupByComponent(oCal, 0, oCal.getOffsetHeight()+1, nWidth, nHeight, "_gfn_calendar_dropbutton_callback");
			}
		},

		/*=================================================================================================
		 * nexacroplatform 기본 Combo 의 재정의 된 Event Function (Start)
		 *=================================================================================================*/
		/**
		 * Form Load 시 Combo를 재정의 한다.
		 * @private
		 * @param  {Object} Combo 컴포넌트
		 * @return void
		 * @see    _gfn_defineCombo(obj)
		 * @memberOf NX.Comps
		 */
		_defineCombo : function(pThis, oComp)
		{
			Util.trace("_defineCombo >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");  
			Util.trace("oComp.displayrowcount :: " + oComp.displayrowcount);
			Util.trace("isMobile :: " + NX.isMobile());
			Util.trace("oComp.type :: " + oComp.type);

			
			if (oComp.displayrowcount == -1) oComp.set_displayrowcount(NX.Comps.COMBO_DISPLAY_ROWCOUNT);
			if (oComp.type == "search" || oComp.type == "filter")
			{
				if (oComp.comboedit)
				{
					if(NX.isMobile())
					{
						oComp.comboedit.set_autoselect(false);
					}
					else
					{
						oComp.comboedit.set_autoselect(true);
					}
				}
				else
				{
					NX.Comps._setPostInitComp(pThis, oComp);
				}
			}
			else
			{
//				oComp.addEventHandler("onkeyup", NX.Comps._combo_onkeyup, pThis);
			}

			// 2019-08-22 모바일 주석
//			if (NX.isMobile())
//			{
//				oComp.set_readonly(true);
//				oComp.style.set_popuptype("none");
//				if (oComp.dropbutton)
//				{
//					oComp.dropbutton.addEventHandler("onlbuttonup", NX.Comps._combo_dropbutton_onlbuttonup, pThis);
//					oComp.dropbutton.addEventHandler("ontouchend", NX.Comps._combo_dropbutton_onlbuttonup, pThis);
//					
//				}
//				else
//				{
//					Util.trace("[Confirm] Combo dropbutton not created : " + oComp.name);
//				}
//				
//				if (oComp.comboedit)
//				{
//					oComp.comboedit.addEventHandler("onlbuttonup", NX.Comps._combo_dropbutton_onlbuttonup, pThis);
//					oComp.comboedit.addEventHandler("ontouchend", NX.Comps._combo_dropbutton_onlbuttonup, pThis);
//				}
//				else
//				{
//					Util.trace("[Confirm] Combo comboedit not created : " + oComp.name);
//				}
//			}
//			else
//			{
// // 2019-08-22 모바일 주석 종료
			Util.trace("oComp.list ::  " +oComp.list);
				if (oComp.list == "multicell")
				{
					oComp.set_type("dropdown");
					oComp.style.set_popuptype("none");
					if (oComp.dropbutton)
					{
						oComp.dropbutton.addEventHandler("onlbuttonup", NX.Comps._combo_multicell_dropbutton_onlbuttonup, pThis);
					}
					else
					{
						Util.trace("[Confirm] MultiCell Combo dropbutton not created : " + oComp.name);
					}
					
					if (oComp.comboedit)
					{
						oComp.comboedit.addEventHandler("onlbuttonup", NX.Comps._combo_multicell_dropbutton_onlbuttonup, pThis);
					}
					else
					{
						Util.trace("[Confirm] MultiCell Combo comboedit not created : " + oComp.name);
					}
				}
// // 2019-08-22 모바일 주석
//			}
// // 2019-08-22 모바일 주석 종료
		},
		
		 /**
		  * Combo컴포넌트 keyup이벤트 처리(space keyin시에 listbox dropdown처리)
		  * @private
		  * @memberOf NX.Comps
		  */
		 _combo_onkeyup : function(obj, e)
		 {
		 	if (e.keycode == 32) obj.dropdown();
		 },
		
		 /**
		  * Combo컴포넌트 모바일Device에서 팝업형태로 호출처리
		  * @private
		  * @memberOf NX.Comps		  
		  */
		_combo_dropbutton_onlbuttonup : function(obj, e)
		{
			Util.trace("_combo_dropbutton_onlbuttonup >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"); 
			Util.trace("NX.Comps.CMMCODE_POPUP_URL :: " + NX.Comps.CMMCODE_POPUP_URL);
			
			var oComp = obj.parent;
			if (!oComp.enable) return;
			
			var oInnerDs = this.objects[oComp.innerdataset];
			if (oInnerDs && oInnerDs.rowcount > 0)
			{
				// check user property(commoncode) out
				var oCmmInfo = oComp._cmmcodeinfo;
				if (!oCmmInfo)
				{
					oCmmInfo = {codecolumn:oComp.codecolumn, datacolumn:oComp.datacolumn};
				}
				
				var oTopFrom = NX.getScriptForm(obj);
				
				oTopFrom.gfn_popup(	"__com_commcode_mobile", 
								NX.Comps.CMMCODE_POPUP_URL, 
								{dataset:oInnerDs, currentvalue:oComp.value, cmmcodeinfo:oCmmInfo}, 
								{callback:function(sPopupId, sRtn){

									var _preindex	= oComp.index;
									var _pretext	= oComp.text;
									var _prevalue	= oComp.value;
									
									var sEventClose = "oncloseup";
									var oCloseFunc = oComp.getEventHandler(sEventClose, 0);
									if (oCloseFunc)
									{
										
										var oEvt = {eventid:sEventClose, fromobject:oComp, preindex:_preindex, pretext:_pretext, prevalue:_prevalue, postindex:oComp.index, posttext:oComp.text, postvalue:oComp.value};
										oCloseFunc.call(NX.Analyzer.form(this.parent), oComp, oEvt);
									}	
									
									if (sRtn != "_CLOSE_EVENT")
									{
 
										oComp.set_value(sRtn);

										var sEvtId	= "onitemchanged";
										var oFunc 	= oComp.getEventHandler(sEvtId, 0);
										if (oFunc)
										{
											var oEvt = {eventid:sEvtId, fromobject:oComp, preindex:_preindex, pretext:_pretext, prevalue:_prevalue, postindex:oComp.index, posttext:oComp.text, postvalue:oComp.value};
											oFunc.call(NX.Analyzer.form(this.parent), oComp, oEvt);
										}											
									}
								}, style:"showtitlebar=false"});
			}
		},		
		
		 /**
		  * Combo컴포넌트 멀티셀형태의 combolist처리
		  * @private
		  * @memberOf NX.Comps		  
		  */
		_combo_multicell_dropbutton_onlbuttonup : function(obj, e)
		{
			var oCombo = obj.parent;
			if (!oCombo.enable || oCombo.readonly) return;
			
			var oInnerDs, sDivId = "_pdiv_combolist_" + oCombo.name;
			var oPopupDiv = this.components[sDivId];
			var sValue = "", nWidth = oCombo.getOffsetWidth(), nHeight = GridEx.BODY_ROW_HEIGHT * NX.Comps.COMBO_DISPLAY_ROWCOUNT;
			
			if (oPopupDiv)
			{
				oInnerDs = oPopupDiv._INNER_DATASET;
				if (!oPopupDiv.__filtered)
				{
					if (oInnerDs && oInnerDs.filterstr) oPopupDiv.__filtered = true;
				}
				
				// rowposition <- combo.index로 사용
				sValue = oPopupDiv._INDEX_COLUMN ? oInnerDs.getColumn(oCombo.index, oPopupDiv._INDEX_COLUMN) : oCombo.value;
				oPopupDiv.setComboList(sValue);
			}
			else
			{
				var sInnerDsNm = oCombo.innerdataset;
				var aLstColumn = [], sLstColumn = Util.trim(oCombo.listcolumn), sLstIdxColumn = Util.trim(oCombo.listidxcolumn); 
				if (sLstColumn) aLstColumn = sLstColumn.split(",");
				
				var sCodeColId = aLstColumn[0] || oCombo.codecolumn;
				var sDataColId = aLstColumn[1] || oCombo.datacolumn;
				
				oCombo.___codecolumn = sCodeColId;
				oCombo.___datacolumn = sDataColId;
				
				oInnerDs = this.objects[sInnerDsNm] || this.lookup(sInnerDsNm);
				
				oPopupDiv = new PopupDiv(sDivId, "absolute", 0, 0, nWidth, nHeight, null, null);
				oPopupDiv.set_tabstop(false);
				oPopupDiv.set_scrollbars("none");
				oPopupDiv.set_text(sInnerDsNm + NX.DELIM1 + sCodeColId + NX.DELIM1 + sDataColId + NX.DELIM1 + sLstIdxColumn);
				oPopupDiv.set_url("com::com_multicell_combolist.xfdl");
				
				this.addChild(sDivId, oPopupDiv);
				oPopupDiv.show();
				
				this[oPopupDiv._unique_id] = oCombo;		
				this._gfn_setPopupDiv(oPopupDiv);
			}

			if (oPopupDiv.isPopup())
			{
				oPopupDiv.closePopup();
			}
			else
			{
				var nMaxWidth = oInnerDs.getMax("String(" + oCombo.___datacolumn + ").length") * NX.Comps.SINGLE_CHAR_WIDTH + 70; // 70 (50:codecolumn+20:padding)<- get textsize by font object ?
				var nBasicWidth = oCombo.getOffsetWidth();
				nWidth = nMaxWidth < nBasicWidth ? nBasicWidth : nMaxWidth;
				
				if (oInnerDs.rowcount > NX.Comps.COMBO_DISPLAY_ROWCOUNT)
				{
					nHeight = GridEx.BODY_ROW_HEIGHT * NX.Comps.COMBO_DISPLAY_ROWCOUNT;
					nWidth += NX.Comps.GRID_VSCROLLBAR_WIDTH; 
				}
				else
				{
					nHeight = GridEx.BODY_ROW_HEIGHT * oInnerDs.rowcount;
				}
				
				oPopupDiv.trackPopupByComponent(oCombo, 0, oCombo.getOffsetHeight(), nWidth, nHeight + 2);
			}
			
		},
		/*=================================================================================================
		 *	nexacroplatform 기본 Combo 의 재정의 된 Event Function (End)
		 *=================================================================================================*/


		/*=================================================================================================
		 *	nexacroplatform 기본 Grid 의 재정의 된 Event Function (Start)
		 ==================================================================================================*/
		/**
		 * Form Load 시 GRID를 재정의 한다.
		 * @private
		 * @param  {Object} : Grid 컴포넌트
		 * @return void
		 * @see    _gfn_defineGrid(obj)
		 * @memberOf NX.Comps
		 */
		_defineGrid : function(pThis, oComp)
		{
			NX.Comps._setDatasetBindGridInfo(pThis, oComp);
			NX.Comps._setGridOnRButtonEvent(pThis, oComp);
			NX.Comps._setSort(oComp);
			NX.Comps._setGridOnHeadClickEvent(pThis,oComp);
					
			if (!oComp.visible && !oComp.initgrid) return;
			
			if (NX.getApp().enableaccessibility)
			{
				oComp.set_selecttype("cell");
				oComp.set_treeuseexpandkey(true);
			}
			
/*			고객 요청에 의한 그리드는 데이터 없을땐 빈화면
			if (!oComp.nodataimage)
			{
				oComp.set_nodatatext("");
//				oComp.set_nodatatext(GridEx.NODATA_TEXT); // <- NX.Service.xjs :: _postProcForResult()에서 설정
				oComp.set_nodataimage("URL('theme://images/grd_WF_NoData.png')");
			}
*/
			
			// 틀고정 보정처리(autofit이 "col"인경우 틀고정 불필요, 횡배열 그리드의 좌측그리드 제외)
			if (Util.isNull(oComp.left))
			{
				oComp.addEventHandler("onmove", function(obj, e){
					if (!Util.isNull(obj.__fixedcolline))
					{
						GridEx._setFixLine(obj, {row:obj.currentrow, cell:obj.__fixedcolline, col:obj.__fixedcolline}, {fixtype:"col"});
					}
				}, pThis);
			}
			
		//	if (oComp._setautofit != "false") oComp.set_autofittype("none");
			//if (oComp._sort == "true" || oComp.applysort == "true") oComp.addEventHandler("onheaddblclick", function(obj, e){GridEx.sort(obj, e);}, pThis);
			if (oComp.getFormatColCount() > 2)
			{
				oComp.set_cellmovingtype("col");
				if (oComp.autofittype != "col") oComp.set_cellsizingtype("col");				
			}
			
			if (oComp.autoenter == "none") oComp.set_autoenter("select"); 
			if (oComp.autoupdatetype == "none") oComp.set_autoupdatetype("itemselect");
//			if (oComp.tooltiptype == "default") oComp.set_tooltiptype("hover");
			
			// onvscroll이벤트가 등록된 그리드에 대한 keyup이벤트 등록(페이지처리시 방향(Down)키 사용관련)
			if (oComp.onvscroll) oComp.addEventHandler("onkeydown", NX.Comps._grid_onkeydown, pThis);
			
			// Edit type이 date 이고 mask가 yyyy.MM 인 Cell 이 있을때만 월달력 처리
			for (var sDisplayType, sEditType, sExpr, i=0, nCellCnt=oComp.getCellCount("body"); i<nCellCnt; i++)
			{
				sDispType = Util.trim(oComp.getCellProperty("body", i, "displaytype")).toLowerCase();
				sEditType = Util.trim(oComp.getCellProperty("body", i, "edittype")).toLowerCase();
				
				sExpr = Util.trim(oComp.getCellProperty("body", i, "expr")).toLowerCase();
				if (sExpr == "currow+1")
				{
					oComp.setCellProperty("body", i, "expr", "currow == dataset.rowposition ? '▶' : currow+1");					
				}
				
				if(NX.isMobile())
				{
					oComp.setCellProperty("body", i, "editautoselect", false);	
				}
				/* //2019.01.08 그리드 자동 autoenter 기능 적용 해제
				else
				{
					oComp.setCellProperty("body", i, "editautoselect", true);	
				}
				*/			
				
				if (sEditType.indexOf("date") >= 0 || sDispType.indexOf("date") >= 0)
				{
					var sDisplayNullType = oComp.getCellProperty("body", i, "calendardisplaynulltype");
					if (sDisplayNullType == "default")
					{
						oComp.setCellProperty("body", i, "calendardisplaynulltype", "none");
					}
					
					// 동일 그리드에 월/일력을 동시에 사용불가함 (화면에서 팝업으로 구현 OR Format으로 처리)
					// controlcalendar의 dropbutton을 미제공
		// 			var sMask = Util.trim(oComp.getCellProperty("body", i, "mask"));
		// 			if (sMask == "yyyy-MM")
		// 			{
		// 				oComp.controlcalendar.style.set_popuptype("none");
		// 				oComp.controlcalendar.dropbutton.addEventHandler("onlbuttonup", NX.Comps._grid_controlcalendar_dropbutton_onlbuttonup, this);
		// 			}
				}
				
				if (sDispType.indexOf("combo") >= 0 || sEditType.indexOf("combo") >= 0)
				{
					var comboDisplayCnt = oComp.getCellProperty("body", i, "combodisplayrowcount");
					
					if(Util.isNull(comboDisplayCnt)) oComp.setCellProperty("body", i, "combodisplayrowcount", NX.Comps.COMBO_DISPLAY_ROWCOUNT);
					
//					if (!oComp.__control_onkeyup && oComp.getCellProperty("body", i, "combotype") == "dropdown")
//					{
//						oComp.__control_onkeyup = true;
//						oComp.addEventHandler("onkeyup", NX.Comps._gridcontrol_onkeyup, pThis);
//					}
				}
				
//				if (sEditType.indexOf("expand") >= 0)
//				{
//					if (!oComp.__control_onkeyup && oComp.onexpanddown && oComp.onexpanddown._has_handlers)
//					{
//						oComp.__control_onkeyup = true;
//						oComp.addEventHandler("onkeyup", NX.Comps._gridcontrol_onkeyup, pThis);
//					}

//					if (!oComp.__control_onkeyup && oComp.onexpandup && oComp.onexpandup._has_handlers)
//					{
//						oComp.__control_onkeyup = true;
//						oComp.addEventHandler("onkeyup", NX.Comps._gridcontrol_onkeyup, pThis);
//					}
//				}
			}
		},
		
		/**
		 * 그리드 keyin이벤트 (paging처리관련 - Down버튼 동작추가)
		 * @private
		 * @param  {Object} Grid 컴포넌트
		 * @param  {nexacro.KeyEventInfo} e 이벤트객체
		 * @return void
		 * @see    NX.Comps._grid_onkeydown(obj, e)
		 * @memberOf NX.Comps
		 */
		_grid_onkeydown : function(obj, e)
		{
			// onvscroll 속성의 EventListener객체가 있는 경우만 onkeyup이벤트 등록처리
			if (obj.onvscroll && obj.vscrollbar && obj.vscrollbar.visible)
			{
				if (e.keycode == 40)
				{
					var oScrlbar = obj.vscrollbar;
					if (oScrlbar.pos == oScrlbar.max && obj.currentrow == obj.rowcount-1)
					{
						var evt = new nexacro.ScrollEventInfo(oScrlbar, "onvscroll", oScrlbar.pos, "lastover", oScrlbar, oScrlbar.parent);
						obj.vscrollbar.onscroll._fireEvent(this, evt);
//		 				if (obj.__islastoverbykeydown === true)
//		 				{
//		 					var evt = new nexacro.ScrollEventInfo(oScrlbar, "onvscroll", oScrlbar.pos, "lastover", oScrlbar, oScrlbar.parent);
//		 					obj.vscrollbar.onscroll._fireEvent(this, evt);
//		 					obj.__islastoverbykeydown = "";
//		 				}
//		 				else
//		 				{
//		 					obj.__islastoverbykeydown = true;
//		 				}
					}
				}
//		 		else if (e.keycode == 38 && obj.__islastoverbykeydown === true)
//		 		{
//		 			obj.__islastoverbykeydown = "";
//		 		}
				else if (e.keycode == 34)
				{
					var oScrlbar = obj.vscrollbar;
					if (oScrlbar && (oScrlbar.pos == oScrlbar.max))
					{
						var evt = new nexacro.ScrollEventInfo(oScrlbar, "onvscroll", oScrlbar.pos, "lastover", oScrlbar, oScrlbar.parent);
						obj.vscrollbar.onscroll._fireEvent(this, evt);
					}
				}
			}
		},

		
	    /**
	     * Grid controlcalendar 내 dropbutton 의 onlbuttondown Event(월력(월달력) 처리)
		 * @private
		 * @memberOf NX.Comps
	     */
	    _grid_controlcalendar_dropbutton_onlbuttonup : function(obj, e)
	    {
	    // 	var oCal	= obj.parent;
	    // 	var oGrid	= oCal.parent;
	    // 	var oGridDs	= this.objects[oGrid.binddataset];
	    // 	var sDivID 	= "_pdiv_popupcal_" + (oCal.name || oGrid.name);
	    // 	var oPdiv 	= this.components[sDivID];
	    // 	var nWidth	= 212+2; // border(2)
	    // 	var nHeight	= 189;
	    // 	
	    // 	if (oPdiv){}
	    // 	else
	    // 	{
	    // 		oPdiv	= new PopupDiv();
	    // 		oPdiv.init(sDivID, absolute, 0, 0, nWidth, nHeight);
	    // 		oPdiv.set_async(false);
	    // 		oPdiv.set_tabstop(false);
	    // 		oPdiv.set_scrollbars("none");
	    // 		this.addChild(sDivID, oPdiv);
	    // 		this._gfn_setPopupDiv(oPdiv);
	    // 		oPdiv.show();
	    // 	}
	    // 
	    // 	if (oPdiv.isPopup())
	    // 	{
	    // 		oPdiv.closePopup();
	    // 		return;
	    // 	}
	    // 
	    // 	oPdiv.set_url("com::com_calendar_month.xfdl");
	    // 	oPdiv.fnSetMonthCalendar(Util.trim(oCal.value).substr(0, 6));
	    // 
	    // // 	var nLeft	= system.clientToScreenX(objCal, 0);
	    // // 	var nTop	= system.clientToScreenY(objCal, oCal.position.height);
	    // 
	    // 	oPdiv._link_calendar = oCal;
	    // 	oPdiv.trackPopupByComponent(oCal, 0, oCal.getOffsetHeight()+2, nWidth, nHeight, "_gfn_grid_controlcalendar_dropbutton_callback");
	    },
	
			
	    /**
	     * 그리드 keyin이벤트 (space키에 대한 처리)
		 * @private
	     * @param  {Object} Grid 컴포넌트
	     * @param  {nexacro.KeyEventInfo} e 이벤트객체
	     * @return void
	     * @see    NX.Comps_gridcontrol_onkeyup(obj, e)
		 * @memberOf NX.Comps
	     */
	    _gridcontrol_onkeyup : function(obj, e)
	    {
	    	if (e.keycode == 32 && !obj.readonly)
	    	{
	    		var nCell = obj.getCellPos(), nRow = obj.getBindDataset().rowposition;
	    		if (nCell >= 0)
	    		{
	    	 		switch (obj.getCurEditType())
	    	 		{
	    				case "combo" 	: obj.dropdownCombo(); 		break;
	    				case "calendar" : obj.dropdownCalendar(); 	break;
	    				case "expand" 	: 
	    					var oRect		= obj.getCellRect(nRow, nCell);
	    					var sButton 	= "lbutton";
	    					var bAltKey 	= false;
	    					var bCtrlKey 	= false;
	    					var bShiftKey 	= false;
	    					var nCanvasX	= 10;
	    					var nCanvasY	= 10;
	    					var nClientX	= 10;
	    					var nClientY	= 10;
	    					var nScreenX	= system.clientToScreenX(obj, oRect.right - nClientX);
	    					var nScreenY	= system.clientToScreenY(obj, obj.getRealRowSize(-1) + oRect.top + nClientY);
	    					var oFromComp	= obj.controlexpand;
	    					var oFromReferComp = obj.controlexpand;
	    					var oGridCell;
	    					
	    					// Grid._bodyBand._matrix._rows[i]._cells[i]
	    					if (obj.onexpanddown && obj.onexpanddown._has_handlers)
	    					{
	    						oGridCell = obj._bodyBand._matrix._rows[nRow]._cells[nCell];
	    						obj.controlexpand._cellobj = oGridCell;
	    						obj.controlexpand._cellobjinfo = oGridCell._refobj;
	    						obj.controlexpand.on_fire_user_onlbuttondown(sButton, bAltKey, bCtrlKey, bShiftKey, nScreenX, nScreenY, nCanvasX, nCanvasY, nClientX, nClientY, oFromComp, oFromReferComp);
	    					}
	    					else if (obj.onexpandup && obj.onexpandup._has_handlers)
	    					{
	    						oGridCell = obj._bodyBand._matrix._rows[nRow]._cells[nCell];
	    						obj.controlexpand._cellobj = oGridCell;
	    						obj.controlexpand._cellobjinfo = oGridCell._refobj;					
	    						obj.controlexpand.on_fire_user_onlbuttonup(sButton, bAltKey, bCtrlKey, bShiftKey, nScreenX, nScreenY, nCanvasX, nCanvasY, nClientX, nClientY, oFromComp, oFromReferComp);
	    					}
	    					break;
	    			}
	    		}
	    	}
	    },
		
		/**
		 * Grid의 이벤트(OnHeadClickEvent)를 설정한다.
		 * @private
		 * @param  {Object} : Grid 컴포넌트
		 * @return void
		 * @see    NX.Comps._setGridOnHeadClickEvent(this, obj)
		 * @memberOf NX.Comps
		 */	    
	    _setGridOnHeadClickEvent : function(pThis,obj)
	    {
	    	var sSort = obj._sort;
	    	
	    		
			if (obj.findEventHandler("onheadclick", GridEx.sort, pThis) >= 0)
			{
				//Util.trace("NX.Comps.xjs :: _setGridOnHeadClickEvent() 핸들러 이미등록되어 있음 : " + obj.name);
			}
			else
			{	

				if (Util.isNull(sSort))
				{
					//Util.trace("NX.Comps.xjs :: _setGridOnHeadClickEvent() 그리드 헤더클릭 이벤트 제거 : " + obj.name);
				}
				else
				{
					obj.addEventHandler("onheadclick", GridEx.sort, pThis);
				}
			}	
			
			/*
			if (obj.findEventHandler("onexpanddown", GridEx.sort, pThis) >= 0)
			{
				Util.trace("NX.Comps.xjs :: _setGridOnHeadClickEvent() 핸들러 이미등록되어 있음 : " + obj.name);
			}
			else
			{	
				if (obj.sExceptColId == "ALL")
				{
					Util.trace("NX.Comps.xjs :: _setGridOnHeadClickEvent() 그리드 헤더클릭 이벤트 제거 : " + obj.name);
				}
				else
				{
					obj.addEventHandler("onexpanddown", GridEx.sort, pThis);
				}
			}			
			
			*/
	    },
	    
		/**
		 * Grid의 이벤트(OnRButtonEvent)를 설정한다.
		 * @private
		 * @param  {Object} : Grid 컴포넌트
		 * @return void
		 * @see    NX.Comps._setGridOnRButtonEvent(this, obj)
		 * @memberOf NX.Comps
		 */
		_setGridOnRButtonEvent : function(pThis, obj)
		{
			if (!obj.visible && !obj.initgrid) return;
			if (Util.trim(obj.cmmpopup) == "false") return; // Userproperty(cmmpopup)에 "false"면 그리드 우측팝업메뉴 미사용

			if (obj.findEventHandler("onrbuttondown", NX.Comps._grid_onrbuttonpress, pThis) >= 0)
			{
				Util.trace("NX.Comps.xjs :: _setGridOnRButtonEvent() 핸들러 이미등록되어 있음 : " + obj.name);
			}
			else
			{	
				if (obj.disablecontextmenu == "Y")
				{
					Util.trace("NX.Comps.xjs :: _setGridOnRButtonEvent() 그리드 컨텍스트메뉴 제거 : " + obj.name);
				}
				else
				{
					obj.addEventHandler("onrbuttondown", NX.Comps._grid_onrbuttonpress, pThis);
				}
			}
			
			var sPmnDs	= NX.Comps.GRID_RBUTTON_DS_PREFIX + "_" + obj.name;
			var sPmnID	= NX.Comps.GRID_RBUTTON_PNM_PREFIX + "_" + obj.name;
			var oPmnDs, oPmenu;	
			if (pThis.isValidObject(sPmnDs) == false)
			{
				oPmnDs = DatasetEx._get(sPmnDs, pThis);
//				oPmnDs = new Dataset;
//				oPmnDs.set_name(sPmnDs);
//				pThis.addChild(sPmnDs, oPmnDs);
			}
			else
			{
				oPmnDs = pThis.objects[sPmnDs];
			}

			if (pThis.isValidObject(sPmnID) == false)
			{
				oPmenu = new PopupMenu();
				oPmenu.init(sPmnID, "absolute", 0, 0, 100, 100);
				oPmenu.set_innerdataset(oPmnDs.name);
		//		oPmenu.set_visible(false);
				oPmenu.style.set_font("돋움체,9");
				oPmenu.set_captioncolumn("captioncolumn");
				oPmenu.set_checkboxcolumn("checkboxcolumn"); // 미설정시 보여지지 않음
				oPmenu.set_enablecolumn("enablecolumn");
				oPmenu.set_hotkeycolumn("hotkeycolumn");
				oPmenu.set_iconcolumn("iconcolumn");
				oPmenu.set_idcolumn("idcolumn");
				oPmenu.set_levelcolumn("levelcolumn");
				oPmenu.set_userdatacolumn("userdatacolumn");
		//		oPmenu.style.showeffect = "trans 500 sineInOut slide [direction top] [starttime 0]";
				
				oPmenu.addEventHandler("onmenuclick", NX.Comps._popupmenu_onmenuclick_grid, pThis);

				pThis.addChild(sPmnID, oPmenu);
				oPmenu.show();
			}

			var sPmnFilterDs = NX.Comps.GRID_RBUTTON_DS_PREFIX + "_filter_" + obj.name;
			var oPmnFilterDs = pThis.objects[sPmnFilterDs];
			if (!oPmnFilterDs)
			{
				oPmnFilterDs = DatasetEx._get(sPmnFilterDs, pThis);
//				oPmnFilterDs = new Dataset;
//				oPmnFilterDs.set_name(sPmnFilterDs);
//				pThis.addChild(sPmnFilterDs, oPmnFilterDs);
			}
		},
		
		/**
		 * 그리드의 이벤트(onrbuttonpress)를 정의- this는 호출기준. (마우스 우측버튼 클릭시 공통기능)
		 * 우측 팝업메뉴중 권한과 관련된 부분이 있는 경우 해당부분도 감안하여 처리해야함(추가, 삽입, 저장, 삭제)
		 * @private
		 * @param  {Object} : Grid 컴포넌트
		 * @return void
		 * @see    _grid_onrbuttonpress(obj)
		 * @memberOf NX.Comps
		 */
		_grid_onrbuttonpress : function(obj, e)
		{
			var nMaxFilterList = 8, nMinFilterList = 6;
			var nRow 	= e.row;
			var nCell 	= e.cell;
			var nCol	= e.col;
			var oDs 	= this.objects[obj.binddataset];
			if (!oDs || oDs.rowcount == 0) return;
			
			if (nRow >= 0)
			{
				oDs.set_rowposition(nRow);
				if (obj.selecttype == "multirow")
				{
					obj.clearSelect();
					obj.selectRow(nRow, false);
					obj.selectRow(nRow);
				}
			}
			
			var sPmnDs	= NX.Comps.GRID_RBUTTON_DS_PREFIX 	+ "_" + obj.name;
			var sPmnID	= NX.Comps.GRID_RBUTTON_PNM_PREFIX 	+ "_" + obj.name;
			if (!this.isValidObject(sPmnID) || !this.isValidObject(sPmnDs)) return; // 객체가 생성되지 않았으면 Return

			var oPmenu = this.components[sPmnID];
			var oPmnDs = this.objects[sPmnDs];
				oPmnDs.set_enableevent(false);
				NX.getApp()._gdsPopupmenu.filter("type=='G' && use=='Y'");
				oPmnDs.copyData(NX.getApp()._gdsPopupmenu, true);
				NX.getApp()._gdsPopupmenu.filter("");

				// 사용자정의 팝업메뉴 추가
				var oUsrDefPopupMenuDs = this.objects["_dsUserContext_" + obj.name];
				if (oUsrDefPopupMenuDs)
				{
					NX.Comps._setPopupMenuDs({dataset:oPmnDs, index:oPmnDs.rowcount, type:"G", sid:"-", lvl:0, enable:"true", caption:"-", userdata:"-"});
					oPmnDs.appendData(oUsrDefPopupMenuDs, true);
				}
				oPmnDs.set_enableevent(true);
			
			var bTreeGrid = GridEx.isTreeGrid(obj);

			var oInfo = {obj:obj, e:e}; // Event가 발생한 Component의 정보를 담는 객체생성
			oPmenu._sourceinfo = oInfo;

			// PopupMenu 화면정의 반영(메뉴제거) <-> disablecontextmenu : NX.Comps.deletePopupMenuItem(this, oPmnDs, "m_export");
			var sExceptMenu = Util.trim(obj.disablecontextmenu);
			var sEnableMenu = Util.trim(obj.enablecontextmenu);
			var sExceptColId = obj.exceptcolid;
			var sSort = obj._sort;
			var sHidden = obj._hiddenCol;
			
			if(Util.isNull(sSort))
			{
				if(sExceptMenu.indexOf("m_sort") < 0) sExceptMenu = sExceptMenu+",m_sort";
			}
			
			if(sEnableMenu)
			{
				if (!bTreeGrid)
				{
					if (sEnableMenu.indexOf("m_filter")   < 0) NX.Comps.deletePopupMenuItem(this, oPmenu, "m_filter");	// 자료필터
					if (sEnableMenu.indexOf("m_hidden")   < 0)
                    {
					    NX.Comps.deletePopupMenuItem(this, oPmenu, "m_hidden");	//숨기기
						NX.Comps.deletePopupMenuItem(this, oPmenu, "m_hiddenCancel");	//숨기기취소
					}	
				}				
			}
			else
			{
				NX.Comps.deletePopupMenuItem(this, oPmenu, "m_filter");
				NX.Comps.deletePopupMenuItem(this, oPmenu, "m_hidden");
				NX.Comps.deletePopupMenuItem(this, oPmenu, "m_hiddenCancel");
			}
			
			if (sExceptMenu)
			{
				if (sExceptMenu.indexOf("m_export") < 0) NX.Comps.enablePopupMenuItem(this, oPmenu, "m_export", true);
				if (!bTreeGrid)
				{
					if (sExceptMenu.indexOf("m_sort")   < 0)
					{
						NX.Comps.enablePopupMenuItem(this, oPmenu, "m_sort", true);	// 자료정렬
					}
					else
					{
						NX.Comps.deletePopupMenuItem(this, oPmenu, "m_sort");	// 자료정렬
					}
					
					if (sExceptMenu.indexOf("m_filter") < 0)
					{
						NX.Comps.enablePopupMenuItem(this, oPmenu, "m_filter", true);	// 자료필터
					}
					else
					{
						NX.Comps.deletePopupMenuItem(this, oPmenu, "m_filter");	// 자료필터
					}
					
					if (sExceptMenu.indexOf("m_hidden") < 0)
					{
						NX.Comps.enablePopupMenuItem(this, oPmenu, "m_hidden", true);	// 자료필터
						NX.Comps.enablePopupMenuItem(this, oPmenu, "m_hiddenCancel", false);	// 자료필터
					}
					else
					{
						NX.Comps.deletePopupMenuItem(this, oPmenu, "m_hidden");	// 자료필터
						NX.Comps.deletePopupMenuItem(this, oPmenu, "m_hiddenCancel");	// 자료필터
					}					

				}
				
				if (sExceptMenu.indexOf("m_fix") 		< 0)
				{
					NX.Comps.enablePopupMenuItem(this, oPmenu, "m_fix", true);		// 틀고정
				}
				else
				{
					NX.Comps.deletePopupMenuItem(this, oPmenu, "m_fix");
				}
			}
			else
			{
				if (!bTreeGrid)
				{
					NX.Comps.enablePopupMenuItem(this, oPmenu, "m_sort", 	true);	// 자료정렬
					NX.Comps.enablePopupMenuItem(this, oPmenu, "m_filter",	true);	// 자료필터
					NX.Comps.enablePopupMenuItem(this, oPmenu, "m_hidden",	true);	// 자료필터
					//NX.Comps.enablePopupMenuItem(this, oPmenu, "m_sfilter", (bActiveSingleFilter ? true : false));
				}
				
				// TODO. 기적용된 틀고정기능이 있는 경우 비활성화
				NX.Comps.enablePopupMenuItem(this, oPmenu, "m_fix",	true);			// 틀고정		
				//NX.Comps.enablePopupMenuItem(this, oPmenu, "m_autosize", true);		// AutoSizing
				//NX.Comps.enablePopupMenuItem(this, oPmenu, "m_valuecopy",true);		// 값복사
			}
			/*
			if(oPmnDs.findRow("idcolumn","m_sfilter") > -1)
			{
				if (!bTreeGrid && nRow >= 0 && nCell >=0 && oDs.getRowCount() < NX.Comps.SINGLE_FILTER_LIMIT_CNT) // (Util.isNull(obj.singlefilter) || obj.singlefilter != "false")
				{
					var bActiveSingleFilter = false;
					var sBindColNm = GridEx.getBindColId(obj, nCell);
					if (sBindColNm)
					{
						var sPmnFilterDs = NX.Comps.GRID_RBUTTON_DS_PREFIX + "_filter_" + obj.name;
						var oPmnFilterDs = this.objects[sPmnFilterDs];
							oPmnFilterDs.clearData();
							oPmnFilterDs.set_keystring("");
						
						oPmnFilterDs.copyData(oDs, false);
						oPmnFilterDs.set_keystring("S:" + sBindColNm);
	//					obj.singlefilter = "true"; 			// 추가userproperty로 조건체크
						
						var nAddIndex = oPmnDs.findRow("idcolumn", "m_sfilter");
						if (nAddIndex < 0) Util.trace("lib_com.xjs :: NX.Comps._grid_onrbuttonpress() >> 위치설정시 문제가 발생했습니다.");
						
						for (var i=0, sValue="", sSvValue="", nPmnDsCnt=oPmnFilterDs.rowcount; i<nPmnDsCnt; i++)
						{
							if (i == 0)
							{
								NX.Comps._setPopupMenuDs({dataset:oPmnDs, index:nAddIndex, type:"G", id:"m_sfilter", lvl:1, enable:"true", caption:"Initialize", userdata:"init"});
								nAddIndex++;
							}
							
							sValue = oPmnFilterDs.getColumn(i, sBindColNm);
							
							if (sSvValue != sValue)
							{
								if (nAddIndex > nMaxFilterList)
								{
									NX.Comps._setPopupMenuDs({dataset:oPmnDs, index:nAddIndex, type:"G", id:"m_sfilter", lvl:1, enabel:"true", caption:"More...", userdata:"more"});
									break;
								}
								else
								{
									NX.Comps._setPopupMenuDs({dataset:oPmnDs, index:nAddIndex, type:"G", id:"m_sfilter", lvl:1, enable:"true", caption:sValue, userdata:sValue});
								}
								nAddIndex++;
							}
							
							sSvValue = sValue;
						}
						
						bActiveSingleFilter = nAddIndex >= nMinFilterList; // 활성화여부 체크값
					}
					
					NX.Comps.enablePopupMenuItem(this, oPmenu, "m_sfilter", (bActiveSingleFilter ? true : false))				
				}
			}
			*/
			
			// 틀고정(컬럼) 활성화 체크(band "left" or "right" 설정된 경우)
			NX.Comps.enablePopupMenuItem(this, oPmenu, "m_fixclear", GridEx.isFixedGrid(obj));
			
			if(obj.autofittype == "col")
			{
				NX.Comps.deletePopupMenuItem(this, oPmenu, "m_fixcol");
			}
			else
			{
				if (nCell >=0 && (obj.hscrollbar && obj.hscrollbar.max > 0))
				{
					if (!GridEx._isMergeCell(obj, nCol) && (Util.isNull(obj.cellmovingtype) || obj.cellmovingtype == "none"))
					{
						NX.Comps.enablePopupMenuItem(this, oPmenu, "m_fixcol", true);
						NX.Comps.checkPopupMenuItem(this, oPmenu, "m_fixcol", obj.getFormatColProperty(e.col, "band") == "left");
					}
				}				
			}

			if(!Util.isNull(sHidden))
			{
				NX.Comps.enablePopupMenuItem(this, oPmenu, "m_hiddenCancel", true);	// 자료필터
			}
			
			// 틀고정(행) 활성화 체크
			if (nRow >= 0 && nCell >= 0 && oDs.getRowCount() > 0 && !GridEx.isTreeGrid(obj))
			{
				NX.Comps.enablePopupMenuItem(this, oPmenu, "m_fixrow", true);
			}
			
			oPmenu._reCalcSize();
			oPmenu.on_created();		
			if (oPmenu.isPopup()) oPmenu.closePopup();
			oPmenu.trackPopupByComponent(obj, e.clientX, e.clientY);
		},
		

		/**
		 * 그리드 우측 팝업메뉴 클릭 이벤트발생시 처리
		 * @private
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {Object} e MenuClickEventInfo객체
		 * @memberOf NX.Comps
		 */
		_popupmenu_onmenuclick_grid : function(obj, e)
		{
			if (obj.isPopup()) obj.closePopup();
			
			var oSrcInfo= obj._sourceinfo;
			var oGrid	= oSrcInfo.obj;
			var nRow	= oSrcInfo.e.row;
			var nCell	= oSrcInfo.e.cell;
			var nCol	= oSrcInfo.e.col;
			var sBindDs	= oGrid.binddataset;
			var oBindDs	= this.objects[sBindDs];
			var sItem	= Util.trim(e.id);
			
			switch (sItem)
			{
				case "m_export" : 
					if (Util.isValidFunc(this, NX.Comps.GRID_CTX_EXPORT_FUNC)) // Excel Export함수 호출
					{
						this[NX.Comps.GRID_CTX_EXPORT_FUNC].call(this);
					}
					else
					{
						this.gfn_export.call(this, [oGrid]);
					}
					break;
					
				case "m_sort" : // 소트 팝업함수 호출			
					if (Util.isValidFunc(this, NX.Comps.GRID_CTX_SORT_FUNC))
					{
						this[NX.Comps.GRID_CTX_SORT_FUNC].call(this);
					}
					else 
					{
						NX.Comps._sort_popup.call(this, oGrid, oBindDs);
					}
					break;
				/*	
				case "m_sfilter" : // 싱글 필터 처리
					oGrid.set_enableevent(false);
					oGrid.set_enableredraw(false);
					if (Util.isValidFunc(this, NX.Comps.GRID_CTX_FILTER_FUNC))
					{
						this[NX.Comps.GRID_CTX_FILTER_FUNC].call(this, "single");
					}
					else
					{
						var sUsrData = Util.trim(e.userdata);
						if (sUsrData == "init")	// 초기화처리
						{
							var sHeaderNm = Util.trim(oGrid.getCellProperty("head", nCell, "text"));
							var sDftFilterStr = DatasetEx.getFilter(oBindDs, false);
							
							oBindDs.set_enableevent(false);
							DatasetEx.setFilter(oBindDs, sDftFilterStr);
							oBindDs.set_enableevent(true);
							oBindDs._cmmsfilter = "";
							
							GridEx._clearFilterMark(oGrid); // clear mark
						}
						else if (sUsrData == "more")
						{
							NX.Comps._filter_single_popup(this, oGrid, oBindDs, nCell);
						}
						else
						{
							GridEx._clearFilterMark(oGrid);
							var nHeaderCell = GridEx.getHeadCell(oGrid, nCol, oGrid.getCellProperty("body", nCell, "row"));
							var sHeaderNm 	= Util.trim(oGrid.getCellProperty("head", nHeaderCell, "text"));
							var sBindColNm 	= GridEx.getBindColId(oGrid, nCell);
							if (sBindColNm)
							{
								var sExpr = sBindColNm + " == '" + sUsrData + "'";
								oBindDs.set_enableevent(false);
								DatasetEx.setFilter(oBindDs, sExpr);
								oBindDs.set_enableevent(true);
								
								if (sHeaderNm.indexOf(GridEx._CONST_FILTER_MARK) < 0)
								{
									oGrid.setCellProperty("head", nHeaderCell, "text", sHeaderNm + GridEx._CONST_FILTER_MARK);
								}
								oBindDs._cmmsfilter = sBindColNm + "^" + sUsrData; // userproperty추가 : 컬럼명^컬럼값
							}
						}
					}
					oGrid.set_enableevent(true);
					oGrid.set_enableredraw(true);			
					break;
				*/
				case "m_filter" 	:
					if (Util.isValidFunc(this, NX.Comps.GRID_CTX_FILTER_FUNC))
					{
						this[NX.Comps.GRID_CTX_FILTER_FUNC].call("multi");
					}
					else
					{
						NX.Comps._filter_multi_popup.call(this, oGrid, oBindDs);
					}
					break;
					
				case "m_valuecopy"	: 
					if (GridEx.isTreeGrid(oGrid)) // clipboard의 경우 IE에서만 지원(우회방법은 검토필요)
					{
						var nRealRow = oGrid.getTreeRow(nRow);
						if (nRealRow >= 0) nRow = nRealRow;
					}
					system.setClipboard("CF_UNICODETEXT", oGrid.getCellText(nRow, nCell));
					break;
				
				case "m_fixclear" :
					GridEx.clearFix(oGrid, {fixtype:"both"});
					break;
					
				case "m_fixcol" : 
					if(GridEx.isFixedGrid(oGrid)) GridEx.clearFix(oGrid, {fixtype:"both"});

					GridEx.fix(oGrid, {cell:nCell, row:nRow, col:nCol, fixtype:"col"});

					break;
				
				case "m_hidden" :
				      GridEx.setHidden(oGrid,nCol);
				    break;
					
				case "m_hiddenCancel" :
				      GridEx.setHiddenCancel(oGrid);
				    break;
					
				case "m_fixrow" : 

					if(GridEx.isFixedGrid(oGrid)) GridEx.clearFix(oGrid, {fixtype:"both"});
					
					GridEx.fix(oGrid, {cell:nCell, row:nRow, col:nCol, fixtype:"row"});

					break;
			}
		},
		
		
		/**
		 * 그리드소트 팝업함수 호출
		 * @private
		 * @param {Grid} oGrid 대상그리드
		 * @return {Array} 반환값(설정한값에 대한 배열)
		 * @example NX.Comps._sort_popup(oGrid)
		 * @memberOf NX.Comps
		 */ 
		 
		_sort_popup : function(oGrid, oDs)
		{
			var oValidDs	= oGrid.validate ? this.objects[oGrid.validate] : "";
			var sPopupId	= "com_sort";
			var sPopupUrl 	= "com::com_sort.xfdl";
			this.gfn_popup(sPopupId, sPopupUrl, {grid:oGrid, dataset:oDs, validate:oValidDs});
		},

		/**
		 * 그리드 우측팝업메뉴를 사용한 소트에서 결과값이 10개이상인경우 호출되는 팝업화면
		 * @private
		 * @param {Object} 컨테이너 pThis
		 * @param {Grid} Filter대상 Grid
		 * @param {Dataset} Filter대상 Dataset
		 * @return N/A
		 * @example NX.Comps._filter_single_popup(pThis, grdLst, dsList, 2)
		 * @memberOf NX.Comps
		 */ 
		_filter_single_popup : function(pThis, oGrid, oDs, nCell)
		{
			var sPopupId	= "com_filter_single";
			var sPopupUrl 	= "com::com_filter_single.xfdl";
			pThis.gfn_popup(sPopupId, sPopupUrl, {grid:oGrid, dataset:oDs, cell:nCell});
		},

		/**
		 * 그리드 자료필터 팝업함수 호출
		 * @private
		 * @param {Grid} oGrid 대상그리드
		 * @return N/A
		 * @example NX.Comps._filter_multi_popup(oGrid, oDs)
		 * @memberOf NX.Comps
		 */ 
		_filter_multi_popup : function(oGrid, oDs)
		{
			var oValidDs	= oGrid.validate ? this.objects[oGrid.validate] : "";
			var sPopupId	= "com_filter_multi";
			var sPopupUrl 	= "com::com_filter_multi.xfdl";
			this.gfn_popup(sPopupId, sPopupUrl, {grid:oGrid, dataset:oDs, validate:oValidDs});
		},
		

		/**
		 * 그리드 우측 팝업메뉴 innerdataset에 column값을 설정하는 함수
		 * @private
		 * @memberOf NX.Comps
		 */
		_setPopupMenuDs : function(o)
		{
			var oDs = o.dataset, nIndex = o.index, sType = o.type, sId = o.id, nLvl = o.lvl, sEnable = o.enable, sCaption = o.caption, sUserData = o.userdata;
			var nRow = oDs.insertRow(nexacro.toNumber(nIndex)+1);
			
			oDs.setColumn(nRow, "type", 			sType);
			oDs.setColumn(nRow, "idcolumn", 		sId);
			oDs.setColumn(nRow, "levelcolumn", 		nLvl);
			oDs.setColumn(nRow, "enablecolumn", 	sEnable);
			oDs.setColumn(nRow, "captioncolumn", 	sCaption);
			oDs.setColumn(nRow, "engcaptioncolumn", sCaption);
			oDs.setColumn(nRow, "userdatacolumn",	sUserData);

			return nRow;
		},
		
		/**
		 * PopupMenu 의 Column 항목값을 얻어온다.
		 * @param  {Object} PopupMenu 컴포넌트
		 * @param  {String} ID
		 * @param  {String} 컬럼ID
		 * @return {String} 팝업메뉴ID에 대한하는 컬럼값
		 * @see    NX.Comps.getPopupMenuItem(obj)
		 * @memberOf NX.Comps
		 */
		getPopupMenuItem : function(pThis, obj, sID, sColID)
		{
			var oRet;
			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				var oColInfo = oInnerDs.getColumnInfo(sColID);
				oRet = oInnerDs.getColumn(nFindRow, sColID);
			}
			return oRet;
		},

		/**
		 * PopupMenu 의 항목을 찾아 Rowindex반환
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @return {Number} row_index
		 * @memberOf NX.Comps
		 */
		findRowPopupMenuItem : function(pThis, obj, sID)
		{
			var nFindRow = -1;
			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}

			nFindRow = oInnerDs.findRow(obj.idcolumn, sID);
			return nFindRow;
		},

		/**
		 * PopupMenu 의 항목을 찾아 enable컬럼 설정
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @param  {Boolean} bEnable true/false
		 * @return {Number} row_index
		 * @memberOf NX.Comps
		 */
		enablePopupMenuItem : function(pThis, obj, sID, bEnable)
		{
			bEnable	= (bEnable == false) ? false : true;

			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				oInnerDs.setColumn(nFindRow, obj.enablecolumn, bEnable);
			}
			return nFindRow;
		},

		/**
		 * PopupMenu 의 항목을 찾아 checkbox컬럼 설정
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @param  {Boolean} bCheck true/false
		 * @return {Number} row_index
		 * @memberOf NX.Comps
		 */
		checkPopupMenuItem : function(pThis, obj, sID, bCheck)
		{
			bCheck	= (bCheck == false) ? false : true;

			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				oInnerDs.setColumn(nFindRow, obj.checkboxcolumn, bCheck);
			}

			return nFindRow;
		},

		/**
		 * PopupMenu 의 항목을 찾아 삭제처리
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @return {Number} row_index
		 * @memberOf NX.Comps
		 */
		deletePopupMenuItem : function(pThis, obj, sID)
		{
			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				oInnerDs.deleteRow(nFindRow);
			}
			
			return nFindRow;
		},

		/**
		 * PopupMenu 의 항목을 찾아 caption컬럼 설정
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @param  {String} sCaption Caption설정값
		 * @return {Number} row_index
		 * @memberOf NX.Comps
		 */
		renamePopupMenuItem : function(pThis, obj, sID, sCaption)
		{
			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				oInnerDs.setColumn(nFindRow, obj.captioncolumn, sCaption);
			}
			return nFindRow;
		},

		/**
		 * PopupMenu 의 항목을 찾아 UserData 반환
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @return {String} UserData컬럼값
		 * @memberOf NX.Comps
		 */
		getUserdataPopupMenuItem : function(pThis, obj, sID)
		{
			var bRet = "";
			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[objInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				bRet = oInnerDs.getColumn(nFindRow, obj.userdatacolumn);
			}
			return bRet;
		},

		/**
		 * PopupMenu 의 항목을 찾아 UserData설정
		 * @param  {Object} obj PopupMenu 컴포넌트
		 * @param  {String} sID 팝업메뉴ID
		 * @param  {String} sUserData UserData설정값
		 * @return {Number} row_index
		 * @memberOf NX.Comps
		 */
		setUserdataPopupMenuItem : function(pThis, obj, sID, sUserData)
		{
			var oInnerDs = obj.innerdataset;
			if (typeof oInnerDs == "string")
			{
				oInnerDs = pThis.objects[oInnerDs];
			}
			
			var nFindRow = NX.Comps.findRowPopupMenuItem(pThis, obj, sID);
			if (nFindRow >= 0)
			{
				oInnerDs.setColumn(nFindRow, obj.userdatacolumn, sUserData);
			}
			return nFindRow;
		},
		
		
		/*=================================================================================================
		 *	nexacroplatform 기본 Grid 의 재정의 된 Event Function (End)
		 *=================================================================================================*/
		

		/**
		 * Modal/Modeless Popuu 처리(공통만 사용)
		 * @private
		 * @param sId		Popup Form의 ID
		 * @param sURL 	Popup Form  URL
		 * @param sArg 	Popup Form으로 전달될 Argument
		 * @param nLeft 	Popup Form Left Position
		 * @param nTop 	Popup Form Top Position
		 * @param nWidth 	Popup Form Width
		 * @param nHeight	Popup Form Height
		 * @param sStyle Popup Form 기본 유형
		 * @param sProp 	Chile Frame의 모든 Property를 설정(추가예정????)
		 * @return : Child Frame Object
		 * @example : NX.Comps._getChildFrame(this, "test", "TEST::frm_type01_popup.xfdl", "");
		 * @memberOf NX.Comps
		 */
		_getChildFrame : function(sId, oOwnerFrame, sURL, oFrameOpt)
		{
			var nLeft	 	= oFrameOpt.left 	|| -1;
			var nTop	 	= oFrameOpt.top		|| -1;
			var nWidth		= oFrameOpt.width 	|| 0;
			var nHeight		= oFrameOpt.height 	|| 0;
			var sStyle	 	= oFrameOpt.style 	|| "";
			
			var bTitle		= true;	// default
			var bStatus		= false;
			var bTaskbar	= false;
			var bLayer		= true;
			var bResizable  = false;
			var bAutoSize	= true;
			var nBorderWidth, sBgColor, sBorderType, sBorderColor;

			if (Util.isNull(sId) || Util.isNull(sURL)) return;

			var oChildFrame = new ChildFrame;

			if (nLeft < 0) 	oChildFrame.openalign.set_halign("center");
			if (nTop < 0) 	oChildFrame.openalign.set_valign("middle");
			
			if (nWidth > 0 && nHeight > 0) bAutoSize = false;
			
			if (Util.isNull(sStyle) == false)
			{
				var aStyle = sStyle.split(" ");
				
				for (var i=0, nLen=aStyle.length; i<nLen; i++)
				{
					var aPropList	= aStyle[i].split("=");
					var sProp 		= Util.trim(aPropList[0]);
					var sValue		= Util.trim(aPropList[1]);
					var bFlag		= (sValue.toLowerCase() == "true");

					switch (sProp.toLowerCase())
					{
						case "showtitlebar" 	:	bTitle			= bFlag;	break;
						case "showstatusbar" 	:	bStatus			= bFlag;	break;
						case "showontaskbar" 	:	bTaskbar		= bFlag;	break;
						case "layered" 			:	bLayer			= bFlag;	break;
						case "resizable" 		:	bResizable  	= bFlag;	break;
						case "borderwidth" 		:	nBorderWidth 	= sValue;	break;
						case "bordercolor" 		:	sBorderColor 	= sValue;	break;
						case "bgcolor" 			:	sBgColor 		= sValue;	break;
						case "bordertype" 		:	sBorderType 	= sValue;	break;
					}
				}
			}

			oChildFrame.set_formurl(sURL);

			// sStyle내용 적용( 이부분은 init()호출전에 사용해야 함 )
			oChildFrame.set_showtitlebar(bTitle);
		//	oChildFrame.set_showcascadetitletext(false);
			oChildFrame.set_showontaskbar(bTaskbar); // Modeless인경우만 처리됨
			oChildFrame.set_autosize(bAutoSize);
			oChildFrame.set_layered(bLayer);
			
			if (!Util.isNull(nBorderWidth))	oChildFrame.style.set_border_width(nBorderWidth);
			if (!Util.isNull(sBgColor))		oChildFrame.style.set_background_color(sBgColor);
			if (!Util.isNull(sBorderColor))	oChildFrame.style.set_border_color(sBorderColor);
			if (!Util.isNull(sBorderType))	oChildFrame.style.set_border_style(sBorderType);

			oChildFrame.init(sId, nLeft, nTop, nLeft + nWidth, nTop + nHeight);

			// sStyle내용 적용( 이부분은 init()호출후에 사용해야 함)
			oChildFrame.set_showstatusbar(bStatus);
		// 	if (bLayer)
		// 	{
		// 		oChildFrame.style.set_margin("5 5 5 5");
		// 		oChildFrame.style.set_shadow("outer 0,0 7 black");
		// 	}
			oChildFrame.set_resizable(bResizable);
//			if (NX.runtime) oChildFrame._sourceform	= this;

			return oChildFrame;
		},
		
		

		/**
		 * 후처리 재정의 컴포넌트 지정
		 * @private
		 * @param	{Object} oComps : Composite 컴포넌트(Edit, Grid...)
		 * @example	NX.Comps._setPostInitComp(oComps)
		 * @memberOf NX.Comps
		 */
		_setPostInitComp : function(pThis, oComp)
		{
			Util.trace("[INFO] unloaded component : " + oComp.name);
			if (!pThis._post_init_components) pThis._post_init_components = [];
			pThis._post_init_components.push(oComp);
		},

		/**
		 * 후처리 재정의 컴포넌트를 대상으로 이벤트 등록
		 * @private
		 * @example	NX.Comps._procPostInitComp(oComps)
		 * @memberOf NX.Comps
		 */
		_procPostInitComp : function(pThis)
		{
//			var oComp, aComp = pThis._post_init_components;
//			if (aComp)
//			{
//				for (var i=0, nCnt=aComp.length; i<nCnt; i++)
//				{
//					oComp = aComp[i];
//					
//					if (oComp.___initcomp) continue;
//					
//					switch (NX.Analyzer._typeof(oComp))
//					{
//						case "calendar" : 
//							oComp.dropbutton.addEventHandler("onlbuttonup", pThis._gfn_calendar_dropbutton_onlbuttonup, pThis);
//							oComp.___initcomp = true;
//							break;
//							
//						case "combo" :
//							if (oComp.comboedit)
//							{
//								oComp.comboedit.set_autoselect(true);
//								oComp.___initcomp = true;
//							}
//							break;
//					}
//				}
//			}
		},
		

		/**
		 * Grid에 Bind된 Dataset에 Grid Bind 정보설정
		 * @private
		 * @param  {Object} : Grid 컴포넌트
		 * @return void
		 * @see    NX.Comps._setDatasetBindGridInfo(obj)
		 * @memberOf NX.Comps
		 */
		_setDatasetBindGridInfo : function(pThis, oComp)
		{
			var sBindDs	= oComp.binddataset;

			if (Util.isNull(sBindDs)) return;
			if (pThis.isValidObject(sBindDs) == false) return;

			var oBindDs	= pThis.objects[sBindDs];
			if (oBindDs)
			{
				var sComp = pThis.components[oComp.name] ? oComp.name : NX.Analyzer.path(oComp, pThis);
				var sBindGrid = Util.trim(oBindDs.bindgrid);
				// find grid of positioned in container(div, tabpage..) <-inseparated form 
				oBindDs.bindgrid = Util.isNull(sBindGrid) ? sComp : sBindGrid + "," + sComp;
				
				if (oComp.selecttype == "multirow") oBindDs._multirowgrid = true;
			}
		},

		/**
		 * 대상그리드의 소트정보를 활성화
		 * @private
		 * @param {Object} o 대상컴포넌트
		 * @param {Object} value 속성값
		 * @return N/A
		 * @see NX.Comp.setProp(this.divSearch, false);
		 * @memberOf NX.Comps
		*/		
		_setSort : function(oComp)
		{
			GridEx._clearSortMark(oComp);
			    
			var nCell = oComp.getCellCount("Head");
			var nBodyCell = oComp.getCellCount("Body");
			var bEqul = (nCell == nBodyCell) ? true : false;
			var sSort = oComp._sort;
		    
		    if(Util.isNull(sSort)) return;
		    
			for(var i=0; i<nCell; i++)
			{
			    var bMerge	= oComp.getCellProperty("head", i, "colspan") > 1 ? true : false;
			    var sDisplaytype;
			    var oInfo = {};
			    
				if(bMerge)
				{
				   continue;	
				}
				else
				{
				    if(bEqul)
				    {
				        oInfo.ColId = oComp.getCellProperty("body", i, "text");
				        oInfo.DisplayType = oComp.getCellProperty("body", i, "displaytype");
				    }
				    else
				    {
				        var nCol = oComp.getCellProperty("head", i, "col");
				        oInfo.ColId = oComp.getCellProperty("body", nCol, "text");
				        oInfo.DisplayType = oComp.getCellProperty("body", nCol, "displaytype");
				    }

					if(!this._isSortVali(oComp,oInfo)) continue;
				}
				
				oComp.setCellProperty("Head", i, "expandshow","show");
				oComp.setCellProperty("Head", i, "expandsize","20");		
			}
		},
		
		_isSortVali : function(oComp,oInfo)
		{
		    var sColId = oInfo.ColId;
		    var sDisplayType = oInfo.DisplayType;
			var aExceptColId = [];
			var aExceptDisplayType = ["checkbox","image","button","bar","tree"];
			
			if(!Util.isNull(oComp._sort))
			{
			   var sSortColId = oComp._sort;
			   aSortColId = sSortColId.split(",");
			}
			
			if(Util.isNull(sColId)) return false;
		    if(sColId.indexOf("bind:") < 0) return false;
		    sColId = sColId.slice(5);
		    if(aSortColId.indexOf(sColId) < 0) return false;
		    if(sColId.indexOf("_") == 0) return false;		    
		    if(aExceptDisplayType.indexOf(sDisplayType) > -1) return false;

		    return true;			
		},
		
		/**
		 * 대상컴포넌트의 속성을 지정하는 함수(default속성 : readonly)
		 * @param {Object} o 대상컴포넌트
		 * @param {Object} value 속성값
		 * @return N/A
		 * @see NX.Comp.setProp(this.divSearch, false);
		 * @memberOf NX.Comps
		*/
		setProp : function(o, v, oCfg)
		{
			if (!oCfg) oCfg = {};
			
			var sProp = oCfg.prop || "readonly";
			var oComp;

			if (Array.isArray(o))
			{
				for (var i=0, nCompCnt=o.length; i<nCompCnt; i++)
				{
					oComp = o[i];
					if (oComp) NX.Comps._setProperty(oComp, v, sProp);
				}
			}
			else
			{
				switch (NX.Analyzer._typeof(o))
				{
					case "div" :
						for (var i=0, nCompCnt=o.components.length; i<nCompCnt; i++)
						{
							oComp = o.components[i];
							if (oComp) NX.Comps._setProperty(oComp, v, sProp);
						}
						break;
				}
			}
		},

		/**
		 * 대상컴포넌트의 속성을 지정하는 함수
		 * @private
		 * @param {Object} o 대상컴포넌트
		 * @param {Object} v 속성값
		 * @param {String} sProp 속성
		 * @return N/A
		 * @see NX.Comps._setProperty(this.edtName, false, "visible");
		*/
		_setProperty : function(o, v, sProp)
		{
			switch (sProp)
			{
				case "readonly" :
					if (o instanceof Div) // composite comp
					{
						if (String(o.url).indexOf("composite") == 0)
						{
							o.fnSetReadonly(v);
						}
						else
						{
							NX.Comps.setProp(o, v, {prop:sProp});
						}
					}
					else if (!Util.isNull(o.readonly))
					{
						o.set_readonly(v);
						o.set_cssclass((o.readonly ? "readonly" : ""));
					}
					break;
					
				case "enable" :
					if (o instanceof Div) // composite comp
					{
						if (String(o.url).indexOf("composite") == 0)
						{
							o.fnSetEnable(v);
						}
						else
						{
							NX.Comps.setProp(o, v, {prop:sProp});
						}
					}
					else if (!Util.isNull(o.enable))
					{
						o.set_enable(v);
					}
					break;
					
				case "visible" :
					if (o instanceof Div)
					{
						NX.Comps.setProp(o, v, {prop:sProp});
					}
					else if (!Util.isNull(o.visible)) 
					{
						o.set_visible(v);
					}
					break;
			}
		},		
		
		/**
		 * 지정한컨테이터(Division)에 체크박스를 동적으로 생성하는 함수
		 * @param {Object} o 설정객체(dataset:참조dataset, target:체크박스를 배치할Division컴포넌트)
		 * @return N/A
		 * @see NX.Comps.genGrpChkBox({dataset:this.dsCmmCd, target:this.divSearch});
		 * @memberOf NX.Comps
		*/
	    genGrpChkBox : function(o)
	    {
	    	var oSize;
	    
	    	var nGapX 	= o.gapx || 20;
	    	var nGapY	  = o.gapy || 20;
	    	var nLeft 	= o.left || 10;
	    	
	    	var nWidth 	= o.checkbox_width 	|| 150;
	    	var nHeight = o.checkbox_height || 20; 
	    	var oDiv  	= o.target;		// division component
	    	var oSrcDs 	= o.dataset; 	// source dataset
	    	var sCodeColId	= o.codecolumn 	|| NX.Service._RESULT_CODE_COLUMN;
	    	var sTextColId	= o.textcolumn 	|| NX.Service._RESULT_DATA_COLUMN;
	    	var bMaxWidth 	= o.maxwidth || Util.isNull(o.checkbox_width);
	    	if (bMaxWidth === true)
	    	{
	    		// maxwidth = true로 지정시 전체 text값의 max(length)값을 사용해서 구성(영/한글시 자폭에 대한 부분은 무시)
	    		oSize = nexacro.getTextSize(oSrcDs.getMax(sTextColId), "9 Dotum");
	    		if (oSize)
	    		{
	    			nWidth = oSize.nx + 30; // checkbox object
	//    			Util.trace("최대넓이 적용 >> " + oSrcDs.getMax(sTextColId) + " width : " + nWidth);
	    		}
	    	}
	    	var nRows	= o.rows || 0;
	    	var nCols	= o.cols || 0;
	    	var nChkBoxCnt = oSrcDs.rowcount;
	    	// cols를 기준으로 처리하도록 함
	    	var nBasicWidth = nWidth + nGapX;
	    	var nShare 	= parseInt((oDiv.getOffsetWidth() - nLeft) / nBasicWidth); // 기본넓이에 배치가능한 수
	    	if (nRows == 0 && nCols == 0)
	    	{
	    		if (nShare < nChkBoxCnt)
	    		{
	    			nCols = nShare;
	    			nRows = Math.ceil(nChkBoxCnt / nShare);
	    		}
	    		else
	    		{
	    			nCols = nChkBoxCnt;
	    			nRows = 1;
	    		}
	    	}
      
	    	var nConvTop = 0; // 높이 재계산처리
	    	if (nCols > 0)
	    	{
	    		nConvTop = oDiv.getOffsetHeight() - ((nHeight * nRows) + (nGapY * (nRows - 1)));
	    		if (nConvTop > 0)
	    		{
	    			nConvTop = parseInt(nConvTop / 2);
	    		}
	    		else
	    		{
	    			nConvTop = 10; // [top]default position
	    		}
	    	}
      
	    	var nTop = o.top || nConvTop;
	    	
	//      Util.trace("=====>> nRows : " + nRows + ", nCols : " + nCols + ", nShare: " + nShare + ", nChkBoxCnt:" + nChkBoxCnt + ", nTop : " + nTop);
	    	
	    	var oCheckBox, sCheckBoxNm = "", nAddCols = 0, nAddRows = 0;    	
	    	var nTempLeft = nLeft, nTempTop = nTop;
	    	for (var i=0; i<nChkBoxCnt; i++)
	    	{
	    		sCheckBoxNm = "chkGroup" + i;
	    		oCheckBox = new CheckBox(sCheckBoxNm, "absolute", nTempLeft, nTempTop, nWidth, nHeight, null, null);
	    		// Add Object to Parent Form
	    		oDiv.addChild(sCheckBoxNm, oCheckBox);
	    		oCheckBox.set_truevalue(oSrcDs.getColumn(i, sCodeColId));
	    		oCheckBox.set_falsevalue("");
	    		oCheckBox.set_text(oSrcDs.getColumn(i, sTextColId));
	    		oCheckBox.show();
	    		
	    		++nAddCols;
	    		nTempLeft = oCheckBox.getOffsetRight() + nGapX;
	    		
	    		if (nCols && nAddCols >= nCols)
	    		{
	    		  nTempTop += (nGapY + nHeight);
	    		  nTempLeft = nLeft;
	    		  nAddCols = 0;
	    		}
	    	}
	    	
	    	oDiv.resetScroll();
	    },
    

		/**
		 * 선택된 체크박스의 값을 반환
		 * @param {Object} o 대상컴포넌트(Division)
		 * @param {Object} oCfg 설정객체(text:텍스트값반환)
		 * @param {String} sProp 속성
		 * @return N/A
		 * @see NX.Comps._setProperty(this.divSearch);
		 * @memberOf NX.Comps
		 */
	    getGrpChkBox : function(o, oCfg)
	    {
	    	if (!oCfg) oCfg = {};
	    	
	    	var sRtnValue, aRtnValue = [];
	    	var oComp, oComps = o.components;
	    	var sProp = oCfg.prop || "value";
	    	
	    	for (var i=0, nCompCnt=oComps.length; i<nCompCnt; i++)
	    	{
	    		oComp = oComps[i];
	    		if (oComp.value == oComp.truevalue) aRtnValue[aRtnValue.length] = oComp[sProp];
	    	}
	    	
	    	return aRtnValue;
	    },
	    
		/**
		 * 대상컴포넌트의 체크박스에 값설정
		 * @param {Object} oDiv 대상컴포넌트(Division)
		 * @param {Array} aValue 설정하려는값(배열)
		 * @return N/A
		 * @see NX.Comps.setGrpChkBox(this.divSrch, ["1","2"]);
		 * @memberOf NX.Comps
		 */
	    setGrpChkBox : function(oDiv, aValue, oCfg)
	    {
	    	if (!oCfg) oCfg = {};
	    	
	     	var oComp, oComps = oDiv.components, bInit = oCfg.init || true;
	     	for (var i=0, nCompCnt=oComps.length; i<nCompCnt; i++)
	     	{
	    		oComp = oComps[i];
	     		if (aValue.indexOf(oComp.truevalue) >= 0)
	     		{
	    			oComp.set_value(oComp.truevalue);
	     		}
	     		else
	     		{
	    			if (bInit) oComp.set_value("");
	     		}
	     	}
	    },
	    
		/**
		 * 그리드컴포넌트의 붙여넣기처리를 위한 textarea동적생성
		 * @private
		 * @param {Object} oForm 컨테이너객체(Form)
		 * @param {Object} oGrid 대상그리드
		 * @return N/A
		 * @see NX.Comps._setTextareaForExcel(this, this.grdList, "copy");
		 * @memberOf NX.Comps
		 */
	    _getTextareaForExcel : function(pThis, oGrid, sType)
	    {
	    	sType = sType || "paste";
	    	
			var sTxaNm = NX.Comps.GRID_EXCEL_TEXTAREA_PREFIX + sType + "_" + oGrid.name;
			var oTextArea = pThis.components[sTxaNm];
			if (!oTextArea)
			{
				oTextArea = new TextArea(sTxaNm, "absolute", oGrid.getOffsetLeft(), oGrid.getOffsetTop(), 0, 0, null, null);
				pThis.addChild(sTxaNm, oTextArea);
				oTextArea.addEventHandler("onchar", NX.Comps._textarea_clipboard_onchar, pThis);
				oTextArea.show();
				oTextArea.set_tabstop(false);
				oTextArea._target_comp = oGrid;
			}
			
			return oTextArea;
	    },
	    
		/**
		 * 그리드컴포넌트의 붙여넣기처리
		 * @private
		 * @param {Object} oForm 컨테이너객체(Form)
		 * @param {Object} oGrid 대상그리드
		 * @return N/A
		 * @see NX.Comps._pasteForExcel(this, this.grdList);
		 * @memberOf NX.Comps
		 */
	    _pasteForExcel : function(pThis, oGrid)
	    {
	    	if (nexacro.Browser == "Edge" || nexacro.Browser == "IE") 
	    	{
	    		var sClipData = String(system.getClipboard("CF_TEXT").replace(",", ""));
	    		
				var oDs = NX.getApp().gdsStorage;
				var nRow = oDs.findRow("type", "clipboard");
				if (nRow >= 0)
				{
					oDs.setColumn(nRow, "value", sClipData);
				}
				else
				{
					nRow = oDs.addRow();
					oDs.setColumn(nRow, "type", "clipboard");
					oDs.setColumn(nRow, "value", sClipData);
				}
	    		
				GridEx._copy2paste(oGrid, "paste");
	    	}
	    	else
	    	{
		    	var oTextArea = NX.Comps._getTextareaForExcel(pThis, oGrid, "paste");
		    	if (oTextArea)
		    	{
		    		oTextArea.setFocus();
		    		oTextArea.set_value("");
		    		window.document.execCommand("paste");
		    	}	    		
	    	}

	    },
	    
	    _textarea_clipboard_onchar : function(obj, e)
	    {
	    	obj._target_comp.setFocus();
	    	GridEx._setClipboardData(e.posttext);
	    	
	    	GridEx._copy2paste(obj._target_comp, "paste");
	    },
	    
		/**
		 * 그리드컴포넌트의 내용을 클립보드에 복사
		 * @private
		 * @param {Object} oForm 컨테이너객체(Form)
		 * @param {Object} oGrid 대상그리드
		 * @return N/A
		 * @see NX.Comps._copyToClipboard(this, this.grdList);
		 * @memberOf NX.Comps
		 */
	    _copyForExcel : function(pThis, oGrid)
	    {
	    	var oTextArea = NX.Comps._getTextareaForExcel(pThis, oGrid, "copy");
	    	if (oTextArea)
	    	{
	    		oTextArea.set_value(GridEx.__getCopyData(oGrid));
	    		oTextArea.setFocus();
	    		oTextArea.setSelect(0);
	    		window.document.execCommand("copy");
	    	}
	    },
	    
		/**
		 * Tab컴포넌트의 clientX값으로 tabindex를 반환
		 * @param {Object} obj Tab객체
		 * @param {Object} e 이벤트객체(mouseover : e.clientX 속성필요)
		 * @return N/A
		 * @see NX.Comps.getTabIndex(this.tabList, e);
		 * @memberOf NX.Comps
		 */
	    getTabIndex : function(obj, e)
	    {
	    	var nTabIndex = -1, nAddWidth = 0;
	    	if (e.clientX >= 0)
	    	{
	    		for (var i=0, nCnt=obj._buttonWidth.length; i<nCnt; i++)
	    		{
	    			nAddWidth += obj._buttonWidth[i];
	    			if (nAddWidth >= e.clientX)
	    			{
	    				nTabIndex = i;
	    				break;
	    			}
	    		}
	    	}
	    	return nTabIndex;
	    }
    
	});
}