﻿if (!nexacro.ExtYearPriodCalendar) 
{
    // ==============================================================================
    // nexacro.ExtYearPriodCalendar
    // ==============================================================================
   
    nexacro.ExtYearPriodCalendar = function(id, position, left, top, width, height, right, bottom, parent) 
    {
		//alert("start~~~~~~~~~~~~~~~~~~~~~");
        nexacro.Div.call(this, id, position, left, top, width, height, right, bottom, parent);
        this._draw = true;
		this.reDraw();
          
    };

	var _pExtYearPriodCalendar = nexacro._createPrototype(nexacro.Div);
    nexacro.ExtYearPriodCalendar.prototype = _pExtYearPriodCalendar;
    _pExtYearPriodCalendar._type = "ExtYearPriodCalendar";
    _pExtYearPriodCalendar._type_name = "ExtYearPriodCalendar";
	_pExtYearPriodCalendar.reDraw = function() 
	{
	    this.value = "";
	    this.title = "";
	    this._CHANGE_EVENT;
		/*
           지역선택 영역 생성
		*/
		var oYearSt = new Edit();  
		oYearSt.init("edt_yearSt","absolute", 0, 0, "47%", null, null, 0);
		this.addChild("edt_yearSt", oYearSt); 
		oYearSt.set_style("align:left middle");
		oYearSt.set_inputfilter("dot,comma,sign,symbol,alpha,space");
		oYearSt.set_inputtype("number");
		oYearSt.set_maxlength("4");
		oYearSt.addEventHandler("onkeyup", this.edt_onkeyup, this);
		oYearSt.addEventHandler("onkillfocus", this.edt_onkillfocus, this);
//		oEditLoc.set_tooltiptext(this.tooltiptext);
//		oEditLoc.set_value("전체");
		oYearSt.show();
	
		var oStaLine = new Static();  
		oStaLine.init("sta_line","absolute", "47%", 0, null, null, "47%", 0);
		this.addChild("sta_line", oStaLine); 
		oStaLine.set_style("align:center middle");
		oStaLine.set_text("~");
		oStaLine.show();
		
		var oYearEd = new Edit();  
		oYearEd.init("edt_yearEd","absolute", null, 0, "47%", null,  0, 0);
		this.addChild("edt_yearEd", oYearEd); 
		oYearEd.set_style("align:left middle");
		oYearEd.set_inputfilter("dot,comma,sign,symbol,alpha,space");
		oYearEd.set_inputtype("number");
		oYearEd.set_maxlength("4");
		oYearEd.addEventHandler("onkeyup", this.edt_onkeyup, this);
		oYearEd.addEventHandler("onkillfocus", this.edt_onkillfocus, this);
//		oEditLoc.set_tooltiptext(this.tooltiptext);
//		oEditLoc.set_value("전체");
		oYearEd.show();		
		//월력달력 오픈버튼 생성
		var oBtnCal = new Button();  
		oBtnCal.init("btn_cal","absolute", null, 2, 21, null,2,2);
		this.addChild("btn_cal", oBtnCal);
		oBtnCal.set_cssclass("btn_WF_Cal");
		oBtnCal.addEventHandler("onclick", this.btn_cal_onclick, this);
		oBtnCal.show(); 

        //원력달력 팝업 생성
		var oPopupDiv = new PopupDiv();  
		oPopupDiv.init("pdp_calYear", "absolute", 0, 0, 519, 296,null,null);
		this.addChild("pdp_calYear", oPopupDiv); 
		oPopupDiv.set_url("com::com_calendar_year_period.xfdl");
		//oPopupDiv.style.set_border( "0 none #ffffffff");
		oPopupDiv.addEventHandler("oncloseup", this.pdp_yearClose, this);
		oPopupDiv.show();
 
	};

	
	/**
	 * Bind 대상 Properties 설정
	 */   
	_pExtYearPriodCalendar.on_getBindableProperties = function () {
		return "value";
	}

	/**
	 * 데이터셋이 변경될때 값 변경처리
	 */ 
	_pExtYearPriodCalendar.on_change_bindSource = function (propid, pSendDataset, rowIdx, colIdx, colArrayIdx) {
		if (propid !== "value" || !pSendDataset || rowIdx < -1 || colIdx < -1) {
			return false;
		}

		var value = pSendDataset.getColumn(rowIdx, colIdx);

		if (this.value == value) {
			return true;
		}

		if(!this._valiateDt(value)) return false;

 	    this.value = value;

 	    if(Util.isNull(value))
 	    {
 	    	this.edt_yearSt.set_value("");
 	    	this.edt_yearEd.set_value(""); 	    	
 	    }
 	    else
 	    {
	 	    if(value.indexOf(",") > -1)
	 	    {
	 	    	var aVal = value.split(",");
	 	    	
	 	    	this.edt_yearSt.set_value(aVal[0]);
	 	    	this.edt_yearEd.set_value(aVal[1]);
	 	    }
	 	    else
	 	    {
	 	    	this.edt_yearSt.set_value(value);
	 	    	this.edt_yearEd.set_value("");
	 	    }
 	    }
        

		return true;
	};

	_pExtYearPriodCalendar.edt_onkeyup = function(obj,e)
	{
	    if(e.keycode == 13)
	    {
	    	this._setValue(this.edt_yearSt.value+","+this.edt_yearEd.value);
	    	
			if(!Util.isNull(this.__callFunc))
			{
				var oTopFrom = NX.getScriptForm(this);
				
	            try{
	               oTopFrom[this.__callFunc]();
				}catch(ex){}			
			}	    	
	    }
	};
	
	_pExtYearPriodCalendar.edt_onkillfocus = function(obj,e)
	{
		this._setValue(this.edt_yearSt.value+","+this.edt_yearEd.value);
	}
	
	_pExtYearPriodCalendar._valiateDt = function(sVal)
    {
        if(Util.isNull(sVal)) return true;

        if(!Util.isString(sVal)) return false;
       
		return true;
	}

	/**
	 * 멀티콤보 데이터 셋팅
	 */ 
    _pExtYearPriodCalendar.set_value = function(sVal)
	{
		if(this._valiateDt(sVal))
		{
            this.value = sVal; 
            
     	    if(Util.isNull(sVal))
     	    {
     	    	this.edt_yearSt.set_value("");
     	    	this.edt_yearEd.set_value(""); 	    	
     	    }
     	    else
     	    {            
	            if(sVal.indexOf(",") > -1)
	            {
	            	var aVal = sVal.split(",");
	            	this.edt_yearSt.set_value(aVal[0]);
	            	this.edt_yearEd.set_value(aVal[1]);            	
	            }
	            else
	            {
	            	this.edt_yearSt.set_value(this.value);
	            	this.edt_yearEd.set_value("");
	            }
     	    }
     	    
            this.applyto_bindSource("value", this.value);
		}		
	};

	/**
	 * 카렌다 선택 이벤트
	 */    
	_pExtYearPriodCalendar.btn_cal_onclick = function(obj,  e)
	{
        var oCal = this.edt_yearSt;  
		var oPopupDiv = this.pdp_calYear;

        oPopupDiv.set_init(this.value);

		oPopupDiv.trackPopupByComponent(oCal,0,21);

	};



	/**
	 * 드랍다운 화면 닫힐때 이벤트
	 */    
    _pExtYearPriodCalendar.pdp_yearClose = function(obj, e)
	{
    	 var sValue;
    	 
    	 if(Util.isNull(obj.fv_selecteStYy) || Util.isNull(obj.fv_selecteEdYy))
         {
    		 sValue = "";
         }
    	 else
         {
    		 sValue = obj.fv_selecteStYy+","+obj.fv_selecteEdYy;
         }
	     

         this._setValue(sValue);
         
		 if(!Util.isNull(this.__callFunc))
		 {
			 if(obj._KEY_ENTER) 
			 {			 
				 obj._KEY_ENTER = false;
			    var oTopFrom = NX.getScriptForm(this);
					
			     try{
			          oTopFrom[this.__callFunc]();
				}catch(ex){}
			 }			 			
		 }         
	};
	
	
	_pExtYearPriodCalendar._setValue = function(sValue)
	{

		 //if(Util.isNull(sValue)) return;
		 if(this.value == sValue) return;

		 this.value = sValue;
		 
 	    if(Util.isNull(sValue))
 	    {
 	    	this.edt_yearSt.set_value("");
 	    	this.edt_yearEd.set_value(""); 	    	
 	    }
 	    else
 	    {		 
			 if(sValue.indexOf(",") > -1)
			 {
				 var aVal = sValue.split(",");
				 
				 this.edt_yearSt.set_value(aVal[0]);
				 this.edt_yearEd.set_value(aVal[1]);
			 }
			 else
		     {
				 this.edt_yearSt.set_value(this.value);
				 this.edt_yearEd.set_value("");
		     }
 	    }
         

		 this.applyto_bindSource("value", this.value);

		 if(!Util.isNull(this._CHANGE_EVENT)) 
		 {
			var oTopFrom = NX.getScriptForm(this);
			
            try{
               oTopFrom[this._CHANGE_EVENT](this.name);
			}catch(ex){}
		 }
		 	
	}
	
	/**
	 * 선택변경시 호출 함수
	 */ 
    _pExtYearPriodCalendar.set_changeEvent = function(sVal)
	{
        this._CHANGE_EVENT = sVal;
	}

	/**
	 * 필수체크시 타이틀 설정
	 */	
	_pExtYearPriodCalendar.set_requiredtitle = function(sTitle)
	{
		if(!Util.isNull(sTitle))
		{
             this.title = sTitle;
	    }
	}

	/**
	 * 필수표시여부
	 */ 
    _pExtYearPriodCalendar.set_required = function(sAct)
	{
		var bAct = (sAct == "true") ? true : false;

		
		if(bAct)
		{
		   var sTitle = this.title;
		   var sValidTitleSt = "";
		   var sValidTitleEd = "";
		   
		   if(Util.isNull(sTitle))
		   {
			   sValidTitleSt = "시작년도";
			   sValidTitleEd = "종료년도";
		   }
		   else
		   {
			   if(sTitle.indexOf(",") > -1)
			   {
				   var aTitle = sTitle.split(",");
				   sValidTitleSt = aTitle[0];
				   sValidTitleEd = aTitle[0];				   
			   }
			   else
			   {
				   sValidTitleSt = sTitle+"시작년도";
				   sValidTitleEd = sTitle+"종료년도";			   
			   }
		   }
		   
		   var sValidExprSt = "title:"+sValidTitleSt+",required:true";
		   var sValidExprEd = "title:"+sValidTitleEd+",required:true";		
		   
           this.edt_yearSt.set_cssclass("point");
		   this.edt_yearSt.validate = sValidExprSt;
           this.edt_yearEd.set_cssclass("point");
		   this.edt_yearEd.validate = sValidExprEd;		 
		   this.btn_cal.set_cssclass("btn_WF_Cal_P");
		}
		else
		{
           this.edt_yearSt.set_cssclass("");
           this.edt_yearSt.validate = "";
           this.edt_yearEd.set_cssclass("");
           this.edt_yearEd.validate = "";    
           this.btn_cal.set_cssclass("btn_WF_Cal");
		}
	};


    delete _pExtYearPriodCalendar;
}