﻿if (!nexacro.ExtYearCalendar) 
{
    // ==============================================================================
    // nexacro.ExtYearCalendar
    // ==============================================================================
   
    nexacro.ExtYearCalendar = function(id, position, left, top, width, height, right, bottom, parent) 
    {
		//alert("start~~~~~~~~~~~~~~~~~~~~~");
        nexacro.Div.call(this, id, position, left, top, width, height, right, bottom, parent);
        this._draw = true;
		this.reDraw();
          
    };

	var _pExtYearCalendar = nexacro._createPrototype(nexacro.Div);
    nexacro.ExtYearCalendar.prototype = _pExtYearCalendar;
    _pExtYearCalendar._type = "ExtYearCalendar";
    _pExtYearCalendar._type_name = "ExtYearCalendar";
	_pExtYearCalendar.reDraw = function() 
	{
	    this.value = "";
	    this.title = "";
	    this._CHANGE_EVENT;
		/*
           지역선택 영역 생성
		*/
		var oYear = new Edit();  
		oYear.init("edt_year","absolute", 0, 0, null, null, 0, 0);
		this.addChild("edt_year", oYear); 
		oYear.set_style("align:left middle");
		oYear.set_inputfilter("dot,comma,sign,symbol,alpha,space");
		oYear.set_inputtype("number");
		oYear.set_maxlength("4");
		oYear.addEventHandler("onkeyup", this.edt_onkeyup, this);
		oYear.addEventHandler("onkillfocus", this.edt_onkillfocus, this);
//		oEditLoc.set_tooltiptext(this.tooltiptext);
//		oEditLoc.set_value("전체");
		oYear.show();
	
		//월력달력 오픈버튼 생성
		var oBtnCal = new Button();  
		oBtnCal.init("btn_cal","absolute", null, 2, 21, null,2,2);
		this.addChild("btn_cal", oBtnCal);
		oBtnCal.set_cssclass("btn_WF_Cal");
		oBtnCal.addEventHandler("onclick", this.btn_cal_onclick, this);
		oBtnCal.show(); 

        //원력달력 팝업 생성
		var oPopupDiv = new PopupDiv();  
		oPopupDiv.init("pdp_calYear", "absolute", 0, 0, 232, 198,null,null);
		this.addChild("pdp_calYear", oPopupDiv); 
		oPopupDiv.set_url("com::com_calendar_year.xfdl");
		oPopupDiv.style.set_border( "0 none #ffffffff");
		oPopupDiv.addEventHandler("oncloseup", this.pdp_yearClose, this);
		oPopupDiv.show();
 
	};

	
	/**
	 * Bind 대상 Properties 설정
	 */   
	_pExtYearCalendar.on_getBindableProperties = function () {
		return "value";
	}

	/**
	 * 데이터셋이 변경될때 값 변경처리
	 */ 
	_pExtYearCalendar.on_change_bindSource = function (propid, pSendDataset, rowIdx, colIdx, colArrayIdx) {
		if (propid !== "value" || !pSendDataset || rowIdx < -1 || colIdx < -1) {
			return false;
		}

		var value = pSendDataset.getColumn(rowIdx, colIdx);

		if (this.value == value) {
			return true;
		}

		if(!this._valiateDt(value)) return false;

 	    this.value = value;

        this.edt_year.set_value(this.value);

		return true;
	};

	_pExtYearCalendar.edt_onkeyup = function(obj,e)
	{
	    if(e.keycode == 13)
	    {
	    	this._setValue(this.edt_year.value);
			if(!Util.isNull(this.__callFunc))
			{
				var oTopFrom = NX.getScriptForm(this);
				
	            try{
	               oTopFrom[this.__callFunc]();
				}catch(ex){}			
			}	    	
	    }
	};
	
	_pExtYearCalendar.edt_onkillfocus = function(obj,e)
	{
		this._setValue(this.edt_year.value);
	}
	
	_pExtYearCalendar._valiateDt = function(sVal)
    {
        if(Util.isNull(sVal)) return true;

        if(!Util.isString(sVal)) return false;
        
        if(sVal.length > 4) return false;

		return true;
	}

	/**
	 * 멀티콤보 데이터 셋팅
	 */ 
    _pExtYearCalendar.set_value = function(sVal)
	{
		if(this._valiateDt(sVal))
		{
            this.value = sVal; 
			this.edt_year.set_value(this.value);
            this.applyto_bindSource("value", this.value);
		}
	};

	/**
	 * 카렌다 선택 이벤트
	 */    
	_pExtYearCalendar.btn_cal_onclick = function(obj,  e)
	{
        var oCal = this.edt_year;  
		var oPopupDiv = this.pdp_calYear;

        oPopupDiv.set_init(this.value);

		oPopupDiv.trackPopupByComponent(oCal,0,21);

	};



	/**
	 * 드랍다운 화면 닫힐때 이벤트
	 */    
    _pExtYearCalendar.pdp_yearClose = function(obj, e)
	{
	     var sValue = obj.fv_selecteYy;

         this._setValue(sValue);
         
		 if(!Util.isNull(this.__callFunc))
		 {
			 if(obj._KEY_ENTER) 
			 {			 
				 obj._KEY_ENTER = false;
			    var oTopFrom = NX.getScriptForm(this);
					
			     try{
			          oTopFrom[this.__callFunc]();
				}catch(ex){}
			 }			 			
		 }            
	};
	
	
	_pExtYearCalendar._setValue = function(sValue)
	{

		 //if(Util.isNull(sValue)) return;
		 if(this.value == sValue) return;

		 this.value = sValue;
		 
         this.edt_year.set_value(this.value);

		 this.applyto_bindSource("value", this.value);

		 if(!Util.isNull(this._CHANGE_EVENT)) 
		 {
			var oTopFrom = NX.getScriptForm(this);
			
            try{
               oTopFrom[this._CHANGE_EVENT](this.name);
			}catch(ex){}
		 }
		 	
	}
	
	/**
	 * 선택변경시 호출 함수
	 */ 
    _pExtYearCalendar.set_changeEvent = function(sVal)
	{
        this._CHANGE_EVENT = sVal;
	}

	/**
	 * 필수체크시 타이틀 설정
	 */	
	_pExtYearCalendar.set_requiredtitle = function(sTitle)
	{
		if(!Util.isNull(sTitle))
		{
             this.title = sTitle;
	    }
	}

	/**
	 * 필수표시여부
	 */ 
    _pExtYearCalendar.set_required = function(sAct)
	{
		var bAct = (sAct == "true") ? true : false;

		if(bAct)
		{
		   var sValidTitle = (Util.isNull(this.title)) ? "년도" : this.title;
		   var sValidExpr = "title:"+sValidTitle+",required:true";
		   
           this.edt_year.set_cssclass("point");
		   this.edt_year.validate = sValidExpr;
		   this.btn_cal.set_cssclass("btn_WF_Cal_P");
		}
		else
		{
           this.edt_year.set_cssclass("");
           this.edt_year.validate = "";
           this.btn_cal.set_cssclass("btn_WF_Cal");
		}
	};


    delete _pExtYearCalendar;
}