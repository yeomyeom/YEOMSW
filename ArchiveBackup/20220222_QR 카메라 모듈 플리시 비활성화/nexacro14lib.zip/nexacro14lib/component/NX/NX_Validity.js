﻿/**
 * @fileoverview 밸리데이션 관련
 */
if (!JsNamespace.exist("NX.Validity"))
{
	/**
	 * @namespace
	 * @name NX.Validity
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("NX.Validity", {
		/*=================================================================================================
		 *	Validation Function
		 *  validate
		 *  -> isValidComps -> _checkValidationExpr -> _checkValidity
		 *  -> isValidGrid	-> _checkValidationDs   -> _checkValidity
		 *===============================================================================================*/
		/**
		 * (공통만사용)Validation 체크하는 데이터셋을 체크한다.
		 * @param {Dataset} dsValid	: valiation 체크하는 데이터셋
		 * @return boolean
		 * @example checkValidDataset(ds_Valid)
		 *
		 * @memberOf NX.Validity
		 */
			
		/**
		 * constructor
		 * @param {Object} o 컨테이너컴포넌트(form)
		 * @memberOf NX.Service
		 */
		constructor : function(o) 
		{
			this._container = o.container;
			this.validate 	= NX.Validity.validate;
		},
		
		checkValidDataset : function(oDsValid)
		{
			if (oDsValid.rowcount != 1)
			{
				Util.trace("NX_Validitey.xjs :: checkValidDataset() => valid dataset 설정에러\n데이터셋 " + oDsValid.name + "는 rowcount가 1건이어야 합니다");
				return false;
			}
			
			for (var i=0, nSize=oDsValid.colcount-oDsValid.getConstCount(); i<nSize; i++)
			{
				var oColInfo = oDsValid.getColumnInfo(i);
				if (Util.isNull(oColInfo)) continue;
				if (oColInfo.type.toUpperCase() != "STRING")
				{
					Util.trace("NX_Validitey.xjs :: checkValidDataset() => valid dataset 설정에러\n데이터셋 " + oDsValid.name + "의 column " + oColInfo.name + "의 타입을 String형으로 변경하세요");
					return false;
				}
			}
			return true;
		},

		/**
		 * Validation을 체크
		 * @param  oGridOrComposite : Grid나 (Div or Tabpage)를 넘긴다.
		 * @return boolean
		 * @see    validate(div_search);	// Div으로 validate check
		 *         validate(grd); 			// Grid로 validate check
		 *
		 * @memberOf NX.Validity
		 */
		validate : function(obj, oCfg)
		{
			var oComp, aComps = [], oContainer = this._container;
			
			var bAll = false;
						
			if(!Util.isNull(oCfg)) bAll = Util.isNull(oCfg.all) ? false : oCfg.all;			
			
			if (Array.isArray(obj))
			{
				aComps = obj;
			}
			else
			{
				aComps.push(obj);
			}

			for (var i=0, nLen=aComps.length; i<nLen; i++)
			{
				oComp = aComps[i];
				switch (NX.Analyzer._typeof(oComp))
				{
					case "tab" :
//						for (var n=0, sizen=oComp.tabpages.length; n<sizen; n++)
// 						{
// 							if (!NX.Validity.isValidComps(oComp.tabpages[n])) return false;
// 						}
						break;
						
					case "div" 		:
						if (Util.isFunction(oComp.validate) && !oComp.validate())
						{
							oComp.setFocus();
							return false;
						}
						else
						{
							if (!NX.Validity.isValidComps(oContainer, oComp)) return false;
						}
						break;
						
					case "tabpage" 	:
						if (!NX.Validity.isValidComps(oContainer, oComp)) return false;
						break;
						
					case "grid" 	:
						if (!NX.Validity.isValidGrid(oContainer, oComp, bAll)) return false;
						break;
					
					case "edit" 	:
					case "maskedit" :
					case "combo" 	:
					case "calendar" :
					case "checkbox" :
					case "textarea" : 
					case "listbox" 	: 
					case "radio" 	: 
					case "imageviewer" :
						if (!NX.Validity.isValidComp(oContainer, oComp)) return false;
						break;
					
					default :
						Util.trace("유효성체크를 지원하지 않는 컴포넌트[" + oComp.name + "] 입니다.");
						break;
				}
			}
			return true;
		},

		/**
		 * Division Validation 체크.
		 * @param {Division} vObj : Validation Check 대상(Division Object)
		 * @return {Boolean} true/false
		 * @example  isValidComps(vObj)
		 *
		 * @memberOf NX.Validity
		 */
		isValidComps : function(pThis, oComps, bAll)
		{
			var	oComp, aCompList = NX.Validity.sortByTabOrder(pThis, oComps);
			for (var i=0, nLength=aCompList.length; i<nLength; i++)
			{
				oComp = aCompList[i];
				switch(NX.Analyzer._typeof(oComp))
				{
					case "div" 		:
						if (Util.isFunction(oComp.validate) && !oComp.validate())
						{
							oComp.setFocus();
							return false;
						}
						else
						{
							if (!NX.Validity.isValidComps(pThis, oComp)) return false;
						}
						break;
						
					case "tabpage" 	:
						if (!NX.Validity.isValidComps(pThis, oComp)) return false;
						break;
						
					case "grid" 	:
						if (!NX.Validity.isValidGrid(pThis, oComp, bAll)) return false;
						break;
					
					case "edit" 	:
					case "maskedit" :
					case "combo" 	:
					case "calendar" :
					case "checkbox" :
					case "textarea" : 
					case "listbox" 	: 
					case "radio" 	: 
					case "imageviewer" :
						if (!NX.Validity.isValidComp(pThis, oComp)) return false;
						break;
						
//					default :
//						Util.trace("유효성체크를 지원하지 않는 컴포넌트[" + oComp.name + "] 입니다.");
//						break;
				}
			}
			return true;
		},
		
		/**
		 * Composite 컴포넌트 내의 Component들을 taborder 순으로 정렬하여 리턴한다.
		 * @param  {Object} oComposite : Composite 컴포넌트(div, tab, tabpage)
		 * @return {Array} object aay
		 *
		 * @memberOf NX.Validity
		 */
		sortByTabOrder : function(pThis, oComps)
		{
			var aSort = [];
			NX.Comps._retrieveComps(pThis, oComps, function(oComp, nLvl, oOwner){
				if (oComp.taborder == undefined) return;
				if (nLvl == 1) oOwner._sort = 1;
				oComp._sort = (oOwner._sort) + ((oComp.taborder+1) / Math.pow(10, nLvl));
				aSort.push(oComp);
			});

			aSort.sort(NX.Validity._tabOrderSort);
			return aSort;
		},

		/**
		 * 컴포넌트단위 Validation 체크.
		 * @param {Object} oComp : Validation Check 대상 컴포넌트
		 * @return {Boolean} true/false
		 * @example  isValidComp(this, oComp)
		 *
		 * @memberOf NX.Validity
		 */
		isValidComp : function(pThis, oComp)
		{
			var sValidExpr = oComp.validate;
			if (sValidExpr && oComp.visible && oComp.enable)
			{
				var sPropType = oComp instanceof Calendar ? "text" : "value";
				if (NX.Validity._checkValidationExpr(pThis, oComp, sValidExpr, sPropType) == false)
				{
/* for async : NX.Validity._validityMsgBoxCallback
					if (oComp instanceof Calendar)
					{
						oComp.calendaredit.setFocus();
					}
					else
					{
						oComp.setFocus();
					}
*/
					return false;
				}
			}
			return true;
		},

		/**
		 * Check 항목에 대한 Object의 Value 확인.
		 * @param {Grid} pThis	Container객체
		 * @param {Grid} oGrid	Validation 체크 대상 Grid
		 * @param {Object} oCfg	all속성:trrue(전체Row),false(default : undefined)
		 * @return  {Boolean} true/false
		 * @example  isValidGrid(this, oGrid)
		 *
		 * @memberOf NX.Validity
		 */
		isValidGrid : function(pThis, oGrid, bAll)
		{
//			if (!oGrid.validate) return true;
			
			var oValidDs = pThis.objects[oGrid.validate] || pThis.objects[oGrid.binddataset + "_valid"];
			if (!oValidDs)
			{
				Util.trace("Delete gfn_validate <= not found validity dataset : " + oGrid.name);
				return true;
			}
			
			if (!this.checkValidDataset(oValidDs)) return false;
		
			var oBindDs	= pThis.objects[oGrid.binddataset];
			var nRowCnt = oBindDs.getRowCount();
			var nColCnt = oValidDs.getColCount();

			for (var i=0; i<nRowCnt; i++)
			{
				if (bAll || DatasetEx.getRowType(oBindDs, i) == Dataset.ROWTYPE_INSERT || DatasetEx.getRowType(oBindDs, i) == Dataset.ROWTYPE_UPDATE)
				{
					for (var j=0; j<nColCnt; j++)
					{
						var oRtnVal = NX.Validity._checkValidationDs(pThis, i, j, oGrid, oBindDs, oValidDs);
						if (oRtnVal != true)
						{
							var oParam = {validity:{target:NX.Analyzer.path(oGrid, pThis), validdataset:oValidDs.name, col:j}, restrict:true, callback:NX.Validity._validityMsgBoxCallback};
							
							if(oGrid.selecttype == "area")
							{
								oGrid.selectArea(i,j,i,j);
							}
							else
							{
							   oBindDs.set_rowposition(i);	
							}
							
							
							pThis.gfn_msgBox("M", oRtnVal, oParam);  // validation message
							
/* for async : NX.Validity._validityMsgBoxCallback
							if (String(oValidDs.getColumn(0, j)).indexOf("focus") == -1)
							{
//								Util.trace("===Grid Validation Error=== \n  row index= " + i + ", column index=" + j + " , column name=" + dsObj.getColID(j) + "\n  Error Message : " + oRtnVal);
								oGrid.setCellPos(oGrid.getBindCellIndex("body", oValidDs.getColID(j)));
								oGrid.setFocus();
							}
							else
							{
								var aItems 	= oValidDs.getColumn(0,j).split(",");
								var aItem 	= [];
								for (var i=0, nLength=aItems.length; i<nLength; i++)
								{
									aItem = aItems[i].split(":");
									if (aItem[0] == "focus")
									{
										pThis.aItem[1].setFocus();
										return false;
									}
								}
							}
*/
							return false;
						}	
					}
				}
			}
			return true;
		},

		_tabOrderSort : function(a, b)
		{
			if (a._sort > b._sort) return 1;
			else if (a._sort < b._sort) return -1;
			return 0;
		},
		
		/**
		 * Check 항목을 user property에 설정
		 * @private
		 * @param {Array} aItems		설정객체(comp : 대상컴포넌트, expr : 수식)
		 * @return N/A
		 * @example _addValidationExpr(aItems)
		 *
		 * @memberOf NX.Validity
		 */
		_addValidationExpr : function(aItems)
		{
			var oItem, oComp, sExpr;
			for (var i=0, nCnt=aItems.length; i<nCnt; i++)
			{
				oItem = aItems[i];
				oComp = oItem.comp;
				sExpr = oItem.expr;
				if (oComp && sExpr)
				{
					oComp.validate = sExpr;
				}
			}
			
		},

		/**
		 * Check 항목에 대한 Object의 Value 확인
		 * @private
		 * @param {Number} rowPos		Check Dataset의 Row Position
		 * @param {Number} colIdx 		Valid Dataset의 Row Column(*)
		 * @param {Grid} objGrd			Check 대상 Grid Object
		 * @param {Dataset} objDs		Grid Binding Dataset
		 * @param {Dataset} objDsValid	Check Info Dataset
		 * @return true/string(Message)
		 * @example _checkValidationDs(pThis, nRowPos, nColIdx, oGrid, oBindDs, oValidDs)
		 *
		 * @memberOf NX.Validity
		 */
		_checkValidationDs : function(pThis, nRowPos, nColIdx, oGrid, oBindDs, oValidDs)
		{
			var sColNm		= oValidDs.getColID(nColIdx); 		// column name
			var sValidExpr 	= oValidDs.getColumn(0, sColNm); 	// validate item

			if (Util.isNull(sValidExpr)) return true;

			var aValidExpr 	= sValidExpr.split(",");
			var sTitle 		= aValidExpr[0].split(":")[1]; 			// title
			var oValue 		= oBindDs.getColumn(nRowPos, sColNm);
			var oRtnVal;
			for (var i=1, nLength=aValidExpr.length; i<nLength; i++)
			{
				oRtnVal = NX.Validity._checkValidity(oBindDs, aValidExpr[i], sTitle, oValue, {container:this._container, rowposition:nRowPos});
				if (oRtnVal == true)
				{
					continue;
				}
				else
				{
					return oRtnVal;
				}
			}
			
			return true;
		},

		/**
		 * validation express 
		 * @private
		 * @param  pThis		Container객체(Form)
		 * @param  oComp		체크 대상 Object
		 * @param  sValidExpr	Check 항목(","로 구분)
		 * @param  sPropType	Object 속성 확인(value/text)
		 * @example  _checkValidationExpr(pThis, oComp, sValidExpr, sPropType)
		 *
		 * @memberOf NX.Validity
		 */
		_checkValidationExpr : function(pThis, oComp, sValidExpr, sPropType) 
		{
			var sValue;
			var aValidExpr = sValidExpr.split(",");
			if (aValidExpr.length < 2) return true;
			
		//	Util.trace("_checkValidationExpr check >>>> " + oComp.name + " , " + sValidExpr + " , " + sPropType);

			// 유효성체크 메시지 처리시 사용될 타이틀 처리
			var aItems 	= aValidExpr[0].split(":");
			var sTitle 	= aItems[1];

			if (oComp instanceof ImageViewer)
			{
				sValue = oComp.image;
			}
			else if (sPropType == "value")
			{
				sValue = oComp.value;
			}
			else
			{
				sValue = String(oComp.text).replace(/[-.\/]/g, ""); // for date mask
			}

			for (var j=1, nLen=aValidExpr.length; j<nLen; j++)
			{
				oRtnVal = NX.Validity._checkValidity(oComp, aValidExpr[j], sTitle, sValue, {container:pThis});
				if (oRtnVal != true)
				{
					pThis.gfn_msgBox("M", oRtnVal, {validity:{target:NX.Analyzer.path(oComp, pThis)}, callback:NX.Validity._validityMsgBoxCallback});
//					pThis.gfn_msgBox("M", oRtnVal, {validity:{target:NX.Analyzer.path(oComp, pThis)}, callback:"_gfn_validityMsgBoxCallback"});
					return false;
				}
			}
			return true;
		},
		
	  /**
		* callback function of validity messagebox
		* @private
		* @param sPopupId	popupId
		* @param sValidExpr valid_object
		*/
//		_validityMsgBoxCallback : function(pThis, sPopupId, sValidInfo)
		_validityMsgBoxCallback : function(sPopupId, sValidInfo)
		{
			var pThis = this;
			if (sValidInfo)
			{
				var oValidInfo = {}, aItem, aValidInfo = sValidInfo.split(NX.DELIM1);
				for (var i=0, nLen=aValidInfo.length; i<nLen; i++)
				{
					aItem = Util.trim(aValidInfo[i]).split(NX.DELIM2);
					oValidInfo[aItem[0]] = aItem[1];
				}
				
				var sPath = Util.trim(oValidInfo.target);
				var oComp = sPath ? NX.Analyzer.comp(pThis, sPath) : "";
				if (oComp)
				{
					if (oComp instanceof Grid)
					{
						var nCol = oValidInfo.col;
						var oValidDs = pThis.objects[oValidInfo.validdataset];
						if (oValidDs)
						{
							if (String(oValidDs.getColumn(0, nCol)).indexOf("focus") == -1)
							{
								oComp.setCellPos(oComp.getBindCellIndex("body", oValidDs.getColID(nCol)));
								oComp.setFocus();
							}
							else
							{
								var aItem = [], aItems = oValidDs.getColumn(0, nCol).split(",");
								for (var i=0, nLength=aItems.length; i<nLength; i++)
								{
									aItem = aItems[i].split(":");
									if (aItem[0] == "focus") pThis.aItem[1].setFocus();
								}
							}
						}
					}
					else
					{
						if (oComp instanceof Calendar)
						{
							oComp.calendaredit.setFocus();
						}
						else
						{
							oComp.setFocus();
						}
					}
				}
				else
				{
					Util.trace("NX_Validity.xjs :: _validityMsgBoxCallback() => not found component : " + sPath);
				}
			}
		},

		/**
		 * check the validation about valid expression(integrated about common components & grid)
		 * @private
		 * @param oComp		target component
		 * @param sValidExpr validation expression
		 * @param sTitle		message title
		 * @param oValue		message title
		 * @param oOptional		extra setup option(속성:rowposition,container)
		 * @return  true/string(Message)
		 * @example  _checkValidity(oComp, sValidExpr, sTitle, oValue, oOptional)
		 *
		 * @memberOf NX.Validity
		 */
		_checkValidity : function(oComp, sValidExpr, sTitle, oValue, oOptional)
		{
			if (!oOptional) oOptional = {};
			
			var oRtnVal     = true;
			var aValidExpr 	= sValidExpr.split(":");
			var nRowPos		= oOptional.rowposition;
			var oContainer	= oOptional.container;
			
			// remove space about validation expression
		// 	for (var i=0, nLength=aValidExpr.length; i<nLength; i++)
		// 	{
		// 		aValidExpr[i] = Util.trim(aValidExpr[i]);
		// 	}
			
			if(typeof(oValue) == "string") oValue = Util.trim(oValue);
			
			var sItem = Util.trim(aValidExpr[0]);
			var sItemValue = aValidExpr[1];
			if (Util.isNull(sItem) || (sItem.indexOf("required") < 0 && Util.isNull(Util.trim(oValue))))
			{
				return oRtnVal;
			}

			switch (sItem)
			{
				case "required" :
					if (Util.isNull(Util.trim(oValue)))
					{
						if (sItemValue == "true")
						{
							//oRtnVal = NX._getUiMsg("UI011", [sTitle, "필수"]); // sTitle + "은(는) 필수입력 항목입니다.";
							oRtnVal = Util.getComMsg("E.ZZ.ZZ.0001",sTitle);
						}
					}
					break;
					
				case "orgrequired" :
					if (Util.isNull(oValue))
					{
						if (sItemValue == "true")
						{
							//oRtnVal = NX._getUiMsg("UI011", [sTitle, "필수"]); // sTitle + "은(는) 필수입력 항목입니다.";
							oRtnVal = Util.getComMsg("E.ZZ.ZZ.0001",sTitle);
						}
					}
					break;
					
				case "ip" :
					if (!Util.isIP(oValue))
					{
						//oRtnVal = NX._getUiMsg("UI011", [sTitle, "IP Address"]); // sTitle + "은(는) IP Address 입력 항목입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0043",[sTitle,"IP Address"]);
						
					}
					break;
					
				case "digits" :
					if (!Util.isDigit(oValue))
					{
						//oRtnVal = NX._getUiMsg("UI011", [sTitle, "숫자"]); // sTitle + "은(는) 숫자 입력 항목입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0043",[sTitle,"숫자"]);
					}
					break;

				case "date" :
					if (!Util.isValidDate(oValue))
					{
						//oRtnVal = NX._getUiMsg("UI010", [sTitle]); // sTitle + "은(는) 정확한 날짜를 입력하십시요.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0002",sTitle);
					}
					break;

				case "dateym" :
					if (!Util.isValidDate(oValue + "01"))
					{
						//oRtnVal = NX._getUiMsg("UI011", [sTitle, "년월"]); // sTitle + "은(는) 년월 입력 항목입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0004",sTitle);
					}
					break;

				case "telno" :
					if (!Util.isTelNo(oValue))
					{
						//oRtnVal = NX._getUiMsg("UI012", [sTitle, "전화번호"]); // sTitle + "은(는) 전화번호 형식이 잘못되었습니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0044",[sTitle,"전화번호"]);
					}
					break;
					
				case "jumin" :
					if (!Util.isRsrNo(oValue))
					{
						//oRtnVal = NX._getUiMsg("UI012", [sTitle, "주민번호"]); // sTitle + "은(는) 주민번호 형식이 잘못되었습니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0044",[sTitle,"주민번호"]);
					}
					break;

				case "max" :
					if (parseFloat(oValue) > parseFloat(sItemValue))
					{
						//oRtnVal = NX._getUiMsg("UI013", [sTitle, "최대값", sItemValue]); // sTitle + " 값의 최대값은 " + sItemValue + "입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0010",[sTitle,sItemValue]);
						
					}
					break;

				case "min" :
					if (parseFloat(oValue) < parseFloat(sItemValue))
					{
						//oRtnVal = NX._getUiMsg("UI013", [sTitle, "최소값", sItemValue]); // sTitle + " 값의 최소값은 " + sItemValue + "입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0011",[sTitle,sItemValue]);
					}
					break;

				case "maxlength" :
					oValue = oValue.valueOf();
					if (oValue.length > parseInt(sItemValue))
					{
						//oRtnVal = NX._getUiMsg("UI014", [sTitle, "최대", sItemValue]); // sTitle + " 최대 길이는 " + sItemValue + "입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0012",[sTitle,sItemValue]);
					}
					break;

				case "minlength" :
					oValue = oValue.valueOf();
					if (oValue.length < parseInt(sItemValue))
					{
						//oRtnVal = NX._getUiMsg("UI014", [sTitle, "최소", sItemValue]); // sTitle + " 최소 길이는 " + sItemValue + "입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0013",[sTitle,sItemValue]);
					}
					break;

				case "maxlengthB" :
					oValue = oValue.valueOf();
					if (Util.lenb(oValue) > parseInt(sItemValue))
					{
						//oRtnVal = sTitle + " 최대 길이는 " + sItemValue + "입니다.\n(한글 2Byte, 영문/숫자 1Byte)";
						//oRtnVal = NX._getUiMsg("UI030", [sTitle, "최대", sItemValue]);
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0016",[sTitle,sItemValue]);
					}
					break;

				case "minlengthB" :
					oValue = oValue.valueOf();
					if (Util.lenb(oValue) < parseInt(sItemValue))
					{
						//oRtnVal = sTitle + " 최소 길이는 " + sItemValue + "입니다.\n(한글 2Byte, 영문/숫자 1Byte)";
						//oRtnVal = NX._getUiMsg("UI030", [sTitle, "최소", sItemValue]);
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0017",[sTitle,sItemValue]);
					}
					break;

				case "equallen" :
					oValue = oValue.valueOf();
					if (oValue.length != parseInt(sItemValue))
					{
						//oRtnVal = NX._getUiMsg("UI015", [sTitle, sItemValue]); // sTitle + " 길이는 " + sItemValue + "입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0047",[sTitle,sItemValue]);
					}
					break;

				case "comparemax" : 
					var nCompareMax = parseFloat(oComp instanceof Dataset ? oComp.getColumn(nRowPos, sItemValue) : NX.Analyzer.find(sItemValue, oContainer).value);
					oValue = oValue.toString();
					if (parseFloat(oValue.replace("-", "")) < nCompareMax)
					{
						//oRtnVal = NX._getUiMsg("UI016", [sTitle, nCompareMax]); // sTitle + "이(가) " + nCompareMax + " 보다 작습니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0008",[sTitle,nCompareMax]);
					}
					break;

				case "comparemin" :
					var nCompareMin = parseFloat(oComp instanceof Dataset ? oComp.getColumn(nRowPos, sItemValue) : NX.Analyzer.find(sItemValue, oContainer).value);
					oValue = oValue.toString();
					if (parseFloat(oValue.replace("-", "")) > nCompareMin)
					{
						//oRtnVal = NX._getUiMsg("UI017", [sTitle, nCompareMin]); // sTitle + "이(가) " + nCompareMin + " 보다 큽니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0009",[sTitle,nCompareMin]);
					}
					break;
				
				case "comparemaxmonth" : 
					var nCompareMaxMonth = parseInt(oComp instanceof Dataset ? oComp.getColumn(nRowPos, sItemValue) : String(NX.Analyzer.find(sItemValue, oContainer).value).substr(0,6));
					if (parseInt(oValue.replace(/[-,\/]/g, "").substr(0,6)) < nCompareMaxMonth)
					{
						//oRtnVal = NX._getUiMsg("UI016", [sTitle, nCompareMaxMonth]); // sTitle + "이(가) " + nCompareMaxMonth + " 보다 작습니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0008",[sTitle,nCompareMaxMonth]);
					}
					break;

				case "compareminmonth" :
					var nCompareMinMonth = parseInt(oComp instanceof Dataset ? oComp.getColumn(nRowPos, sItemValue) : String(NX.Analyzer.find(sItemValue, oContainer).value).substr(0,6));
					if (parseInt(oValue.replace(/[-,\/]/g, "").substr(0,6)) > nCompareMinMonth)
					{
						//oRtnVal = NX._getUiMsg("UI017", [sTitle, nCompareMinMonth]); // sTitle + "이(가) " + nCompareMinMonth + " 보다 큽니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0009",[sTitle,nCompareMinMonth]);
					}
					break;

				case "equalto" :
					var oCompValue = oComp instanceof Dataset ? oComp.getColumn(nRowPos, sItemValue) : NX.Analyzer.find(sItemValue, oContainer).value;
					if (oValue != oCompValue)
					{
						//oRtnVal = NX._getUiMsg("UI018", [sTitle, oCompValue]); // sTitle + "은(는) " + sItemValue + "와(과) 다릅니다."
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0022",[sTitle,oCompValue]);
					}
					break;

				case "range" :
					var oFromValue 	= oComp instanceof Dataset ? oComp.getColumn(nRowPos, sItemValue) : sItemValue;//NX.Analyzer.find(sItemValue, this._container).value;
					var oToValue 	= oComp instanceof Dataset ? oComp.getColumn(nRowPos, aValidExpr[2]) : aValidExpr[2];//NX.Analyzer.find(aValidExpr[2], this._container).value;
					if (parseInt(oValue) < parseInt(oFromValue) || parseInt(oValue) > parseInt(oToValue))
					{
						//oRtnVal = NX._getUiMsg("UI019", [sTitle, oFromValue, oToValue]); // sTitle + "은(는) " + oFromValue + " ~ " + oToValue + " 사이의 값입니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0023",[sTitle,oFromValue,oToValue]);
					}
					break;
					
				case "declimit" :
					oValue = String(oValue);
					var nDotIdx = oValue.indexOf(".");
					if (nDotIdx == -1){}
					else
					{
						var nDecLength = oValue.substr(nDotIdx+1, oValue.length);
						if (nDecLength.length > parseInt(sItemValue))
						{
							//oRtnVal = NX._getUiMsg("UI020", [sTitle, sItemValue]); // sTitle + "은(는) " + sItemValue + " 자리로 구성되어야 합니다.";
							oRtnVal = Util.getComMsg("E.ZZ.ZZ.0024",[sTitle,sItemValue]);
						}
					}
					break;

				case "bothlimit" :
					oValue = String(oValue);
					var nDotIdx = oValue.indexOf(".");
					if (nDotIdx == -1)
					{
						if (oValue.length > parseInt(sItemValue))
						{
							//oRtnVal = NX._getUiMsg("UI021", [sTitle, sItemValue, aValidExpr[2]]); // sTitle + "은(는) 정수부 " + sItemValue + " 자리, 소수부 " + aValidExpr[2] + " 자리로 구성되어야 합니다.";
							oRtnVal = Util.getComMsg("E.ZZ.ZZ.0025",[sTitle,sItemValue,aValidExpr[2]]);
						}
					}
					else {
						var nIntLength = oValue.substring(0, nDotIdx);
						var nDecLength = oValue.substr(nDotIdx+1, oValue.length);
						if (nIntLength.length > parseInt(sItemValue) || nDecLength.length > parseInt(aValidExpr[2])) 
						{
							//oRtnVal = NX._getUiMsg("UI021", [sTitle, sItemValue, aValidExpr[2]]); // sTitle + "은(는) 정수부 " + sItemValue + " 자리, 소수부 " + aValidExpr[2] + " 자리로 구성되어야 합니다.";
							oRtnVal = Util.getComMsg("E.ZZ.ZZ.0025",[sTitle,sItemValue,aValidExpr[2]]);
						}
					}
					break;

				case "charat" :
					var nIndex = Util.isNull(aValidExpr[2]) ? 0 : aValidExpr[2];
					if (oValue.charAt(nIndex) != sItemValue)
					{
						//oRtnVal = NX._getUiMsg("UI022", [sTitle, (nIndex+1), sItemValue]); // sTitle + " 의 " + (nIndex + 1) + " 자리는 " + sItemValue + "로 구성되어야 합니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0026",[sTitle,(nIndex+1),sItemValue]);
					}
					break;
					
				case "email" :
					if (!Util.isEmail(oValue))
					{
						//oRtnVal = NX._getUiMsg("UI012", [sTitle, "이메일"]); // sTitle + "은(는) 주민번호 형식이 잘못되었습니다.";
						oRtnVal = Util.getComMsg("E.ZZ.ZZ.0044",[sTitle,"이메일"]);
					}
					break;					
				default :
					oRtnVal = "Validation Items[" + sItem + "]이 명확하지 않습니다.";
					break;
			}

			return oRtnVal;
		}
		
	});
}
