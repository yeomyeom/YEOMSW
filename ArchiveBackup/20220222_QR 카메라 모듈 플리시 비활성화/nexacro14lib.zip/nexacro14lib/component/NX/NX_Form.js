/**
 * @fileoverview 글로벌 공통함수
 */

/**
 * @namespace
 * @name global
 */
var pForm = nexacro.Form.prototype;

/**
 * 화면초기화 공통함수
 * @param  {Object} obj	초기화대상 Form
 * @param  {Object} e	Form 의 LoadEventInfo
 * @return n/a
 * @example this.gfn_initForm(obj, e);
 * @memberof global
 */
pForm.gfn_initForm = function(obj, e, oConfig)
{
	NX._setDefaultSvcUrl();	// for quickview
	
	switch (this.fvFormType)
	{
		case NX.FORM_FRAME : 
			obj.addEventHandler("onkeyup", this.gfn_form_onkeyup, this);
			break;
			
		case NX.FORM_MAIN :	// Main
			obj.addEventHandler("onkeyup", this.gfn_form_onkeyup, this);
			var oTopForm = this.gfn_getWorkForm();
			if (NX.isFrame() && oTopForm)
			{
				oTopForm.fvBeforeClose = true;
				oTopForm.setDefaultWidth();
				NX.Comps._setAuthority(this);
			}
			break;
			
		case NX.FORM_TAB :	// Tab
		case NX.FORM_DIV :	// Division
			NX.Comps._setAuthority(this);
			break;
			
		case NX.FORM_POP :	// Popup
			NX.Comps._setAuthority(this);

//			obj.titletext = Util.trim(obj.titletext) + " [" + obj.name + "]";
			obj.__popupdiv = [];
//			obj.addEventHandler("onsize", this._gfn_form_onsize, this);
			obj.addEventHandler("onkeyup", this.gfn_form_onkeyup, this);
			
			//공통 호출 서비스 경로 재설정
			this.gfn_setCommSvc();
			
			break;
	}
	
	NX.Comps._interceptEvent(this, obj);	// 컴포넌트 재정의
	NX.Comps._developerSupport(this, obj);	// 개발공통 체크
	
	obj.setFocus(); // for async load
}


/**
 * 공통버튼 설정함수
 * @param  {String} sAuthLst	버튼권한문자열 R(조회)S(저장)D(삭제)P(출력)A(승인)F(기안)
 * @return n/a
 * @example this.gfn_setCmmBtn("RS");
 * @memberof global
 */
pForm.gfn_setCmmBtn = function(sAuthLst)
{
	var oTopForm = this.gfn_getWorkForm();
	if (NX.isSystemId(NX.SYS_ANGS) && oTopForm && oTopForm.gfn_isFormType(NX.FORM_WORK)) 
	{
		oTopForm.applyBtnAuth(sAuthLst);
	}
}

/**
 * 버튼으로 구성된 Division영역의 버튼을 taborder 순으로 정렬처리(visible버튼대상)
 * @param  {Object} oDiv
 * @return n/a
 * @example this.gfn_arrangeBtn(this.div_search);
 * @memberof global
 */
pForm.gfn_arrangeBtn = function(oDiv)
{
//	oDiv.set_visible(false);
	var nLeft, nDivWidth, nGap = 2;
	var oComps = oDiv.components, aComps = [];
	for (var i=0, nCnt=oComps.length; i<nCnt; aComps.push(oComps[i]), i++);
	aComps = aComps.sort(function(a, b){
		if (parseInt(a.taborder) > parseInt(b.taborder)) return 1;
		else if (parseInt(a.taborder) < parseInt(b.taborder)) return -1;
		return 0;
	});
	nLeft = nDivWidth = oDiv.getOffsetWidth();
	for (var i=aComps.length-1; i>=0; i--)
	{
		oComp = aComps[i];
		if (oComp && oComp.visible)
		{
			nLeft -= oComp.getOffsetWidth();
			Util.isNull(oComp.left) ? oComp.set_right(nDivWidth - (nLeft + oComp.getOffsetWidth())) : oComp.setOffsetLeft(nLeft);
			nLeft -= nGap;
		}
	}
//	oDiv.set_visible(true);
}

/**
 * 조회건수를 설정하는 함수(for Static컴포넌트)
 * @param  {Object} oStatic	조회건수를 표기할 Static컴포넌트
 * @param  {Object} nCnt	건수
 * @return N/A
 * @example this.gfn_setResultCnt(this.sta_girdReuslt,50);
 * @memberof global
 */
pForm.gfn_setResultCnt = function(oStatic, nCnt)
{
	NX.Service._setResultCnt(oStatic, nCnt);
}


/**
 * 화면을 닫는 함수(모델리스 팝업용)
 * @return N/A
 * @example this.gfn_close();
 * @memberof global
 */
pForm.gfn_close = function()
{
	try
	{
		var oForm = this.gfn_getWorkForm();
		if (oForm.gfn_isFormType(NX.FORM_POPUP))
		{
			window.open("", "_self", "");
			window.close();
		}
		else
		{
			oForm.fn_close();
		}
	}
	catch(e)
	{
		Util.trace("lib_com.xjs :: gfn_close() Exception => " + e.message);
	}
}

/**
 * 공통버튼의 클릭이벤트 처리(화면의 특정함수 호출 : btnID + "_onclick")
 * @private
 * @memberof global
 */
pForm._gfn_dev_button_onclick = function(obj, e)
{
	var oFunc = this[obj.name + "_onclick"];
	if (oFunc) oFunc.call(this, obj, e);
}


/**
 * Tab컴포넌트의 Tabpage로드여부 (동적변경 Tab은 미지원) 
 * @param  {Object} obj		Tab컴포넌트
 * @param  {Number} nIdx	(선택)로드여부확인할 인덱스(default : 현재index)
 * @return {Boolean} 로드여부
 * @example this.gfn_isLoadTabpage(tabList, 0)
 * @memberof global
 */
pForm.gfn_isLoadTabpage = function(obj, nIdx)
{
	return NX.Comps._isLoadTabpage(obj, nIdx);
}

/**
 * Form의 fvFormType확인
 * @param  {String} sType	Form타입(this.fvFormType)
 * @return {Boolean} 일치여부
 * @example this.gfn_isFormType(divSearch)
 * @memberof global
 */
pForm.gfn_isFormType = function(sType)
{
	return this.fvFormType && (this.fvFormType == sType);
}

/**
 * Form의 fvFormType을 반환
 * @return {String} fvFormType값
 * @example this.gfn_getFormType()
 * @memberof global
 */
pForm.gfn_getFormType = function()
{
	return this.fvFormType;
}

/**
 * Application LogOut후처리 작업
 * @return N/A
 * @example this.gfn_setLogOut()
 * @memberof global
 */
pForm.gfn_setLogOut = function()
{
	if (application.gvIsLoadFrame === true)
	{
		try
		{
			if (this.gfn_isFormType(NX.FORM_POP)) this.close(); // Modal팝업인경우 close처리 2016.07.01
			
			application.gvEntryChannel = ""; // 진입채널 초기화
			NX.setActiveFrame("loginform");
			NX.FRAME_LOGIN.form.setTimer(NX.Comps.TIMERID_LOGOUT, 50);
		}
		catch(e)
		{
			Util.trace("lib_com.xjs :: gfn_setLogOut() => " + e.message);
		}
	}
}

/**
 * Dataset Row상태컬럼을 관리하는 공통이벤트 등록함수
 * @param  {Object} aDsLst	Dataset배열
 * @return n/a
 * @example this.gfn_updateControl([this.dsList1, this.dsList2]);
 * @memberof global
 */
pForm.gfn_updateControl = function(a)
{
	DatasetEx.updateControl(a);
}

/**
 * 대상Dataset의 상태컬럼(_rowtype) 초기화처리
 * @param  {Object} oDs	대상Dataset객체
 * @return N/A
 * @example this.gfn_applyChange(this.dsList1)
 * @memberof global
 */
pForm.gfn_applyChange = function(oDs)
{
	NX.Service._applyChange(oDs);
}


/**
 * 페이징처리시 정보반환 함수(전체조회건수.. 등) <- 서비스호출과 동일한 컨테이너에서 호출해야 정상적인 값을 반환
 * @param  {String} sCtrl	컨트롤러
 * @param  {String} sColId	헤더Dataset 조회컬럼(조회건수 : totalCnt)
 * @return {String} 조회컬럼의 값
 * @example this.gfn_getHeader("", "totalCnt")
 * @memberof global
 */
pForm.gfn_getHeader = function(sCtrl, sColId)
{
	var sRtn = "", oDs = NX.Service._getCmmHeader(sCtrl, this);
	if (oDs && sColId) sRtn = Util.trim(oDs.getColumn(0, sColId));
	return sRtn;
}

/**
 * 대상MaskEditor에 mask문자를 설정
 * @param  {MaskEdit} obj	대상MaskEdit
 * @param  {String} sType	적용형태(telno, celno)
 * @example this.gfn_setMaskStr(this.mdt_telNo, "telno")
 * @memberof global
 */
pForm.gfn_setMaskStr = function(obj, sType)
{
	switch (Util.trim(sType).toLowerCase())
	{
		case "telno" : 
		case "celno" : 
			obj.set_type("string");
			obj.set_mask(Util.getMaskStr(obj.value, sType));
			break;
	}
}


/*=================================================================================================
 * ↓Mandatory Event Function
 *===============================================================================================*/
/**
 * 공통onkeyup이벤트 처리(디버그팝업 호출)
 * @return N/A
 * @example this.gfn_form_onkeyup(obj, e)
 * @memberof global
 */
pForm.gfn_form_onkeyup = function(obj, e)
{    
    if (e.ctrlKey && e.shiftKey && e.keycode == 119)
    {
    	this.gfn_popup("com_pop_test", "com::com_pop_test.xfdl", "", {width:1600, height:800, modeless:true});
    }
    else
    {
		switch (this.gfn_getFormType())
		{
			case NX.FORM_POP : // Esc
				if (e.keycode == 27)
				{
					this.close();
				}
				
			case NX.FORM_MAIN : 
				if (e.ctrlKey && e.shiftKey && e.keycode == 90) // Ctrl + Shift + Z
				{
					this.gfn_popup("com_form_info", "com::com_form_info.xfdl", "", {width:1024, height:768, modeless:true});
				}
				break;
		}
    }
}

/**
 * conatinser에 생성된 팝업Div 설정(공통 onsize이벤트에서 사용)
 * @private
 * @return N/A
 * @example this._gfn_setPopupDiv(pDivMenu)
 * @memberof global
 */
pForm._gfn_setPopupDiv = function(obj)
{
	if (this.__popupdiv) this.__popupdiv[this.__popupdiv.length] = obj;
}

/**
 * 공통onsize이벤트 처리(Form onsize 공통 Evnet <- calendar popupdiv..etc)
 * @private
 * @return N/A
 * @example this._gfn_form_onsize(obj, e)
 * @memberof global
 */
pForm._gfn_form_onsize = function(obj, e)
{
	try
	{
		var oPdiv, aPdivLst = obj.__popupdiv;
		for (var i=0, nLen=aPdivLst.length; i<nLen; i++)
		{
			oPdiv = aPdivLst[i];
			if (oPdiv && oPdiv.isPopup()) oPdiv.closePopup();
		}
	}
	catch(e)
	{
		Util.trace("lib_com.xjs :: _gfn_form_onsize " + e.message);
	}
}

/**
 * 컴포넌트에 대한 validity를 체크
 * @param  {Object} obj		container comp(Div), components array
 * @param  {Object} oCfg	container(form), all:그리드일경우 전체행 처리여부
 * @return {Object} 인자값
 * @example this.gfn_validate(this.divSearch)
 * @memberof global
 */
pForm.gfn_validate = function(obj, oCfg)
{
	if (oCfg)
	{
		var oContainer = oCfg.container;
		if (!oCfg.container) oCfg["container"] = this;
	}
	
	var oValidity = new NX.Validity.constructor(oCfg || {container:this});
	return oValidity.validate(obj, oCfg);
}

/**
 * 유효성체크식 설정함수(속성으로 직접설정해도 무방)
 * @param {Array} aItems 	설정객체(comp:대상컴포넌트, expr:체크식)
 * @example this.gfn_setValidExpr([{comp:this.divSearch.edtInput, expr:"체크식"}, {comp:this.divSearch.edtInput2, expr:"체크식2"}])
 * @memberof global
 */
pForm.gfn_setValidExpr = function(aItems)
{
	NX.Validity._addValidationExpr(aItems);
}

/**
 * 화면 Open시 인자값을 획득하는 함수
 * @param  {String} sProp	조회할Key값(팝업화면:popup)
 * @return {Object} Key에 해당하는 Value값
 * @example this.gfn_getParams("param")
 * @memberof global
 */
pForm.gfn_getParams = function(sProp)
{
	var oRtn = "", oFrame = this.gfn_getFrame("work");
	
	if (!sProp) sProp = this.gfn_getFormType() == NX.FORM_POP ? "popup" : "param";

	switch (String(sProp).toLowerCase())
	{
		case "parent" 	: 
			if (NX.isFrame())
			{
				oRtn = oFrame.__forminfo.parentmenuid;
			}
			else
			{
				Util.trace("lib_com.xjs :: gfn_getParams() => MDI환경에서 부모화면 참조가능" + sProp);
			}
			break;
		case "param" 	: oRtn = oFrame.__arguments; 	break;
		case "popup"	: oRtn = oFrame.__params; 		break;
		case "auth"		: oRtn = oFrame.__auth; 		break;
	}
	return oRtn;
}

/**
 * 화면 Open시 인자값을 설정하는 함수(초기화용-개발자사용금지) for SDI
 * @private
 * @param  {String} sProp	설정할Key값
 * @return N/A
 * @example this._gfn_setParams("param")
 * @memberof global
 */
pForm._gfn_setParams = function(sProp)
{
	var oFrame = this.gfn_getFrame("work");
	switch (String(sProp).toLowerCase())
	{
		case "parentmenuid" : oFrame.forminfo.parentmenuid 	= ""; 	break;
		case "param" 		: oFrame.__arguments = ""; 				break;
		default 			: oFrame[sProp] = ""; 					break;
	}
}

/**
 * 화면 Open시 인자값을 초기화하는 함수
 * @return N/A
 * @example this.gfn_clearParams()
 * @memberof global
 */
pForm.gfn_clearParams = function()
{
// 	if (!Array.isArray(aProp)) aProp = [aProp];
// 	for (var i=0, nLen=aProp.length; i<nLen; i++)
// 	{
// 		this._gfn_setParams(aProp[i]);
// 	}
    this._gfn_setParams("param");
}

/**
 * Div에 배치된 컴포넌트의 value속성이 데이터셋을 바인딩한 경우에 value 값을 데이터셋에 반영시키는 메소드
 * Key이벤트를 사용해서 서비스 호출시 변경된정보 반영하기 위함(외 단일 컴포넌트는 직접 updateToData()을 직접호출)
 * @param {Object} oDiv 	대상container(Div)
 * @return {String} sDragID와 sValue를 구분자로 조합
 * @see this.gfn_updateToDataset(divSearch);
 * @memberof global
*/
pForm.gfn_updateToDataset = function(o)
{
	// Div에 배치된 컴포넌트 Retrieve 처리 검토.
	var oComp = o.getFocus();
	if (oComp && oComp.updateToDataset) oComp.updateToDataset();
}

/**
 * WorkForm을 반환하는 함수
 * @return {Object} 업무영역Form
 * @see this.gfn_getWorkForm();
 * @memberof global
 */
pForm.gfn_getWorkForm = function()
{
	return NX.ismdi ? this.getOwnerFrame().form : (NX.getForm("work") || this.getOwnerFrame().form);
}

/**
 * 현재Form의 ChildFrame을 반환하는 함수
 * @param {String} sType 대상 프레임
 * @return {Object} 프레임을 구성하는 Form
 * @see this.gfn_getFrame("WORK");
 * @memberof global
 */
pForm.gfn_getFrame = function(sType)
{
	switch (sType.toLowerCase())
	{
		case "work" : 
			return NX.ismdi ? this.getOwnerFrame() : this.gfn_getWorkForm(sType);
		case "main" : 
			return NX.getForm("main") || this.getOwnerFrame().form;
	}
}

/**
 * 거래일자 반환(동기)
 * @param {String} sFormat : 얻으려는 시간 Format
 * @param {boolen} bTran : 재조회여부(Default : false)
 * @return {String} 시스템 일시
 * @see this.gfn_getTrDate("yyyymmdd");
 * @memberof global
*/
pForm.gfn_getTrDate = function(sFormat, bTran)
{
	if (!sFormat) sFormat = "yyyymmdd";
 	if (NX.isFrame() && bTran)
 	{
		var aRtn = this.gfn_trans("COC0040RA", "", "gdsTrDate=dsTrDt", "", "", "", {async:false});
 		if (aRtn[0] < 0)
 		{
			Util.trace("lib::lib_com.xjs :: gfn_getTrDate() >> Service Failed : " + aRtn[1]);
			gdsTrDate.clearData();
			gdsTrDate.setColumn(gdsTrDate.addRow(), "hdyDt", Util.today());
		}
	}
	
	var sDateTime = application.gdsTrDate.rowcount > 0 ? application.gdsTrDate.getColumn(0, "hdyDt") : Util.today();
	var sRtnDate  = "";
	
	sFormat	= Util.trim(sFormat).toLowerCase();
	switch (sFormat)
	{
		case "yyyy":
		case "yyyymm":
			sRtnDate = sDateTime.substr(0, sFormat.length);
			break;
		case "yyyymmdd":
		default:
			sRtnDate = sDateTime.substr(0, 8);
			break;
	}
	return sRtnDate;
}


/**
 * (월)달력컴포넌트 팝업callback함수
 * @private
 * @memberof global
 */
pForm._gfn_calendar_dropbutton_callback = function(sPdivNm, sYearMonth)
{
	var oPdiv = this.components[sPdivNm];
	var oCal = this.components[sPdivNm]._link_calendar;
	if (oCal)
	{
		if (!Util.isNull(sYearMonth) && oCal.value != sYearMonth)
		{
			var _pretext	= oCal.text;
			var _prevalue	= oCal.value;

			oCal.set_value(sYearMonth);
			
			var sEvtId	= "onchanged";
			var oFunc 	= oCal.getEventHandler(sEvtId, 0);
			if (oFunc)
			{
				var oEvt = {eventid:sEvtId, fromobject:oCal, preindex:_pretext, pretext:_pretext, prevalue:_prevalue, posttext:oCal.text, postvalue:oCal.value};
				oFunc.call(NX.Analyzer.form(this.parent), oCal, oEvt);
			}
			
			if (oCal.autoskip) this.getNextComponent(oCal).setFocus();
		}
		
		if(!Util.isNull(oCal.__callFunc))
		{
			if(oPdiv._KEY_ENTER) 
			{
				try{				
				    this[oCal.__callFunc]();
				}catch(ex){}
			}
		}
	}
}

/**
 * Grid expandbutton(월달력) keyup이벤트 처리
 * @private
 * @memberof global
 */
pForm.gfn_grid_calendar_onexpandup = function(obj, e)
{
	var oGrid	= obj;
	var oGridDs	= this.objects[oGrid.binddataset];
	var sDivID 	= "_pdiv_popupcal_" + oGrid.name;
	var oPopDiv = this.components[sDivID];
	var nWidth	= 197;
	var nHeight	= 192;
	
	if (oPopDiv)
	{}
	else
	{
		oPopDiv = new PopupDiv(sDivID, "absolute", 0, 0, nWidth, nHeight, null, null);
		oPopDiv.set_async(false);
		oPopDiv.set_tabstop(false);
		oPopDiv.set_scrollbars("none");
		oPopDiv.set_url("com::com_calendar_month.xfdl");
		this.addChild(sDivID, oPopDiv);
		oPopDiv.show();
		
		this._gfn_setPopupDiv(oPopDiv);
	}

	if (oPopDiv.isPopup())
	{
		oPopDiv.closePopup();
		return;
	}
	
	oPopDiv.fnSetMonthCalendar(Util.trim(obj.getCellValue(e.row, e.cell)).substr(0, 6));

	var oRect = obj.getCellRect(e.row, e.cell);
	
	oPopDiv._link_calendar = {grid:obj, event:e};
	oPopDiv.trackPopupByComponent(obj, oRect.left-2, oRect.bottom+2, nWidth, nHeight, "_gfn_grid_controlcalendar_dropbutton_callback");
}

/**
 * Grid expandbutton(월달력) keyup이벤트시 호출된 팝업의 callback함수
 * @private
 * @memberof global
 */
pForm._gfn_grid_controlcalendar_dropbutton_callback = function(sPdivNm, sYearMonth)
{
 	var oInfo 	= this.components[sPdivNm]._link_calendar;
	var oEvent	= oInfo.event;
	var oGrid	= oInfo.grid;
	if (oGrid)
	{
		var oGridDs	= this.objects[oGrid.binddataset];
		var sDisplayType = oGrid.getCellProperty("body", oEvent.cell, "displaytype");
		if (!Util.isNull(sYearMonth) && (oGrid.getCellValue(oEvent.row, oEvent.cell) != sYearMonth))
		{
			var sColID = GridEx.getBindColId(oGrid, oEvent.cell);
			if (sColID)
			{
				oGridDs.setColumn(oEvent.row, sColID, sYearMonth + (sDisplayType == "date" ? "01" : ""));
			}
			
			// autoskip이 설정되어 있는 경우 다음 cell로 이동되도록 처리
			var bAutoSkip = String(oGrid.getCellProperty("body", oEvent.cell, "editautoskip"));
			if (bAutoSkip == "true") oGrid.moveToNextCell();
		}
	}
}

/*=================================================================================================
 *	nexacroplatform 기본 Grid 의 재정의 된 Event Function (End)
 *=================================================================================================*/



/*=================================================================================================
 *	화면처리 관련 스크립트 Function (Begin) 
 *===============================================================================================*/
/**
 * 공통 Modal Popup를 실행하는 함수
 * @param {String} sId 		Popup Form의 ID
 * @param {String} sURL 	Form URL
 * @param {String} oArgLst 	Form으로 전달될 Argument
 * @param {String} oCfg		팝업속성객체 (선택사항)
 * <pre>
 * * callback : 콜백함수명설정(문자열)
 * * modal : 모달여부(true/fals)
 * * style : 팝업유형
 * * left : 좌측좌표
 * * top : 상단좌표
 * * width : 너비
 * * height : 높이
 * </pre>
 * @return {Boolean} 호출여부
 * @example gfn_popup(sId, sURL, oArgLst, {style:"showtitlebar=true",left:200,top:200,width:600,bottom:400})
 * @memberof global
 */
pForm.gfn_popup = function(sId, sURL, oArgLst, oCfg)
{
	// Runtime[Windows] 계의의 경우 system.showModalWindow, system.showModalSync 지원
	if (!sId || !sURL)
	{
		return this.alert("팝업화면 공통함수 this.gfn_popup() :: 팝업화면의 ID[" + sId + "] URL[" + sURL + "] mandatory parameter.");
	}
	
	if (!oCfg) oCfg = {};

	var bModeless	= oCfg.modeless || false;
	var oOwnerFrame = this.gfn_getFrame("work");
	var bCmmPopup	= sURL.indexOf("com::") == 0;
	var sScrnAuth 	= bCmmPopup ? "" : this.gfn_getScrnAuth(); // 메시지팝업의 경우 권한처리 제외(oOwnerFrame.__auth || )
	
	var sParentId	= this.gfn_getFormInfo("menuid");
	var sIdvInfoIncsYn	= this.gfn_getFormInfo("idvinfoincsyn");

	// 타업무 팝업화면 사용불가 <- 서비스그룹체크 2017.12.21 테스트
// 	var sSvcGrp = this.gfn_getFormInfo("menuurl").split(NX.FORM_URL_DELIM)[0];
// 	if (["com","sample"].indexOf(sSvcGrp) < 0)
// 	{
// 		if (sSvcGrp != sURL.split(NX.FORM_URL_DELIM)[0])
// 		{
// 			return this.alert("팝업화면의 업무그룹을 확인하세요.");
// 		}
// 	}

	if (bModeless === true)
	{		
		if(Util.isNull(oCfg.width))
		{
			oCfg.width = 500;
		}
		
		if(Util.isNull(oCfg.height))
		{
			oCfg.height = 350;
		}
		
		// modeless의 경우 width, height 필요
		var nGapWidth = window.outerWidth - oCfg.width;
		if (nGapWidth >= 0) oCfg.left = window.screenX + (nGapWidth / 2);
		var nGapHeight = window.outerHeight - oCfg.height;
		if (nGapHeight >= 0) oCfg.top = window.screenY + (nGapHeight / 2);		
		//var bAutoSize 	= (Util.isNull(oCfg.autosize)) ?  true : oCfg.autosize;
		
		var bPopupStyle	= oCfg.style || "";
		var sAutoSize = (Util.isNull(oCfg.autosize)) ? "true" : (oCfg.autosize) ? "true " : "false";
		
		bPopupStyle += (bPopupStyle ? " " : "") + "autosize="+sAutoSize;
		
		/*
		if (bAutoSize)
		{
			// adjust screen-position when modeless-popup has width and height
			bPopupStyle += (bPopupStyle ? " " : "") + "openalign='left top'";
		}		
		*/
		return application.open(sId, sURL, oOwnerFrame, {__opener_menuid:sParentId,__params:oArgLst,__auth:sScrnAuth,__idvinfoincsyn:sIdvInfoIncsYn}, bPopupStyle, oCfg.left, oCfg.top, oCfg.width, oCfg.height, this);
	}
	else
	{
		var oFrame 	= NX.Comps._getChildFrame(sId, oOwnerFrame, sURL, {left:oCfg.left,top:oCfg.top,width:oCfg.width,height:oCfg.height,style:oCfg.style});
		var bSucc 	= oFrame.showModal(sId, oOwnerFrame, {__opener_menuid:sParentId,__params:oArgLst,__auth:sScrnAuth,__idvinfoincsyn:sIdvInfoIncsYn}, this, oCfg.callback);
		var sStyle	= Util.trim(oCfg.style);
		if (bSucc && sStyle)
		{
			var aPropList, sProp, sValue, bFlag, aStyle = sStyle.split(" ");
			for (var i=0, nLen=aStyle.length; i<nLen; i++)
			{
				aPropList	= aStyle[i].split("=");
				sProp 		= Util.trim(aPropList[0]);
				sValue		= Util.trim(aPropList[1]);
				bFlag		= (sValue.toLowerCase() == "true");
				switch (sProp.toLowerCase())
				{
					case "closebutton" 	:	oFrame.titlebar.closebutton.set_enable(bFlag);	break;
					case "minbutton" 	:	oFrame.titlebar.minbutton.set_enable(bFlag);	break;
					case "maxbutton" 	:	oFrame.titlebar.maxbutton.set_enable(bFlag);	break;
					case "titlebar" 	:	oFrame.set_showtitlebar(bFlag);					break;
					case "resizable" 	:	oFrame.set_resizable(bFlag);					break;
				}
			}
		}
		return bSucc;
	}
}


/**
 * 화면연계 공통함수
 * @param {String} 	sMenuId	메뉴ID(필수)
 * @param {Object} 	oArgLst	화면으로 넘기려는 Argument, Dataset지정시 gfn_getParamDs()함수사용해야함
 * @param {Object}  oCfg	설정객체
 * <pre>
 * * type : new(새창호출)
 * * focus(Focus처리)
 * </pre>
 * @return {Boolean} true/false
 * @example this.gfn_openForm(sMenuId, oArgLst)
 * @memberof global
 */
pForm.gfn_openForm = function(sMenuId, oArgLst, oCfg)
{
	if (!NX.isFrame()) return application.alert("단위화면[Quick View]에서는 화면연계 처리불가");
	
	sMenuId = Util.trim(sMenuId);
	
	if (Util.isNull(sMenuId)) return;
	if (!oCfg) oCfg = {};
	

	var oMenuDs		= application.gdsMenu;
	var sOpenType	= oCfg.type || "postload";
	var sFrameID	= Util.trim(sMenuId) + "_" + Util.toDateTime("ms"); // get unique childframe id
	var sFindExpr 	= "mnuId=='" + sMenuId + "'";
	var nFindRow 	= oMenuDs.findRowExpr(sFindExpr);
	if (nFindRow < 0)
	{
		//return this.gfn_msgBox("M", "등록되어 있지 않은 화면ID 입니다. [" + sMenuId + "]", {restrict:true});
		return;
		
	}
	
	var sDvsn = oMenuDs.getColumn(nFindRow,"scrinDvsn");
	
	if(!Util.isNull(sDvsn) && sDvsn == "M")
	{
		var sPgmUrl		 = Util.trim(oMenuDs.getColumn(nFindRow, "scrinUrl"));
		this.gfn_popup(	sMenuId, 
				sPgmUrl, 
				oArgLst,
				{
			       modeless:true
			      ,style:"resizable=true"
			      ,width:1856
			      ,height:695
			    }); // 주의		 
		return;
	}
	
	if (sOpenType != "new")
	{
		var nRow = application.gdsOpenList.findRow("menuId", sMenuId);
		if (nRow >= 0)
		{
			sFrameID 	= Util.trim(application.gdsOpenList.getColumn(nRow, "frameId"));
			oChildFrame	= NX.FRAME_WORK.frames[sFrameID];
			if (oChildFrame)
			{
				oChildFrame.__arguments = oArgLst;
				switch (sOpenType)
				{
					case "postload" : 
						var oWorkForm = oChildFrame.form.divWork;
						if (oWorkForm && oWorkForm.fn_postload) oWorkForm.fn_postload(sOpenType);
						oWorkForm.setFocus();
					default : // for [type : focus]
						oChildFrame.setFocus();
//						oChildFrame.form.setFocus();
						break;
				}
				return oChildFrame;
			}
			else
			{
				Util.trace("lib_com.xjs :: gfn_openForm() => not found childframe id : " + sFrameID);
			}
		}
	}
	
	if (application.gvMaxWinCnt <= application.gdsOpenList.rowcount)
	{
		//var sUiMsg = NX._getUiMsg("UI029",[application.gvMaxWinCnt]);
		var sUiMsg = Util.getComMsg("E.ZZ.ZZ.0048",application.gvMaxWinCnt);
		this.gfn_msgBox("A", sUiMsg);
		
		return
	}
	
	var sParentFrame, sParentMenu, sOpenType = "M";		
	var sPgmUrl		 = Util.trim(oMenuDs.getColumn(nFindRow, "scrinUrl"));
	var sPgmName	 = Util.trim(oMenuDs.getColumn(nFindRow, "mnuNm"));
	var sScrinAuthId = Util.trim(oMenuDs.getColumn(nFindRow, "scrinAthId"));
	var sIdvInfoIncsYn = Util.trim(oMenuDs.getColumn(nFindRow, "idvInfoIncsYn"));
	
	if (this.gfn_isFormType(NX.FORM_FRAME))
 	{
		sParentFrame	= "MENU";
		sParentMenu		= "MENU";
 	}
 	else
 	{
		var oWorkMain	= this.gfn_getWorkForm();
		if (oWorkMain)
		{
			sParentFrame	= oWorkMain.getFormInfo("frameid"); // 호출하는 화면ID
			sParentMenu		= oWorkMain.getFormInfo("menuid");
		}
 	}

	var oFormInfo = {};
		oFormInfo.frameid		= sFrameID;					// ChildFrame ID
		oFormInfo.menuid		= sMenuId;					// Program ID
		oFormInfo.menuurl		= sPgmUrl;					// Program URN
		oFormInfo.menunm		= sPgmName;					// Menu Title
		oFormInfo.formid		= Util._getFormId(sPgmUrl);	// FormID by URL
		oFormInfo.opentype		= sOpenType;	// Open Type(?)
		oFormInfo.parentframeid	= sParentFrame;	// 
		oFormInfo.parentmenuid	= sParentMenu;	// 
		oFormInfo.scrinauthid   = sScrinAuthId;
		oFormInfo.idvinfoincsyn =  sIdvInfoIncsYn;

	if (NX.ismdi)
	{
		var nLeft = 0, nTop = 0, sWorkMainUrl = "frame::frm_workMain.xfdl";
		
		oChildFrame = new ChildFrame();
		oChildFrame.init(sFrameID, "absolute", nLeft, nTop, nLeft + 800, nTop + 600, null, null, sWorkMainUrl);
		oChildFrame.__forminfo	= oFormInfo;
		oChildFrame.__arguments = oArgLst;
		
		NX.FRAME_WORK.addChild(sFrameID, oChildFrame);
		
		oChildFrame.addEventHandler("onsyscommand", this.__gfn_childframe_onsyscommand);
		oChildFrame.set_showcascadetitletext(false);
		oChildFrame.set_resizable(true);
		oChildFrame.set_titletext("[" + sMenuId + "] " + sPgmName);
		oChildFrame.style.set_border("0 none #000000");
		oChildFrame.set_openstatus("maximize");
		oChildFrame.set_dragmovetype("none");
//		oChildFrame.set_showtitlebar(false);
		oChildFrame.show();
			
		return oChildFrame;
	}
	else
	{
		var oWorkMain = this.gfn_getFrame("work");
		if (oWorkMain.fvFormType != NX.FORM_WORK) // sync to url changing
		{
			oWorkMain.set_url("frame::frm_workMain.xfdl");
		}

		if (oWorkMain.getFormLoad() === false)
		{
			return this.gfn_msgBox("M", "화면 로딩중에 다른화면을 호출했습니다.\n\n잠시 후 다시 시도해주세요.", {restrict:true});
		}
		return true;
	}
}

/**
 * 화면연계 공통함수
 * @param {String} 	sUrl 화면URL EX)sample::sample084.xfdl 
 * @param {Object} 	oArgLst	화면으로 넘기려는 Argument
 * @return N/A 
 * @example this.gfn_goForm("sample::sample084.xfdl", {key1:"value1"})
 * @memberof global
 */
pForm.gfn_goForm = function(sUrl,oArgLst)
{

    var oWorkMain	= this.gfn_getWorkForm("work");
    var oFrame = this.gfn_getFrame("work");
    oFrame.__arguments = oArgLst;
    
    oWorkMain.divWork.set_url(sUrl);
}

pForm.__gfn_childframe_onsyscommand = function(obj,e)
{
	if (e.state == "maximize")
	{
		if (NX.FRAME_WORK.__openstate == "restore")
		{
			NX.FRAME_WORK.__openstate = "";
			
			// frameset의 다른 화면들도 체크하여 titlebar확인
			var oFrame, aFrames = NX.FRAME_WORK.frames;
			for (var i=0, nCnt=aFrames.length; i<nCnt; i++)
			{
				
				oFrame = aFrames[i];
				if (oFrame && oFrame.showtitlebar === true)
				{
					oFrame.set_showtitlebar(false);
					oFrame.style.set_border("0 none #000000");
				}
			}
		}
		else
		{
			obj.set_showtitlebar(false);
			obj.style.set_border("0 none #000000");
		}
	}
	else if (e.state == "restore")
	{
		NX.FRAME_WORK.__openstate = e.state;
	}
}

/**
 * 공통 Message처리하는 함수(필수입력항목 : sType, sText)
 * @param {String} sType 	"A":alert, "C":confirm, "M":메시지박스 직접호출
 * @param {String} sText	메시지코드
 * @param {Object} oMsgOpt 메시지옵션
 * <pre>
 * * params - 가변메시지와 대응하여 replace할 배열
 * * title -타이틀
 * * icon - 아이콘("error", "question", "warning", "info")
 * * btnstyle - 버튼스타일[sType이 "M"인경우만 해당 : default("YN")]
 *                            "ARI" : ABORT/RETRY/IGNORE
 *                            "O" : OK
 *                            "OC" : OK/CANCEL
 *                            "RC" : RETRY/CANCEL
 *                            "YN" : YES/NO
 *                            "YNC" : YES/NO/CANCEL
 * * btnindex - 기본선택버튼[sType이 "M"인경우만 해당: default(0)]
 * * btntext(Array) - 버튼스타일에 따른 버튼명 재정의 할 경우(버튼스타일 길이와 동일한 배열로 구성)
 * * callback - 반환값사용을 위한 콜백함수명 지정
 * * btnvalue - 반환값 대체하여 사용(버튼index 미사용) - alert인경우만 해당
 * * popupid - 팝업화면ID를 지정(Callback함수에서 사용됨)
 * </pre>
 * @return {Number}
 * <pre>
 * sType "A"인경우 : 없음
 * sType "C"인경우 : true(1), false(0)
 * sType "M"인경우 : 버튼Index(순서에 따라 0,1,2)
 * </pre>
 * @example alert 	: gfn_msgBox("A", "테스트입니다");
 *          confirm : gfn_msgBox("C", "저장하시겠습니까?");
 * @memberof global
 */
pForm.gfn_msgBox = function(sType, sText, oMsgOpt)
{
	if (Util.isNull(sType)) return this.alert("message type is mandatory parameter.", "MessageBox");
	if (Util.isNull(sText)) return this.alert("message is mandatory parameter.", "MessageBox");
	
	if (Util.isNull(oMsgOpt)) oMsgOpt = {};

	var sIcon 	= "INFO";
	var sTitle 	= oMsgOpt.title || "Information";
	var aParams = oMsgOpt.params || "";
	
	var oRegExp = new RegExp("^[EQIW]\.");
	if (oRegExp.test(sText))
	{
		var sChar = sText.charAt(0);
		switch (sChar)
		{
			case "E" :	sIcon = "ERROR";	break;
			case "Q" :	sIcon = "QUESTION";	break;
			case "I" :	sIcon = "INFO";		break;
			case "W" :	sIcon = "WARNING";	break;
		}
	}
	
	if (oMsgOpt.icon) sIcon = oMsgOpt.icon;
	
	switch (Util.trim(sType).toUpperCase())
	{
		case "A" :	// alert
			oMsgOpt.btnstyle 	= "O";
 			oMsgOpt.message 	= Util.getComMsg(sText, aParams, oMsgOpt);
			oMsgOpt.title		= sTitle;
			oMsgOpt.icon		= sIcon;
 			return this.gfn_popup(oMsgOpt.popupid || "_alert", "com::com_messagebox.xfdl", {pvMsgBoxStyle:oMsgOpt}, {callback:oMsgOpt.callback || "fn_msgBoxCallback"});
			break;

		case "C" :	// confirm
			oMsgOpt.btnstyle 	= "YN";
 			oMsgOpt.message 	= Util.getComMsg(sText, aParams, oMsgOpt);
			oMsgOpt.title		= sTitle;
			oMsgOpt.icon		= sIcon;
 			return this.gfn_popup(oMsgOpt.popupid || "_confirm", "com::com_messagebox.xfdl", {pvMsgBoxStyle:oMsgOpt}, {callback:oMsgOpt.callback || "fn_msgBoxCallback"});
			break;

		case "M" :	// manual message box
 			oMsgOpt.message = Util.getComMsg(sText, aParams, oMsgOpt);
			oMsgOpt.title	= sTitle;
			oMsgOpt.icon	= sIcon;
 			return this.gfn_popup(oMsgOpt.popupid || "_manual_msgbox_" + Math.random(), "com::com_messagebox.xfdl", {pvMsgBoxStyle:oMsgOpt}, {callback:oMsgOpt.callback || "fn_msgBoxCallback"});
			break;
	}
}

/**
 * 그리드 복사&붙여넣기처리 함수(for Excel)
 * Document.execCommand() Html5의 ED(Editor's Draft), 브라우저 버전에 따라 상이하게 지원함
 * @param  {Grid} obj	그리드객체
 * @param  {KeyEventInfo} e	이벤트객체
 * @return  N/A
 * @example  this.gfn_copy2paste(obj, e);
 * @memberof global
 */
pForm.gfn_copy2paste = function(obj, e, oCfg)
{
	if (e.ctrlKey)
	{
		switch (e.keycode)
		{
			case 67 : // Ctrl+C
				if (!NX.isruntime && oCfg.excel === true)
				{
					NX.Comps._copyForExcel(this, obj);
				}
				else
				{
					GridEx._copy2paste(obj, "copy");
				}
				break;
				
			case 86 : // Ctrl+V
				if (!NX.isruntime && oCfg.excel === true)
				{
					NX.Comps._pasteForExcel(this, obj);
				}
				else
				{
					GridEx._copy2paste(obj, "paste", oCfg);
				}
				break;
		}
	}
}

/*=================================================================================================
 * ↓Site dependant Function
 *===============================================================================================*/
/**
 * Status 에 메시지를 출력
 * @param  {String} sMsg	상태창에 출력할 문자열
 * @return  N/A
 * @example  this.gfn_setStatusMsg("조회가 완료되었습니다.");
 * @memberof global
 */
pForm.gfn_setStatusMsg = function(sMsg)
{
	// 팝업화면의 경우 : 하단naming rule과 일치하는 컴포넌트에 메시지 설정?
	if (NX.isFrame()) NX.getForm("bottom").setMsg(sMsg);
}

/**
 * 현재 Form의 정보반환
 * @param {String} sType 정보를 얻으려는 구분
 * @param {String} oCfg url:컴테이터컴포넌트의 url속성에 link된 formid리턴용
 * @return {String} Form Info
 * @example this.gfn_getFormInfo("menuid")
 * @memberof global
 */
pForm.gfn_getFormInfo = function(sType, oCfg)
{
	oCfg = oCfg || {};
	
	var sRet = "", sType = String(sType).toLowerCase();
	switch (sType)
	{
		case "titletext" 	: sRet = this.getOwnerFrame().form.titletext; 	break;
		case "childid" 		: sRet = this.getOwnerFrame().name; 			break;
		case "formurl" :
			if (NX.isFrame())
			{
				var sFormType = this.gfn_getFormType();
				sRet = NX.ismdi ? this.getOwnerFrame().formurl : this.url;
			}
			else
			{
				 sRet = this.getOwnerFrame().formurl;
			}
			break;
			
		case "menuid" : 
			var oFrame = this.gfn_getFrame("work"), sFormType = this.gfn_getFormType();
			if (NX.isFrame())
			{
				bUrl = oCfg.url === true ? oCfg.url : false;
				if (this.opener == null) // for MDI 
				{
					if (sFormType == NX.FORM_DIV || sFormType == NX.FORM_TAB)
					{
						var sTopFormType = oFrame.form.fvFormType;
						if (sTopFormType == NX.FORM_POP) // for popup (include Tab, Div..) <- __opener_menuid
						{
							return oFrame.__opener_menuid || oFrame.form.name;
						}
						else
						{
							var sUrl = Util.trim(this.url);
							if (bUrl && sUrl)
								return sUrl.substring(sUrl.indexOf(NX.FORM_URL_DELIM) + NX.FORM_URL_DELIM.length, sUrl.lastIndexOf(NX.FORM_EXTENSION));
							else
								return this.gfn_getWorkForm().getFormInfo("menuid");
						}
					}
					else if (sFormType == NX.FORM_FRAME) // for FRAME
					{
						return "[FRAME]" + this.name;
					}
					else
					{
						return this.fvFormId || this.gfn_getWorkForm().getFormInfo("menuid");
					}
				}
				else
				{
					var sFrameId = oFrame.name;
					
					var sFrameId = application.gdsMenu.lookup("mnuId",sFrameId,"mnuId");
					
					if(Util.isNull(sFrameId))
					{
					    return oFrame.__opener_menuid || this.name; // for popup	
					}
					else
					{
						return sFrameId;
					}					
				}
			}
			else
			{
				var bUrl = oCfg.url === false ? oCfg.url : true;
				if (sFormType == NX.FORM_DIV || sFormType == NX.FORM_TAB)
				{
					var sUrl = Util.trim(this.url);
					return bUrl && sUrl ? sUrl.substring(sUrl.indexOf(NX.FORM_URL_DELIM) + NX.FORM_URL_DELIM.length, sUrl.lastIndexOf(NX.FORM_EXTENSION)) : this.name;
				}
				else
				{
					return oFrame.__opener_menuid || this.name;
				}
			}
			break;
			
		case "idvinfoincsyn" : 
			var oFrame = this.gfn_getFrame("work"), sFormType = this.gfn_getFormType();
			if (NX.isFrame())
			{
				bUrl = oCfg.url === true ? oCfg.url : false;
				if (this.opener == null) // for MDI 
				{
					if (sFormType == NX.FORM_DIV || sFormType == NX.FORM_TAB)
					{
						var sTopFormType = oFrame.form.fvFormType;
						if (sTopFormType == NX.FORM_POP) // for popup (include Tab, Div..) <- __opener_menuid
						{
							return oFrame.__idvinfoincsyn || "N";
						}
						else
						{
							var sUrl = Util.trim(this.url);
							if (bUrl && sUrl)
								return sUrl.substring(sUrl.indexOf(NX.FORM_URL_DELIM) + NX.FORM_URL_DELIM.length, sUrl.lastIndexOf(NX.FORM_EXTENSION));
							else
								return this.gfn_getWorkForm().getFormInfo("idvinfoincsyn");
						}
					}
					else if (sFormType == NX.FORM_FRAME) // for FRAME
					{
						return "N";
					}
					else
					{
						return this.gfn_getWorkForm().getFormInfo("idvinfoincsyn");
					}
				}
				else
				{				
					var sIdvInfoIncsYn = application.gdsMenu.lookup("mnuId",sFrameId,"idvInfoIncsYn");
					
					if(Util.isNull(sIdvInfoIncsYn))
					{
					    return oFrame.__idvinfoincsyn || "N"; // for popup	
					}
					else
					{
						return sIdvInfoIncsYn;
					}					
				}
			}
			else
			{
				var bUrl = oCfg.url === false ? oCfg.url : true;
				if (sFormType == NX.FORM_DIV || sFormType == NX.FORM_TAB)
				{
					var sUrl = Util.trim(this.url);
					return bUrl && sUrl ? sUrl.substring(sUrl.indexOf(NX.FORM_URL_DELIM) + NX.FORM_URL_DELIM.length, sUrl.lastIndexOf(NX.FORM_EXTENSION)) : this.name;
				}
				else
				{
					return oFrame.__idvinfoincsyn || "N";
				}
			}
			break;
			
		case "menuurl" : // Popup화면 호출시 메인화면의 업무시스템 체크용			
			var sFormType = this.gfn_getFormType();
			if (NX.isFrame())
			{
				if (this.opener == null) // for MDI
				{
					if (sFormType == NX.FORM_DIV || sFormType == NX.FORM_TAB)
					{
						var sTopFormType = this.getOwnerFrame().form.fvFormType;
						if (sTopFormType == NX.FORM_POP) // for popup (include Tab, Div..)
						{
							return this.getOwnerFrame().formurl;
						}
						else
						{
							return this.gfn_getWorkForm().getFormInfo("menuurl");
						}
					}
					else if (sFormType == NX.FORM_FRAME) // for FRAME
					{
						return this.getOwnerFrame().formurl;
					}
					else
					{
						return this.fvFormId || this.gfn_getWorkForm().getFormInfo("menuurl");
					}
				}
				else
				{
					return this.getOwnerFrame().formurl; // for popup URL
				}
			}
			else
			{
				return this.getOwnerFrame().formurl; // for quickview
			}
			break;
			
		case "formid" 	: 
		case "frameid" 	: 
			var sFormType = this.gfn_getFormType();
			if (NX.isFrame())
			{
				if (this.opener == null) // for MDI
				{
					if (sFormType == NX.FORM_DIV || sFormType == NX.FORM_TAB)
					{
						var sTopFormType = this.getOwnerFrame().form.fvFormType;
						if (sTopFormType == NX.FORM_POP) // for popup (include Tab, Div..)
						{
							//return this.name;
							var oForm = this.getOwnerFrame().form;
							return oForm.name;
						}
						else
						{
							return this.gfn_getWorkForm().getFormInfo(sType);
						}
					}
					else if (sFormType == NX.FORM_FRAME) // for FRAME
					{
						return "[FRAME]" + this.name;
					}
					else
					{
						return this.fvFormId || this.gfn_getWorkForm().getFormInfo(sType);
					}
				}
				else
				{
					return this.name; // for popup URL
				}
			}
			else
			{
				return this.name; // for quickview
			}
			break;
	}
	
	return sRet;
}

/**
 * 화면의 권한정보를 반환
 * @return {String} 권한물자열
 * @example this.gfn_getScrnAuth()
 * @memberof global
 */
pForm.gfn_getScrnAuth = function()
{
	var sAuth = "", oForm = this.gfn_getWorkForm();
	
	if (NX.getApp().id == NX.SYS_SANGS)
	{
		// 임의서비스로 조회한 권한설정 or 화면로드시 한화면에 대한 서비스요청 하여 동일스크립트로 처리
		return "";
	}
	else
	{
		if (oForm.gfn_isFormType(NX.FORM_WORK)) // !this.gfn_isFormType(NX.FORM_POP) 제외(팝업화면도 별도권한)
		{
			sAuth = oForm.getAuth();
		}
		else
		{
			if (oForm.gfn_isFormType(NX.FORM_POP))
			{
				sAuth = oForm.gfn_getParams("auth");
			}
			else
			{
				Util.trace("[권한획득 실패] 화면설정 변수 및 공통함수 확인 : " + this.name + "/" + oForm.gfn_getFormType());
			}
		}
	}
	return sAuth;
}

/**
 * 지정한컨테이터(Division)에 체크박스를 동적으로 생성하는 함수
 * @param {Object} o 설정객체(dataset:참조dataset, target:체크박스를 배치할Division컴포넌트)
 * @return N/A
 * @see this.gfn_genGrpChkBox({dataset:this.dsCmmCd, target:this.divSearch});
 * @memberof global
*/
pForm.gfn_genGrpChkBox = function(o)
{
	NX.Comps.genGrpChkBox(o);
}

/**
 * 선택된 체크박스의 값을 반환
 * @param {Object} o 대상컴포넌트(Division)
 * @param {Object} oCfg 설정객체(text:텍스트값반환)
 * @param {String} sProp 속성
 * @return N/A
 * @see this.gfn_getGrpChkBox(this.divSearch);
 * @memberof global
*/
pForm.gfn_getGrpChkBox = function(oDiv, oCfg)
{
	return NX.Comps.getGrpChkBox(oDiv, oCfg);
}

/**
 * 대상컴포넌트의 체크박스에 값설정
 * @param {Object} oDiv 대상컴포넌트(Division)
 * @param {Array} aValue 설정하려는값(배열)
 * @return N/A
 * @see this.gfn_setGrpChkBox(this.divSrch, ["1","2"]);
 * @memberof global
*/
pForm.gfn_setGrpChkBox = function(oDiv, aValue, oCfg)
{
	NX.Comps.setGrpChkBox(oDiv, aValue, oCfg);
}

/**
 * 대상컴포넌트의 속성(readonly)을 조정
 * @param {Object} oDiv 대상컴포넌트(Division) 또는 대상컴포넌트 배열
 * @param {Boolean} v 지정하려는 속성값
 * @param {Object} oCfg 설정객체 <지원속성 prop:지정속성값(default:"readonly") >
 * @return N/A
 * @example this.gfn_setProp(this.divSrch, true);
 * @memberof global
*/
pForm.gfn_setProp = function(o, v, oCfg)
{
	NX.Comps.setProp(o, v, oCfg);
}

/*=================================================================================================
 * ↑Site dependant Function
 *===============================================================================================*/


/*=================================================================================================
 * ↓Dataset Common Function
 *===============================================================================================*/
/**
 * [화면연계함수] 전달Dataset을 생성하여 반환
 * @param  {Dataset} o Dataset배열
 * @return {Dataset} 반환dataset
 * @example this.gfn_getParamDs(oDs);
 * @memberof global
 */
pForm.gfn_getParamDs = function(o)
{
	var oDs = new Dataset();
		oDs.copyData(o);
	return oDs;
}

/**
 * [화면연계시 피호출화면에서 사용] 동적생성 Dataset Clear처리
 * @param  {Dataset} o Dataset객체
 * @return N/A
 * @example this.gfn_clearParamDs(oDs);
 * @memberof global
 */
pForm.gfn_clearParamDs = function(o)
{
	DatasetEx._destroy(o);
}

/*=================================================================================================
 * ↑Dataset Common Function
 *===============================================================================================*/



/*=================================================================================================
 * ↓File Common Function
 *===============================================================================================*/
/**
 * 엑셀 및 CSV 다운로드(서버상에서 생성한 파일 다운로드 요청)
 * @param  {Object} oFileInfo	파일다운로드 설정객체
 * <pre>
 * 파일설정객체의 Property
 * path : 파일Path
 * filename : 파일명
 * </pre>
 * @return n/a
 * @example this.gfn_downExpFile({path:"/cm", filename:"test.xlsx"});
 * @memberof global
 */
pForm.gfn_downExpFile = function(oFileInfo)
{
	var sPath = oFileInfo.path, sFileName = oFileInfo.filename;
	var sDownLoadUrl = NX.getSvcUrl("file") + "/cm/downdExpFile.do?path=" + sPath + "&fileName=" + sFileName;
	system.execBrowser(sDownLoadUrl);
}
 

 
/*=================================================================================================
 * ↓Excel Common Function
 *===============================================================================================*/
/**
 * 엑셀 Export처리 공통함수
 * @param	{Array} aGridLst 그리드배열
 * <pre>
 * aItem Export대상 상세설정 (optional)
 * - sheetname : sheet명정의
 * - title : 엑셀상단의 title설정
 * - titlealign : title의 정렬설정
 * - search : 조회조건(객체형)
 * - exceptcolumns : 제외컬럼지정 : "_chk"
 * </pre>
 * @param	{Object} oCfg 환경설정객체
 * <pre>
 * - onsuccess : (optional)Export 성공시 발생하는 이벤트함수명 지정
 * - onerror : (optional)Export 도중 오류가 생겼을때 발생하는 이벤트함수명 지정
 * - filename : (optional)Export하는 파일명을 지정할 경우 설정
 * </pre>
 * @return N/A
 * @example gfn_export([grdList1,grdList2]);
 * @memberof global
 */
pForm.gfn_export = function(aGridLst, oCfg)
{
	
	if(NX.isMobile()) return; //2018.12.28 모바일인 경우에는 동작안하게 반환처리
	
	var oExp = NX.Excel.constructor(this);
	if (oExp)
	{
		var oExpItem;
		for (var i=0, nCnt=aGridLst.length; i<nCnt; i++)
		{
			oExpItem = aGridLst[i];
			if (oExpItem instanceof Grid)
			{
				oExp.addExpItem({grid:oExpItem});
			}
			else
			{
				oExp.addExpItem(oExpItem);
			}
		}
		NX.Excel.export(oExp, oCfg);
	}
}


/**
 * 엑셀 Import처리 공통함수
 * @param {Object} oImpInfo 엑셀import설정객체 또는 배열
 * @param {Object} oCfg 환경설정객체
 * <pre>
 * oImpInfo 객체 속성
 * - head 		: (optional) 헤드 컬럼 영역, 생략 시 컬럼명은 Column0,Column1… 로 자동 생성 (형식 : Sheet!Cell:Cell)
 * - body 		: (optional) 바디 컬럼 영역, 생략 시 모든 레코드 반환 (형식 : Sheet!Cell:Cell)
 * - dataset 	: import transaction의 처리 결과를 받을 Dataset의 ID
 * - header 	: (optional) 헤더부분에 대한 설정, 읽어들일 Row설정됨
 * oCfg 	환경설정객체 속성
 * - onsuccess 	: (optional)Import 성공시 발생하는 이벤트함수명 지정
 * - onerror 	: (optional)Import 도중 오류가 생겼을때 발생하는 이벤트함수명 지정
 * </pre> 
 * @return N/A
 * @example this.gfn_import({dataset:"Dataset00"}, {onsuccess:"fnImportOnsuccess"});
 * @memberof global
 */
pForm.gfn_import = function(aImpInfo, oCfg)
{
	if (!Array.isArray(aImpInfo)) aImpInfo = [aImpInfo];
	
	var oImp = NX.Excel.constructor(this);
	if (oImp)
	{
		for (var i=0, nCnt=aImpInfo.length; i<nCnt; i++)
		{
			oImp.addImpItem(aImpInfo[i]);
		}
	}
	
	NX.Excel.import(oImp, oCfg);
}

/**
 * Import대상 엑셀파일의 sheet리스트를 반환하는 함수(this.gfn_import()함수 동일한 parameter사용)
 * @param {Object} oImpInfo 엑셀import설정객체 또는 배열
 * 			dataset : sheetlist에 대한 결과를 받을 Dataset의 ID
 * @param {Object} oCfg 환경설정객체(optional)
 * 			onsuccess : (optional)Import 성공시 발생하는 이벤트함수명 지정
 * 			onerror : (optional)Import 도중 오류가 생겼을때 발생하는 이벤트함수명 지정
 * @return N/A
 * @example this.gfn_getExcelSheets({dataset:"Dataset00"}, {onsuccess:"fnImportOnsuccess"});
 * @memberof global
 */
pForm.gfn_getExcelSheets = function(oImpInfo, oCfg)
{
	var oImp = NX.Excel.constructor(this);
	if (oImp)
	{
		oImpInfo.command = "getsheetlist";
		oImp.addImpItem(oImpInfo);
	}
	
	NX.Excel.import(oImp, oCfg);
}

/*=================================================================================================
 * ↑Excel Common Function
 *===============================================================================================*/
 
 
 
/*=================================================================================================
 * ↓Print Common Function
 *===============================================================================================*/
/**
 * UbiReport를 팝업호출화면에서 처리
 * @param {objects} oCfg Report 오픈 옵션 오브젝트
 * @return N/A
 * @example
 *  var oCfg = {file:"vertical3.jrf", runtime:false, localds:[this.ds_dtlList,this.ds_dtlList2], params:"title#코드상세#title2#RMCM120"};
 *  this.gfn_print(oCfg);
 * @memberof global
 */
pForm.gfn_print = function(oCfg)
{
	var sIsRuntime 	= oCfg.runtime;
	var sReportFile = oCfg.file;
	var sSvcUrl 	= oCfg.url;
	var sLocalDs 	= oCfg.localds;
	var oGrid 		= oCfg.grid;
	var sArgs 		= oCfg.params;
	var sScale      = oCfg.scale;
	var sExcelSkip  = oCfg.excelskip;
	
	// modeless의 경우 viewer웹페이지로 처리
	var oArgs = {runtime:sIsRuntime, file:sReportFile, url:sSvcUrl, localds:sLocalDs, grid:oGrid, params:sArgs, scale:sScale, excelskip:sExcelSkip};
	this.gfn_popup("_com_ubiview_" + sReportFile.replace(".", "_"), "com::com_ubipreview.xfdl", {config:oArgs},{style:"resizable=true"});
}

/*=================================================================================================
 * ↑Print Common Function
 *===============================================================================================*/

 
/*=================================================================================================
 * ↓Chart Function
 *===============================================================================================*/
/**
 * 차트생성호출 함수
 * @param  {String} sChartId (필수)차트ID(unique하게 설정)
 * @param  {Object} oDiv (필수)차트가 위치할 div 의 id (즉, 차트의 부모 div 의 id)
 * @param  {String} sChartVars 차트 생성 시 필요한 환경 변수들의 묶음인 chartVars(생략가능)
 * @param  {String} sWidth 차트의 가로 사이즈 (생략 가능, 생략 시 100%)
 * @param  {String} sHeight 차트의 세로 사이즈 (생략 가능, 생략 시 100%)
 * @return N/A
 * @memberof global
 */
pForm.gfn_drawChart = function(sChartId, oDiv, sChartVars, sWidth, sHeight)
{
	sChartVars 	= sChartVars || "rMateOnLoadCallFunction=_rMateChartReadyHandler";
	sWidth 		= sWidth || "100%";
	sHeight 	= sHeight || "100%";	
	var sHolderId = Util.getHolderId(oDiv);
	
	rMateChartH5.create(sHolderId + "_" + sChartId, sHolderId, sChartVars, sWidth, sHeight);
}

/**
 * 차트설정함수
 * @param  {String} sLayout (필수)차트형식
 * @param  {String} sChartData (필수)차트데이터
 * @return N/A
 * @memberof global
 */
pForm.gfn_setChart = function(sId, sLayout, sChartData)
{
	if (sId)
	{
		if (sChartData instanceof Dataset)
		{
			sChartData = Util.getChartData(sChartData);
		}
		
		var oEle = document.getElementById(sId);
		if (oEle)
		{
			oEle.setLayout(sLayout);
			oEle.setData(sChartData);
			if (!sChartData) oEle.hasNoData(true);
		}
	}
	else
	{
		Util.trace("this.gfn_setChart :: confirm chart_id => " + sId);
	}
}

/*=================================================================================================
 * ↑Chart Function
 *===============================================================================================*/


/**
 * [페이지처리] 거래호출시 사용한 헤더Dataset을 반환
 * @param {String}	sRequestId	거래ID : Transaction을 구분하기 위한 정보
 * @example this.gfn_getCmmHeaer(sSvcId);
 * @memberof global
 */
pForm.gfn_getCmmHeader = function(sSvcId)
{
	return this.objects["_dsCmmHeader_" + sSvcId.replace(/[\.\/]/g, "")];
}

/**
 * [페이지처리-Scroll] scroll페이징방식에서 임시로 생성된 Dataset을 반환하는 함수
 * @param {Object}	oOutDs	output으로 지정한 dataset
 * @example this.gfn_getPageDs(this.dsOutList);
 * @memberof global
 */
pForm.gfn_getPageDs = function(oOutDs)
{
	return this.objects[NX.Service._PAGE_OUTPUT_PREFIX + oOutDs.name];
}

/** 
 * [페이지처리-Scroll] 다음페이지 여부반환
 * @memberof global
 */
pForm.gfn_isNextPage = function(sSvcId)
{
	var oDs = this.gfn_getCmmHeader(sSvcId);
	if (oDs)
	{
//		return oDs.getColumn(0, "existNextPage") != "N";
		var nPageSize 	= parseInt(oDs.getColumn(0, "pageSize"));
		var nPageNo 	= parseInt(oDs.getColumn(0, "pageNo"));
		return parseInt(oDs.getColumn(0, "totalCnt")) > (nPageSize * nPageNo);
	}
}

/**
 * Service 처리(일반 Service 호출에 적용).
 * @param {String}	sRequestId	거래ID(Transaction을 구분하기 위한 정보)
 * @param {String}	sCtrlr	Controller
 * @param {String}	sInDs 	Input DatasetList
 * @param {String}	sOutDs 	Output DatasetList
 * @param {String}	sArgument Argument (key=value 쌍으로 구성되며 “ “로 구분됨)
 * @param {String}	sCallback Transaction 수행 후 결과 Return Fuctnion
 * @param {String}	sMsgType	Transaction Type 정의(Status 정보 표현:CRUD)
 * @param {Object}	oOptional
 * <pre>
 * * async			- 비동기 호출여부(default : true)
 * * usermsg		- 사용자 정의 Message 처리 (서비스 호출후 Status메시지)
 * * errpopup		- 에러발생시 화면에 공통에러창 팝업여부 (true : 팝업미호출, false : 팝업호출(default))
 * </pre>
 * @example  this.gfn_trans(sRequestId, sInDs, sOutDs, sArgument, sCallback, sMsgType, {})
 * @memberof global
 */
pForm.gfn_trans = function(sSvcId, sCtrlr, sInDs, sOutDs, sArgument, sCallback, sMsgType, oOptional)
{
	if (!sSvcId && !sCtrlr)
	{
		return this.gfn_msgBox("A", "필수입력 항목을 확인하세요.\n서비스ID : " + sSvcId + ", Controller : " + sCtrlr);
	}

	oOptional 			= oOptional || {};
	oOptional.msgtype 	= Util.trim(sMsgType);
		
	var sInData 		= sInDs;
	var sOutData 		= sOutDs;
	var sArgs			= sArgument;
	var sCallbackFnc	= sCallback || "fn_callback";
	var oContainer		= oOptional.container || this;
	
//	if (gvIsLoadFrame) 	gv_frm_top.form.fnResetTimer();

	var oTr = NX.getClass({type:"service", container:oContainer});
	return oTr.trans(sSvcId, sCtrlr, sInData, sOutData, sArgs, sCallbackFnc, oOptional);
}

/**
 * Service 호출 후 CallBack Function.
 * @private
 * @param  sSvcId     - Transaction을 구분하기 위한 ID
 * @param nErrorCode  - Error Code
 * @param sErrorMsg - Error Message
 * @memberof global
 */
pForm._gfn_callback = function(sSvcId, nErrorCode, sErrorMsg)
{
	NX.Service._callback.call(this, sSvcId, nErrorCode, sErrorMsg);
}

pForm._gfn_sso_callback = function(sPopupId, sRtn)
{
	//Util.execBrowser(Util._getRelUrl("portal")); // 포탈화면 호출
	application.exit();
}

/**
 * Combo컴포넌트를 위한 공통코드 조회
 * @param {Object} aInqryInfo 조회정보를 담은 객체
 * <pre>
 * aInqryInfo 조회조건객체의 속성
 * - code 		(필수)	조회공통코드
 * - dataset 	(선택)	결과수신 Dataset
 * - datacolumn (선택)	바인딩처리시 data컬럼으로 사용될 컬럼ID 지정 (default : name)
 * - combo 		(선택)	조회후 바인딩처리 콤보지정
 * - index 		(선택)	조회후 바인딩한 combo의 index지정시
 * - grid		(선택)	조회후 바인딩처리 그리드지정(그리드ID@컬럼명)
 * - addrow 	(선택)	combo 구성시 행추가("select" : [선택], "all" : [전체]), 설정한 combo는 index값 0으로 설정
 *            			array로 구성해서 ["select", "ALL"] 형태로 보내면 추가Row의 컬럼값으로 emptystring대신에 "ALL"로 설정
 * - format 	(선택)	코드명 보여지는 형식지정 all : [코드] 코드명, default : 코드명
 * - classtype  (선택)	분류유형코드 지정
 * - filterstr  (선택) reference컬럼(attr1, attr2, attr3 ...)에 대한 필터링할 조건을 기술 ex) "attr1 == 'RM' && attr1 == 'CM'"
 * oCfg 설정객체에 대한 속성
 * - serviceid 	(선택)	callback함수에서 수신될 서비스ID지정
 * </pre> 
 * @param {String} sCallback callback함수명 (default:fn_cmmCodeCallback)
 * @param {String} oCfg 설정객체callback에서 사용할 서비스id 
 * @example this.gfn_getCmmData([	{code:"01", dataset:"dsList05"},
 *									{code:"09", dataset:"dsList06", grid:"grdList@Column2"}],
 *									{code:"09", dataset:"dsList06", grid:"grdList@Column2", format:"all"}
 *								]);
 * @memberof global
 */
pForm.gfn_getCmmData = function(aInqryInfo, sCallback, oCfg)
{
	oCfg = oCfg || {};
	var sSvcType = oCfg.type || "service";
	var bAsync = oCfg.async || true;
	
			
	switch (sSvcType)
	{
		case "service" 	: 
			var sCodeList 	= "", sCodeDsList = "", sBindInfo = "";
			var sServiceId 	= "retrieveCommCdList";
			var sCtrlr 		= "comm/cp/retrieveCommCdList.do";
			var oInquiryDs 	= DatasetEx._get("_dsComboInquiryList_", this);
			if (oInquiryDs.colcount > 0)
			{
				oInquiryDs.clearData();
			}
			else
			{
				oInquiryDs.copyData(application._gdsCmmCodeInquiryFormat);
			}
			
				
			var oInquiry, sBigCtgryCd, sFilterStr, nRow, nFindRow;
			for (var i=0, nCnt=aInqryInfo.length; i<nCnt; i++)
			{
				oInquiry 	= aInqryInfo[i];
				sBigCtgryCd = oInquiry.code;
				sFilterStr 	= oInquiry.filterstr || ""; // only process local browser(AA)
				sUseYn      = oInquiry.useyn || "Y";
				
				// TODO. check mandatory parameter
				
				// skip duplicated commoncode
				nFindRow = oInquiryDs.findRow(NX.Service._SEARCH_CODE_COLUMN, sBigCtgryCd);
				if (nFindRow < 0)
				{
					nRow = oInquiryDs.addRow();
					oInquiryDs.setColumn(nRow, NX.Service._SEARCH_CODE_COLUMN, sBigCtgryCd);
					oInquiryDs.setColumn(nRow, NX.Service._RESULT_USEYN_COLUMN, sUseYn);
				}
 				else
 				{
					// clear distribution_code for duplicated common_code
//					oInquiryDs.setColumn(nFindRow, "itgCdClsTypStrtVl", "");
// 					Util.trace("[Info] lib_svc.xjs -> gfn_getCmmData() 공통코드 중복처리 : "  + sBigCtgryCd);
 				}
			}
			
			var oResultDs = DatasetEx._get("_dsCmmCodeRsltLst_", this);
			if (oResultDs.colcount > 0)
			{
				oResultDs.clearData();
			}
			else
			{
				oResultDs.copyData(application._gdsCmmCodeResultFormat);
			}

			var sCallbackNm = sCallback || "fn_cmmCodeCallback";
			this.gfn_trans(	sServiceId, 
							sCtrlr,
							"ds_commICd=" + oInquiryDs.name, 
							oResultDs.name + "=ds_commOCd", 
							"", 
							sCallbackNm,
							"Z",
							{serviceid:oCfg.serviceid, realcallback:"_gfn_commoncode_callback", cmmcodeinfo:aInqryInfo, async:bAsync}
							);
			break;
	}
}

/**
 * Combo컴포넌트를 위한 공통코드 조회
 * @param {Object} aInqryInfo 조회정보를 담은 객체
 * <pre>
 * aInqryInfo 조회조건객체의 속성
 * - code 		(필수)	조회공통코드
 * - dataset 	(선택)	결과수신 Dataset
 * - datacolumn (선택)	바인딩처리시 data컬럼으로 사용될 컬럼ID 지정 (default : name)
 * - combo 		(선택)	조회후 바인딩처리 콤보지정
 * - index 		(선택)	조회후 바인딩한 combo의 index지정시
 * - grid		(선택)	조회후 바인딩처리 그리드지정(그리드ID@컬럼명)
 * - addrow 	(선택)	combo 구성시 행추가("select" : [선택], "all" : [전체]), 설정한 combo는 index값 0으로 설정
 *            			array로 구성해서 ["select", "ALL"] 형태로 보내면 추가Row의 컬럼값으로 emptystring대신에 "ALL"로 설정
 * - format 	(선택)	코드명 보여지는 형식지정 all : [코드] 코드명, default : 코드명
 * - classtype  (선택)	분류유형코드 지정
 * - filterstr  (선택) reference컬럼(attr1, attr2, attr3 ...)에 대한 필터링할 조건을 기술 ex) "attr1 == 'RM' && attr1 == 'CM'"
 * oCfg 설정객체에 대한 속성
 * - serviceid 	(선택)	callback함수에서 수신될 서비스ID지정
 * </pre> 
 * @param {String} sCallback callback함수명 (default:fn_cmmCodeCallback)
 * @param {String} oCfg 설정객체callback에서 사용할 서비스id 
 * @example this.gfn_getCmmData([	{code:"01", dataset:"dsList05"},
 *									{code:"09", dataset:"dsList06", grid:"grdList@Column2"}],
 *									{code:"09", dataset:"dsList06", grid:"grdList@Column2", format:"all"}
 *								]);
 * @memberof global
 */
pForm.gfn_getCmmMisData = function(aInqryInfo, sCallback, oCfg)
{
	oCfg = oCfg || {};
	var sSvcType = oCfg.type || "service";
	var bAsync = oCfg.async || true;
	
			
	switch (sSvcType)
	{
		case "service" 	: 
			var sCodeList 	= "", sCodeDsList = "", sBindInfo = "";
			var sServiceId 	= "retrieveCommMisCdList";
			var sCtrlr 		= "comm/cp/retrieveCommMisCdList.do";
			var oInquiryDs 	= DatasetEx._get("_dsComboInquiryList_", this);
			if (oInquiryDs.colcount > 0)
			{
				oInquiryDs.clearData();
			}
			else
			{
				oInquiryDs.copyData(application._gdsCmmCodeInquiryFormat);
			}
			
				
			var oInquiry, sBigCtgryCd, sFilterStr, nRow, nFindRow;
			for (var i=0, nCnt=aInqryInfo.length; i<nCnt; i++)
			{
				oInquiry 	= aInqryInfo[i];
				sBigCtgryCd = oInquiry.code;
				sFilterStr 	= oInquiry.filterstr || ""; // only process local browser(AA)
				sUseYn      = oInquiry.useyn || "Y";
				
				// TODO. check mandatory parameter
				
			 	// skip duplicated commoncode
				nFindRow = oInquiryDs.findRow(NX.Service._SEARCH_CODE_COLUMN, sBigCtgryCd);
				if (nFindRow < 0)
				{
					nRow = oInquiryDs.addRow();
					oInquiryDs.setColumn(nRow, NX.Service._SEARCH_CODE_COLUMN, sBigCtgryCd);
					oInquiryDs.setColumn(nRow, NX.Service._RESULT_USEYN_COLUMN, sUseYn);
				}
 				else
 				{
					// clear distribution_code for duplicated common_code
//					oInquiryDs.setColumn(nFindRow, "itgCdClsTypStrtVl", "");
// 					Util.trace("[Info] lib_svc.xjs -> gfn_getCmmData() 공통코드 중복처리 : "  + sBigCtgryCd);
 				}
			}
			
			var oResultDs = DatasetEx._get("_dsCmmCodeRsltLst_", this);
			if (oResultDs.colcount > 0)
			{
				oResultDs.clearData();
			}
			else
			{
				oResultDs.copyData(application._gdsCmmCodeResultFormat);
			}

			var sCallbackNm = sCallback || "fn_cmmCodeCallback";
			this.gfn_trans(	sServiceId, 
							sCtrlr,
							"ds_commICd=" + oInquiryDs.name, 
							oResultDs.name + "=ds_commOCd", 
							"", 
							sCallbackNm,
							"Z",
							{serviceid:oCfg.serviceid, realcallback:"_gfn_commoncode_callback", cmmcodeinfo:aInqryInfo, async:bAsync}
							);
			break;
	}
}

/**
 * 서브타이틀이 가변인경우 총건수 붙여주는 공통함수
 * @param  {object}  oSubTitle  - 서브타이틀 오브젝트
 * @param {object}  oResultCnt - 서브타이틀 옆에 붙을 총건수 오브젝트
 * @param {string} sTitle - 서브타이틀
 * @example
 *   this.gfn_setMoveSubResult(this.sta_title02,this.sta_resultCnt_grd_dtlList,"가나다라마바사아다차카마다.");
 * @memberof global
 */ 
pForm.gfn_setMoveSubResult = function(oSubTitle,oResultCnt,sTitle)
{
    oSubTitle.style.set_font("bold 12 Malgun Gothic");
	var oFont = oSubTitle.style.font;
    var oTextSize = nexacro.getTextSize(sTitle,oFont);
    var nWidth = oTextSize.nx+30;
    var nLeft = parseInt(oSubTitle.left)+nWidth;
    oSubTitle.set_text(sTitle);    
    oSubTitle.set_width(nWidth);
    
    oResultCnt.move(nLeft);
}

/**
 * 공통코드조회 CallBack Function.
 * @private
 * @param  sSvcId     - Transaction을 구분하기 위한 ID
 * @param nErrorCode  - Error Code
 * @param sErrorMsg - Error Message
 * @memberof global
 */ 
pForm._gfn_commoncode_callback = function(sSvcId, nErrorCode, sErrorMsg)
{
	NX.Service._cmmCodeCallback.call(this, sSvcId, nErrorCode, sErrorMsg);
}


/**
 * 사용자 정보 반환 함수
 * @param  sCol     - gdsUserInfo에 적용되어있는 col ID
 * @example
 *   var sUserNm = this.gfn_getUserInfo("userNm");  
 * @memberof global
 */ 
pForm.gfn_getUserInfo = function(sCol)
{
    return application.gdsUserInfo.getColumn(0,sCol);
}                                                                   

/**
 * 파일 다운로드 함수
 * @param  sEcmOid     - 첨부파일 oId
 * @example
 *   this.gfn_download("oid");  
 * @memberof global
 */ 
pForm.gfn_download = function(sEcmOid,sFileNm)
{
	
	if(NX.isMobile()) return; //2018.12.28 모바일인 경우에는 동작안하게 반환처리
	
	if(Util.isNull(sEcmOid)) return;
	
	var sFileDownload = "_fdl_"+this.name;
    var oFileDownload = this.components[sFileDownload];
    
    var fileNm = (Util.isNull(sFileNm)) ? "" : "&fileNm="+sFileNm;
    
    
    if(Util.isNull(oFileDownload))
    {
    	oFileDownload = new FileDownload();
    	this.addChild(sFileDownload,oFileDownload);
    	oFileDownload.show();
    }

	var sUrl = application.services[NX.DEFAULT_SVC_GRP].url + NX.File._DEFAULT_FILE_CONFIG.downloadUrl+sEcmOid+fileNm;
	
	oFileDownload.download(sUrl);	    
}

/**
 * 파일업로드 모듈형 컴포넌트 호출 
 * @param  {object} obj 그리드 또는 데이터셋
 * @param  {object} oCfg 파일업로드관련 환경 파일
 * <pre>
 *   * 옵션 Grid인 경우
 *     - oCfg.tempId  : 임시ID컬럼
 *   
 *   * 옵션 Dataset인 경우
 *     - oCfg.fileNmCol : 파일명 컬럼ID
 *     - oCfg.fileSizeCol : 파일사이즈 컬럼ID
 *     - oCfg.pathFileNmCol : 임시파일 경로파일 컬럼ID
 *   * 공통 옵션
 *     - oCfg.allowTypes : 파일 확장자 제한 옵션   EX) ["jpg","png","gif"]
 *     - oCfg.fileFilter  : 파일 다이아로그 파일필터 적용 EX) NX.File.setFileFilter String 필터 적용 부분 참조
 *     - oCfg.callback : 파일콜백
 *   * 모바일 옵션
 *     - oCfg.selectType = "C": 카메라전용 , "F" : 파일선택전용 , "FC" : 카메라 또는 파일선택 선택창 활성화  Default : C  
 * </pre> 
 * @example
 *   this.gfn_addFile(this.grd_list); 
 * @memberof global 
 */ 
pForm.gfn_addFile = function(obj,oCfg)
{
	if(!(obj instanceof Grid || obj instanceof Dataset)) return;
	
	var sSelectType = "";
	var bMulti = (obj instanceof Grid) ? false : true;
	if(!bMulti)
	{
		if(Util.isNull(oCfg.fileNmCol)) return;
		if(Util.isNull(oCfg.fileSizeCol)) return;
		if(Util.isNull(oCfg.pathFileNmCol)) return;		
	}
	else
	{
		if(Util.isNull(oCfg.tempId)) return;
	}

	if(nexacro.OS == "Android" && nexacro.Browser == "Runtime")
	{
		sSelectType = (Util.isNull(oCfg.selectType)) ? "C" : oCfg.selectType;
		
		if(sSelectType == "FC")
		{
			this.gfn_popup(	"com_file_select", 
							"com::com_file_select.xfdl", 
							{pv_obj:obj, pv_oCfg:oCfg});			
		}
		else
		{
			this._addFile(obj,oCfg,sSelectType);
		}
	}
	else
	{	    
        sSelectType = "F";
		this._addFile(obj,oCfg,sSelectType);
	}
}

pForm._addFile = function(obj,oCfg,sType)
{
    var sUniqueId = "extUp_"+NX.getUniqueId(obj.name,this);
    var sUniqueIdCamera = "extUp_"+NX.getUniqueId(obj.name,this)+"_camera";
	var bMulti = (obj instanceof Grid) ? false : true;	
	var extUp;
	
	if(sType == "C")
	{
		extUp = this.objects[sUniqueIdCamera];
		
		if(Util.isNull(extUp))
		{
			Util.trace("extUp start=================================");
			extUp = new nexacro.Camera(sUniqueIdCamera, this);
			Util.trace("extUp end =================================");
			Util.trace("addChild start=================================");
			this.addChild(sUniqueIdCamera, extUp);
			Util.trace("addChild end=================================");
			
			//카메라를 이용하여 촬영하고 난 후 확인했을때의 이벤트
			Util.trace("sUniqueId ::::: " + sUniqueId);
			Util.trace("sUniqueIdCamera ::::: " + sUniqueIdCamera);
			Util.trace("extUp ::::: " + extUp);
			Util.trace("addEventHandler oncapture start=================================");
			extUp.addEventHandler("oncapture", this._gfn_extUpload_oncapture, this);
			Util.trace("addEventHandler oncapture end=================================");
			
			//통신 오류 시 발생하는 이벤트
			extUp.addEventHandler("onerror", this._gfn_extUpload_onerror, this);  
				  
			extUp.set_imagewidth(480); //촬영시 이미지크기 제한
			extUp.set_imageheight(320);	//촬영시 이미지크기 제한
			extUp.set_gettype(1);
			extUp.fileConfig = {};
			Util.copyProperties(extUp.fileConfig,NX.File._DEFAULT_FILE_CONFIG);
			
			if(!bMulti) extUp.fileConfig.maxCount = -1;       
			
		}
		
		if(!Util.isNull(oCfg.allowTypes))
        {
			extUp.fileConfig.allowTypes = oCfg.allowTypes;			
		}
		else
		{
			extUp.fileConfig.allowTypes = NX.File._DEFAULT_FILE_CONFIG.allowTypes;
		}
		
		extUp._targetObject = obj;
		extUp._tagetColInfo = oCfg;
		extUp._callback = oCfg.callback;
		extUp.takePicture();			
	}
	else
	{
		
	    this.transferType = "all";
	    
		//런타임환경이면 Filedialog를 생성
		//if(nexacro.OS == "Android" && nexacro.Browser == "Runtime")
		if(nexacro.Browser == "Runtime") //테스트 하기 위해 안드로이드 조건은 임시 주석처리
		{
			extUp = this.components[sUniqueId];
			if(Util.isNull(extUp))
			{
   				extUp = new FileUpload(sUniqueId,"absolute", 0, 0, 0, 0, null, null);
				this.addChild(sUniqueId, extUp);			
				
				extUp.addEventHandler("onitemchanged", this._gfn_fileUpload_onitemchanged, this);
				
				extUp.show();
				extUp.set_multiselect(bMulti);
								
			}	
			
			extUp._targetObject = obj;
			extUp._tagetColInfo = oCfg;
			extUp._callback = oCfg.callback;	 

			extUp.filefindbuttons[0].click();			
		}
		else
		{
			extUp = this.components[sUniqueId];
			if(Util.isNull(extUp))
			{
				extUp = new nexacro.ExtFileUpload(sUniqueId, this);
				this.addChild(sUniqueId, extUp);
				//	파일 다이얼로그를 통해 파일을 선택했을 때 발생하는 이벤트입니다
				extUp.addEventHandler("onchange", this._gfn_extUpload_onchange, this);
				
				//통신 성공시에 발생하는 이벤트입니다
				extUp.addEventHandler("onsuccess", this._gfn_extUpload_onsuccess, this);
				
				//통신 오류 시 발생하는 이벤트입니다.
				extUp.addEventHandler("onerror", this._gfn_extUpload_onerror, this);  
					  
				extUp.fileConfig = {};
				Util.copyProperties(extUp.fileConfig,NX.File._DEFAULT_FILE_CONFIG);
				
				extUp.fileConfig.uploadUrl = "/comm/cp/getCommAttchFile.do";
				extUp.show();
			}
			
			extUp.set_multiselect(bMulti);
			
			if(!bMulti) extUp.fileConfig.maxCount = -1;
				
			if(!Util.isNull(oCfg.allowTypes))
			{
				extUp.fileConfig.allowTypes = oCfg.allowTypes;			
			}
			else
			{
				extUp.fileConfig.allowTypes = NX.File._DEFAULT_FILE_CONFIG.allowTypes;
			}
			
			if(!Util.isNull(oCfg.fileFilter))
			{
				NX.File.setFileFilter(extUp,oCfg.fileFilter);
			}
			else
			{
				NX.File.setFileFilter(extUp,extUp.fileConfig.allowTypes);
			}				
			
			extUp._targetObject = obj;
			extUp._tagetColInfo = oCfg;
			extUp._callback = oCfg.callback;	
			
			extUp.addFiles();			
		}
	}	
}

pForm._gfn_fileUpload_onitemchanged = function(obj,e)
{
    var sVal = obj.value;
    if(Util.isNull(sVal)) return;
	
	var oDs = DatasetEx._get("ds_"+obj.name,this);
	
	if(oDs.getColCount() == 0)
	{
		oDs.addColumn("imgData","String");
		oDs.addColumn("fileNm","String");
	}
		
	oDs.clearData();
	
	var vf = new VirtualFile();
    vf._targetDataset = oDs;	
	vf.set_async(false);	
	vf.addEventHandler("onsuccess", this._gfn_vf_onsuccess, this);
	
	if(sVal.indexOf(",") > -1)
	{
		var aVal = sVal.split(",");	
		
		for(var i=0; i<aVal.length; i++)
		{
		   var sPath = aVal[i].trim();
		   var sFileNm = this._gfn_getFileName(sPath);
		   oDs.addRow();
		   oDs.setColumn(i, "fileNm", sFileNm);
		   vf.open(sPath,VirtualFile.openBinary);
		}			
	}
	else
	{
	   var sFileNm = this._gfn_getFileName(sVal);
	   oDs.addRow();
	   oDs.setColumn(i, "fileNm", sFileNm);
	   vf.open(sVal,VirtualFile.openBinary);
	}
	
	this.gfn_trans(	"comm"+obj.name, 
			"/comm/cp/getCommAttchFileSw.do",
			"ds_commAttchFile=" + oDs.name, 
			oDs.name + "=ds_commAttchFile", 
			"", 
			"_gfn_extUpload_callback"
			);		
}

pForm._gfn_getFileName = function(sFilePath)
{
	var nIdx = 0;
	if(nexacro.OS == "Android")
	{
		nIdx = sFilePath.lastIndexOf("/");	
	}
	else
	{
	    nIdx = sFilePath.lastIndexOf("\\");	
	}
	
	var sFileName = sFilePath.substring(nIdx+1,sFilePath.length);
	
	return sFileName;
}

pForm._gfn_fileDialog_onclose = function(obj,e)
{
	var vf = new VirtualFile();
	vf.set_async(false);	
	vf.addEventHandler("onsuccess", this._gfn_vf_onsuccess, this);
	
	var oDs = DatasetEx._get("ds_"+obj.name,this);
	
	if(oDs.getColCount() == 0)
	{
		oDs.addColumn("imgData","String");
		oDs.addColumn("fileNm","String");
	}
	
	oDs.clearData();
	vf._targetDataset = oDs;
	
	for(var i=0; i<e.virtualfiles.length; i++)
	{
	   oDs.addRow();
	   oDs.setColumn(i, "fileNm", e.virtualfiles[i].filename);
	   vf.open(e.virtualfiles[0].fullpath,VirtualFile.openBinary);
	}
	
	trace(oDs.saveXML());
	/*
	this.gfn_trans(	"comm"+obj.name, 
			"/comm/cp/getCommAttchFileSw.do",
			"ds_commAttchFile=" + oDs.name, 
			oDs.name + "=ds_commAttchFile", 
			"", 
			"_gfn_extUpload_callback"
			);	
	*/
	
}

pForm._gfn_vf_onsuccess = function(obj,e)
{  
   var oDs = obj._targetDataset;
   
   switch(e.reason)
   {
       case 1 : obj.read(); break;
       case 2 : break;
       case 3 :
	      oDs.setColumn((oDs.rowcount-1),"imgData",e.binarydata);
          obj.close();
       break;
   }	
}

pForm._gfn_extUpload_oncapture = function(obj,e)
{
	Util.trace("_gfn_extUpload_oncapture start=================================");
	if(Util.isNull(e.imagedata)) return;
	
	Util.trace("1=================================");
	
	var nStart = e.url.lastIndexOf("/");
	
	Util.trace("nStart ::::: " + nStart);
	
	var oDs = DatasetEx._get("ds_"+obj.name,this);
	
	Util.trace("2=================================");
	Util.trace("oDs.getColCount() ::::: " + oDs.getColCount());
	
	if(oDs.getColCount() == 0)
	{
		Util.trace("oDs.getColCount() == 0 start =====");
		oDs.addColumn("imgData","String");
		Util.trace("imgData ======== ");
		
		oDs.addColumn("fileNm","String");
		Util.trace("fileNm ======== ");
	}
	
	Util.trace("oDs.getColCount() == 0 END =====");
	oDs.clearData();
	Util.trace("oDs.clearData() ===== ");
	oDs.addRow();
	Util.trace("oDs.addRow() ===== ");
	
	oDs.setColumn(0, "fileNm", e.url.substr(nStart + 1));
	
	Util.trace("fileNm ::::: " + e.url.substr(nStart + 1));
	
	oDs.setColumn(0,"imgData",e.imagedata);
	
	Util.trace("imgData ::::: " + e.imagedata);
	
	Util.trace("gfn_trans Start ============= ");
	
	this.gfn_trans(	"comm"+obj.name, 
			"/comm/cp/getCommAttchFileSw.do",
			"ds_commAttchFile=" + oDs.name, 
			oDs.name + "=ds_commAttchFile", 
			"", 
			"_gfn_extUpload_callback"
			);
	
	Util.trace("gfn_trans end ============= ");
			
	//사진 캡쳐인 경우에는 바이너리 타입으로 와서 Base64 String으로 변환후 전송
	//this.gfn_fileBirnaryToBase64(e.imagedata,"_oncapture_fileBirnaryToBase64",oDs)
}

/*
pForm._oncapture_fileBirnaryToBase64 = function(sData,oDs)
{
	oDs.setColumn(0,"imgData",sData);
	
	this.gfn_trans(	"comm"+obj.name, 
			"/comm/cp/getCommAttchFileSw.do",
			"ds_commAttchFile=" + oDs.name, 
			oDs.name + "=ds_commAttchFile", 
			"", 
			"_gfn_extUpload_callback"
			);
}
*/

pForm._gfn_extUpload_callback = function(sSvcId, nErrorCode, sErrorMsg)
{
	Util.trace("_gfn_extUpload_callback ============= ");
	Util.trace("nErrorCode :: " + nErrorCode +"\nsErrorMsg :: " + sErrorMsg);
	if (nErrorCode < 0) return; 
	
	var sExtUpId = sSvcId.replace("comm","");
	
	var obj = this.objects[sExtUpId];

	if(Util.isNull(obj)) obj = this.components[sExtUpId];
	
	var outDs = this.objects["ds_"+sExtUpId];
	var sCallback = obj._callback;
	
	var targetObj = obj._targetObject;
	
	
	
	var oDs = (targetObj instanceof Grid) ? this.objects[targetObj.binddataset] : targetObj;
	
	if(targetObj instanceof Dataset)
	{
		for(var i=0; i<outDs.rowcount; i++)
		{
            outDs.setColumn(i,"tempId",obj._tagetColInfo.tempId);				
		}
		
		oDs.appendData(outDs,true,false);
	}
	else
	{
		var nRow = oDs.rowposition;
		
		var sCopyCol = obj._tagetColInfo.fileNmCol+"=fileNm,"+obj._tagetColInfo.fileSizeCol+"=fileSize,"+obj._tagetColInfo.pathFileNmCol+"=pathFileNm";
		
		if(!Util.isNull(outDs.getColumn(0,"imgData"))) sCopyCol += ",imgData=imgData";
		
		oDs.copyRow(nRow,outDs,0,sCopyCol);
		
		if(nRowType == Dataset.ROWTYPE_NORMAL) DatasetEx.setRowType(oDs, nRow, DatasetEx.ROWTYPE_UPDATE);			
	}	  
	
    try{
		if(!Util.isNull(sCallback)) this[sCallback]();
	}catch(ex){}	
}

/**
 * 파일 다이얼로그를 통해 파일을 선택했을 때 발생하는 이벤트입니다.
 * @param {ExtFileUpload} obj ExtFileUpload
 * @param {nexacro.ExtFileUploadChangeEventInfo} e ExtFileUploadChangeEventInfo
 */
pForm._gfn_extUpload_onchange = function(obj,  e)
{
	//trace("extUpload_onchange index=" + e.index + ", newvalue=" + e.newvalue   + ", oldvalue=" + e.oldvalue);
	var index = e.index;
 	var fileList = e.files;
 	var fileCount = fileList.length;
 	var fileSupport = (obj.support.XHR2 && obj.support.FileAPI);
	
	if(fileCount > 0)
	{
		for(var i=0; i<fileCount; i++)
		{		
			var file = fileList[i];
			var tempfilekey   = file.id;
			var fileName = file.name;
	        var fileSize = file.size;
	        var fileType = file.type;
	        var fileFullpath = file.fullpath; 
	          
	          
			var cond;
			if (fileSupport)
			{
				cond = {"name" : fileName, "length" : fileCount, "size" : fileSize, "totalSize" : fileSize};
			}
			else
			{
				cond = {"name" : fileName, "length" : fileCount};
			}
			
			//var cond = {"name" : fileName, "length" : dsCount};
			var valid = NX.File.validateFile(cond,obj.fileConfig);
			
			//파일 유형 에러
			if (valid == 0)
			{
				obj.removeFile(tempfilekey);
				return;
			}
			else if (valid == -1) //최대 파일첨부가능 건수 또는 size 에러.
			{
				obj.removeFile(tempfilekey);
				return;
			}
		}
		
		var sUrl = application.services[NX.DEFAULT_SVC_GRP].url + obj.fileConfig.uploadUrl;
		
		this.setWaitCursor(true,true);
		obj.upload(sUrl, "","", this.transferType, 0);	
	}
}



/*
 *   통신 성공시에 발생하는 이벤트입니다
 */
pForm._gfn_extUpload_onsuccess = function(obj,  e)
{
//	trace("\n\n >>>> e.type=" + e.type);
	trace("extUpload_onsuccess errorcode=" + e.errorcode + ", errormsg=" + e.errormsg   + ", datasets=" + e.datasets + ", url=" + e.url + ", tempfilekey=" + e.tempfilekey );
	this.setWaitCursor(false,true);
	var sCallback = obj._callback;
	if(e.datasets.length > 0)
	{
		var outputDatasets = e.datasets;
		if(outputDatasets.length == 0) return;
		
		var outDs = outputDatasets[0];
		var targetObj = obj._targetObject;
		
		
		var oDs = (targetObj instanceof Grid) ? this.objects[targetObj.binddataset] : targetObj;
		
		if(obj.multiselect)
		{
			for(var i=0; i<outDs.rowcount; i++)
			{
                outDs.setColumn(i,"tempId",obj._tagetColInfo.tempId);				
			}
			
			oDs.appendData(outDs,true,false);
		}
		else
		{
			var nRow = oDs.rowposition;
			
			var sCopyCol = obj._tagetColInfo.fileNmCol+"=fileNm,"+obj._tagetColInfo.fileSizeCol+"=fileSize,"+obj._tagetColInfo.pathFileNmCol+"=pathFileNm";
			
			if(!Util.isNull(outDs.getColumn(0,"imgData"))) sCopyCol += ",imgData=imgData";
			
			oDs.copyRow(nRow,outDs,0,sCopyCol);
			
			var nRowType = DatasetEx.getRowType(oDs,nRow);
			
			if(nRowType == Dataset.ROWTYPE_NORMAL) DatasetEx.setRowType(oDs, nRow, DatasetEx.ROWTYPE_UPDATE);			
		}

        try{
			if(!Util.isNull(sCallback)) this[sCallback]();
		}catch(ex){}	
	}
}

pForm._gfn_extUpload_onerror = function(obj,  e)
{
	this.setWaitCursor(false,true);
    trace("파일 업로드중 에러가 발생하였습니다.");   
}

/**
 * Birnary데이터를 Base64 데이터로 변경 처리 (안드로이드 Runtime이 아닐경우에는 ByPass처리)
 * @param {objects} oData Birnary 데이터로
 * @param {String} sCallback 콜백받을 함수명
 * @param {object} oDs 함께 반환받을 데이터셋
 * @return callback함수 호출
 * @memberof global
 */
pForm.gfn_fileBirnaryToBase64 = function(oData,sCallback,oDs)
{
	if(nexacro.OS == "Android" && nexacro.Browser == "Runtime")
	{
		this.standardobj = new nexacro.Standard();
		this.standardobj.addEventHandler("oncallback", this._standard_callback, this);	
        this.standardobj._callback = sCallback;
		this.standardobj._dataset = oDs;
		var data =	{data1:"base64",data2:oData};
		this.standardobj.callMethod("nativeService_base64",data);
	}
	else
	{
		if(!Util.isNull(sCallback)) this[sCallback](oData,oDs);
	}
}

pForm._standard_callback = function(obj,e)
{
     var sCallback = obj._callback;
	 var oDs = obj._dataset;
	 
	 if(!Util.isNull(sCallback)) this[sCallback](e.returnvalue,oDs);
}

/**
 * UbiViewerLib를 사용하여 서버에 파일 저장
 * transaction 함수 사용. 숨기면서 콜백 사용 가능
 * Data : Local Dataset 사용
 * @memberof global
 */
pForm.gfn_reportParam = function(legacykey, scrnId, drftrFrm, drftrTitle, aReportInfo, aAttchFileInfo)
{
	var argument = legacykey + "||" + scrnId + "||" + drftrFrm + "||" + drftrTitle + "||"
	var oReportInfo;
	var oAttchFileInfo;

	this.commDraftStt = "";

	// 공통서비스 함수호출
	this.gfn_trans(	"commDraftStt"									// callback service_id
				   ,"/comm/cp/retrieveCommDraftSttMd.do"			// controller
				   ,""												// input dataset
				   ,""												// output dataset
				   ,"webDraftInfo=" + nexacro.wrapQuote(argument)	// variable
				   ,""												// callback function
				   ,"C" // 시스템 처리 구분 (C:생성, R:조회, U:수정, D:삭제, S:저장)
				   ,{async:false}
				   );

	if (this.commDraftStt = "NEW")
	{
		var sReportDs = "";
		if(!Util.isNull(aReportInfo))
		{
			for(var i=0; i<aReportInfo.length; i++)
			{
				oReportInfo = aReportInfo[i];
				
				sReportDs = "";
				
				if (!Util.isNull(oReportInfo.reprtDs)) 
				{
					if(Util.isString(oReportInfo.reprtDs))
					{
						if(oReportInfo.reprtDs == "SQL") sReportDs = "SQL";
					}
					else
					{
						sReportDs = this.gfn_ubiSsvData(oReportInfo.reprtDs);
					}
				}
				
				argument += "KEY_RP||" + oReportInfo.reprtNm + "||" + oReportInfo.reprtArgs + "||" + sReportDs + "||%%||"; 
			}
		}

		if(!Util.isNull(aAttchFileInfo)) 
		{
			var sAttchDs = "";
			for (var i = 0; i < aAttchFileInfo.length; i++) 
			{
				oAttchFileInfo = aAttchFileInfo[i];
				
				sAttchDs = "";
				
				if(!Util.isNull(oAttchFileInfo.attchDs))
				{
					if(Util.isString(oAttchFileInfo.attchDs))
					{
						if(oAttchFileInfo.attchDs == "SQL") sAttchDs = "SQL";
					}
					else
					{
						sAttchDs = this.gfn_ubiSsvData(oAttchFileInfo.attchDs);
					}
				}
				
				argument += "KEY_AF||" + oAttchFileInfo.attchNm + "||" + oAttchFileInfo.attchFrm + "||" + oAttchFileInfo.attchArgs + "||" +sAttchDs+ "||%%||";
			}
		}
	} 

	return nexacro.wrapQuote(argument);
}

/**
 * Ubi Report Dataset 문자열 치환
 * @param {objects} reprtDs 데이터셋정보 (배열 또는 데이터셋오브젝트)
 * @memberof global
 */
pForm.gfn_ubiSsvData = function(reprtDs)
{
	var _etx_ = String.fromCharCode(3);
	var _nrs_ = String.fromCharCode(28);
	var _ncs_ = String.fromCharCode(29);
	var _rs_  = String.fromCharCode(30);
	var _cs_  = String.fromCharCode(31);
	var _sp_  = String.fromCharCode(32);

	
	var ubiData = [];
	
	if(reprtDs instanceof Dataset)
	{
		ubiData.push([reprtDs.name, reprtDs]); // Dataset명(UbiReport에 지정된 명), this.데이터셋명(Nexacro의 데이터셋명)	
	}  
	else
	{
		var oTempDs;
		for(var i=0; i<reprtDs.length; i++)
		{
			oTempDs = reprtDs[i];
			ubiData.push([oTempDs.name, oTempDs]); // Dataset명(UbiReport에 지정된 명), this.데이터셋명(Nexacro의 데이터셋명)
		}
	}
//	ubiData.push(["Dataset00", this.Dataset00]);
	

	var ssvData = [];
	ssvData.push("LOCALDATASET:" + _rs_);

	for (var i = 0; i < ubiData.length; i++) {
		if (ubiData[i] && ubiData[i].length == 2) {
			ssvData.push(ubiData[i][0] + _cs_);
			ssvData.push(ubiData[i][1].name + _cs_);
			ssvData.push(_rs_);
		}
	}

	for (var i = 0; i < ubiData.length; i++ ) {
		if(ubiData[i] && ubiData[i].length == 2) {
			if(i == 0) {
				ssvData.push("SSV:utf-8" + _rs_);
			}
			ssvData.push(ubiData[i][1].saveSSV(ubiData[i][1].name, "A"));
		}
	}

	var ubiSsvData = ssvData.join("");
	ubiSsvData = this.replaceAll(ubiSsvData, _nrs_, "[_NRS_]");
	ubiSsvData = this.replaceAll(ubiSsvData, _ncs_, "[_NCS_]");
	ubiSsvData = this.replaceAll(ubiSsvData, _rs_ , "[_RS_]");
	ubiSsvData = this.replaceAll(ubiSsvData, _cs_ , "[_CS_]");
//	ubiSsvData = this.replaceAll(ubiSsvData, _etx_, "[_ETX_]"); // ETX는 문제가 있으므로 주석처리 한다.(ubi)
	ubiSsvData = this.replaceAll(ubiSsvData, _sp_ , "[_SP_]");

	return ubiSsvData;
}


/**
  * 문자열 치환 함수(유틸)
  * @param {string} str 원본문자열
  * @param {string} searchStr 찾읇문자열
  * @param {string} replaceStr 변경할문자열
  * @memberof global
  */
pForm.replaceAll = function(str, searchStr, replaceStr)
{
	return str.split(searchStr).join(replaceStr);
}


/**
 * 웹기안기 상신 팝업 오픈을 위한 url 만들기
 * @param {object} oDs 웹기안기 오픈정보 데이터셋
 * @memberof global
 */
pForm.gfn_callWebDraft = function(oDs)
{
    var oParam = {};
    var oColInfo;
    var sColId;
    var sData;
    var sUrl;
    for(var i=0; i<oDs.getColCount(); i++)
    {
        oColInfo = oDs.getColumnInfo(i);
        sColId = oColInfo.id;
        sData = oDs.getColumn(0,sColId);
        
        if(sColId == "url")
        {
            sUrl = sData;            
            continue;
        }
        
        oParam[sColId] = sData;
    }
         
    Util.execBrowserWithPost(this,{url:sUrl,popup:true,height:800,width:300,params:oParam});
    //Util.execBrowserWithPost(this,{url:sUrl,target:"_blank",height:800,width:600,params:oParam});
}

/**
  * 크로스도메인적용시 공통영역 활성화된 폼과 같은 도메인으로 적용되게 수정하는 함수사용해야함수
  * @private
  * @memberof global
  */
pForm.gfn_setCommSvc = function()
{
	if (!NX.isSystem("local") && (this.fvFormType == NX.FORM_WORK || this.fvFormType == NX.FORM_POP))
	{
		var aCommSvc = ["com","composite","img","snd"]; 
		var sComUrl = application.services["com"].url;
		var sOldGrp = NX._getSvcGrp(sComUrl);			
	    var sMenuUrl;
	    
	    if(this.fvFormType == NX.FORM_WORK)
	    {
	    	sMenuUrl = this.gfn_getFormInfo("menuurl");
	    }
	    else
	    {
	    	sMenuUrl = this.gfn_getFormInfo("formurl");
	    }
	   
	    var sGrp = sMenuUrl.split("::")[0];
	     
	     if(sGrp.length != 4) return;
	     
	     sGrp = sGrp.substr(0,2);
	     
	     if(sOldGrp != sGrp)
	     {
		     var oDs = NX.getApp().gdsSvcUrl;
		     oDs.filter("sysCd=='" + NX.system + "'");		
		     var nSvcIndex = oDs.findRow("svcGrp", sGrp);  
		     
		     if(nSvcIndex < 0) return;	 
			   
			 var sSvcUrl = Util.trim(oDs.getColumn(nSvcIndex, "svcUrl")) + ":" + Util.trim(oDs.getColumn(nSvcIndex, "svcPort"));
			 
			 for(var i=0; i<aCommSvc.length; i++)
			 {
			     var sComSvc = aCommSvc[i];
			     application.services[sComSvc].set_url(sSvcUrl+"/angs/common/"+sComSvc+"/");
			 }
		 }
	}	
}

/**
 * 그리드에 복사또는 붙여넣기 기능을 적용하는 공통함수 (selectrowtype : area로 강제변경)
 * @param {object} obj 그리드 컴포넌트
 * @return N / A
 * @example
 *   onload 함수에 적용하며 아래와 같이 적용한다.
 *   this.gfn_gridCopyPasteArea(this.grdList);
 * @memberof global
 */
pForm.gfn_gridCopyPasteArea = function(obj)
{
   obj.set_selecttype("area");
   obj.addEventHandler("onkeydown",this._girdPasteOnkeydownEvent,this);  
   obj.addEventHandler("onkeyup",this._girdCopyOnkeyupEvent,this);  
}

pForm._girdPasteOnkeydownEvent = function(obj,e)
{
     // 붙여넣기처리 공통함수
	if (e.ctrlKey && e.keycode == 86) // Ctrl+V
	{
		this.gfn_copy2paste(obj, e, {excel:true});
	}
}

pForm._girdCopyOnkeyupEvent = function(obj,e)
{
	// Ctrl+C (시스템클립보드에 복사처리)
	if (e.ctrlKey && e.keycode == 67)
	{
		this.gfn_copy2paste(obj, e, {excel:true});
	}
}

/**
 * 그리드에 PageUp PageDown Home End 키입력시 포커스 변경처리 
 * @param {object} obj 그리드 컴포넌트
 * @return N / A
 * @example
 *   onload 함수에 적용하며 아래와 같이 적용한다.
 *   gfn_setPageUpDownKey(this.grdList);
 * @memberof global
 */
pForm.gfn_setPageUpDownKey = function(obj)
{
    obj.addEventHandler("onkeydown",this._pageUpDownKey_onkeydown,this);
    obj.addEventHandler("onkeyup",this._pageUpDownKey_onkeyup,this);
}

pForm._pageUpDownKey_onkeydown = function(obj,e)
{
    if(e.keycode == 33 || e.keycode == 34)
    {
        if(Util.isNull(obj.__gappos)) obj.__gappos = (obj.currentrow-obj.vscrollbar.pos);
    }
}

pForm._pageUpDownKey_onkeyup = function(obj,e)
{
    var oDs = this.objects[obj.binddataset];
    if(oDs.rowcount < 1) return;
    
    switch(e.keycode)
    {
       case 33 : 
       case 34 : 
	    var nGap = (Util.isNull(obj.__gappos)) ? 0 : obj.__gappos;
	    
	    var nRow = obj.vscrollbar.pos+nGap;
	    
	    if(Util.isNull(oDs)) return;
	    
	    if(nRow > (oDs.rowcount-1)) nRow = (oDs.rowcount-1);
	    
	    if(obj.selecttype == "row")
	    {
	    	 obj.selectRow(nRow);
	    }
	    else
	    {
	    	var nPos = obj.getCellPos();
	    	obj.selectArea(nRow , nPos, nRow, nPos)
	    }
	    	    
	    obj.__gappos = null;
	  break;
	  case 36 :
		    if(obj.selecttype == "row")
		    {
		    	 obj.selectRow(0);
		    }
		    else
		    {
		    	var nPos = obj.getCellPos();
		    	obj.selectArea(0 , nPos, 0, nPos)
		    }		  
	  break;
	  case 35 : 
		    var nRow = oDs.rowcount-1;
		    if(obj.selecttype == "row")
		    {
		    	 obj.selectRow(nRow);
		    }
		    else
		    {
		    	var nPos = obj.getCellPos();
		    	obj.selectArea(nRow , nPos, nRow, nPos)
		    }		  
	  break; 
    }
}

/**
 * 조회조건 Div영역에 엔터키 입력시 조회 적용 함수 
 * @param {object} obj Div 컴포넌트(조회조건 Div)
 * @param {string} sFunc 엔터키 입력시 호출할 함수명
 * @param {array} aExceptList 엔터키 조회시 예외를 적용할 컴포넌트 명
 * @return N / A
 * @example
 *   //onload 함수에 적용하며 아래와 같이 적용한다.
 *   //검색조건 Div Enter키 조회 적용 함수
 *    var aExceptList = ["edt_execFileFuncNm","ExtYearPriodCalendar"]; //엔터키 조회 예외 컴포넌트 명 
 *    this.gfn_searchDivEvent(this.div_search,"fn_search",aExceptList);
 * @memberof global
 */
pForm.gfn_searchDivEvent = function(obj,sFunc,aExceptList)
{
   if(Util.isNull(obj)) return;
   if(Util.isNull(sFunc)) return;
   
   var aComp = obj.components;
   var oComp,sType,sUrl;

   var aAcceptCompList = ["combo","calendar","edit","maskedit","radio","checkbox"];
   
   var aAcceptExtCompList = ["extcalendar","extmonthcalendar","extyearcalendar","extyearpriodcalendar"];

   for(var i=0; i<aComp.length; i++)
   {
	   oComp = aComp[i];
	   sType = NX.Analyzer._typeof(oComp);

	   if(!Util.isNull(aExceptList) && (aExceptList.indexOf(oComp.name) > -1)) continue;
	   
       if(aAcceptCompList.indexOf(sType) > -1)
       {
    	   oComp.__callFunc = sFunc;
    	   oComp.addEventHandler("onkeyup",this._searchOnKeyupEvent,this);
       }
       
       if(aAcceptExtCompList.indexOf(sType) > -1)
       {
    	   oComp.__callFunc = sFunc;  
       }
       
       if(sType == "div")
       {
    	   sUrl = oComp.url;
    	   
    	   if(!Util.isNull(sUrl))
    	   {
    		   if(sUrl.indexOf("composite") > -1)
        	   {
        		   oComp.__callFunc = sFunc;
        	   }
    	   }
       }
   }
}

pForm._searchOnKeyupEvent = function(obj,e)
{
    if(e.keycode == 13)
    {
    	try{
    	    this[obj.__callFunc]();
    	}catch(ex) {};
    }
}

/**
 * 대용량 엑셀 다운로드 함수
 * @param  sFileNm    - 파일명
 * @param  sExcelInfo - 엑셀정보 (서버경로 및 파일명)
 * @example
 *   var sFileNm = "excelFile";
 *   var sExcelInfo = "";
 *   gfn_excelDownload(sFileNm,sExcelInfo);  
 * @memberof global
 */ 
pForm.gfn_excelDownload = function(sFileNm,sExcelInfo)
{
    if(NX.isMobile()) return; //2018.12.28 모바일인 경우에는 동작안하게 반환처리
	
	if(Util.isNull(sFileNm) || Util.isNull(sExcelInfo)) return;

	var sFileDownload = "_fdl_"+this.name;
    var oFileDownload = this.components[sFileDownload];

    var excelInfo = "?excelInfo="+sExcelInfo;
    var fileNm = "&fileNm="+encodeURI(sFileNm)+".xlsx";

    //UTF-8 Encode적용 후 EUC-KR에서 읽기 위해 % => %25로 변경
    fileNm = nexacro.replaceAll(fileNm,"%","%25");

    if(Util.isNull(oFileDownload))
    {
    	oFileDownload = new FileDownload();
    	this.addChild(sFileDownload,oFileDownload);
    	oFileDownload.show();
    }

	var sUrl = application.services[NX.DEFAULT_SVC_GRP].url+"/comm/cp/downloadCommExcel.do"+excelInfo+fileNm;

	oFileDownload.download(sUrl);
}

/**
 * 스케치 입력 호출
 * @param  sCallback    - 스케치데이터 입력받을 콜백함수명
 * @example
 *   this.fn_sketch = function()
 *   {
 *        gfn_sketchCall("fn_sketchCallback");
 *   }
 *   
 *   this.fn_sketchCallback = function(sData)
 *   { 
 *        if(!Util.isNull(sData))
 *        {
 *            this.ImageViewer00.set_image(sData);
 *        }  
 *   }
 *   
 * @memberof global
 */ 
pForm.gfn_sketchCall = function(sCallback)
{

    if(nexacro.OS == "Android" && nexacro.Browser == "Runtime")
    {
    	this.standardobj = new nexacro.Standard();
    	this.standardobj.addEventHandler("oncallback", this.on_standard_callback, this);
    	this.standardobj._callback = sCallback;
    	this.standardobj.callMethod("nativeService_canvas",{data1 :"canvas"});
    	
    }
    else
    {
		this.gfn_popup( "com_sketch"
					   ,"com::com_sketch.xfdl"
					   //,{arg1:lbsNo , arg2:lbsNm, arg3:hgrnkMstrLbsSerno}
					   ,{}
					   ,{callback:function(sId,val)
					               {
					                   this[sCallback](val);
					               }
					    }
					   );  
	}
}

pForm.on_standard_callback = function(obj,e)
{
	if(e.svcid == "nativeService_canvas")
	{
		var rtnVal = e.returnvalue;
		var sData = (Util.isNull(rtnVal)) ? "" : "data:image/*;base64,"+rtnVal;
	    
		this[obj._callback](sData);
	}
}

// Grid 오브젝트 기본 Align적용되게 반영
var pGrid = nexacro.Grid.prototype;
pGrid.on_find_CurrentStyle_align = function (pseudo) {
	return this._find_pseudo_obj("align", pseudo, "align");
};