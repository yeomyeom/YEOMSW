﻿if (!JsNamespace.exist("NX.File") )
{
	/**
	 * @namespace
	 * @name NX.File
	 * @memberof! <global>
	 * @author Gyund-Ho Yang <livedcilegna@tobesoft.co.kr>
	 */
	JsNamespace.declare("NX.File", {

    _MAX_SINGLE_SIZE : 10247680,		
	
	
	/**
	 * alphabet character code.
	 * charvalue값 => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f]
	 * @private
	 * @constant
	 * @memberOf NX.File
	 */
	_ALPHA_CHAR_CODES: [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102],
		
	_DEFAULT_FILE_CONFIG : {
		uploadUrl : "/comm/cp/saveCommAttchFile.do",
		downloadUrl : "/comm/cp/downloadCommAttchFile.do?ecmOid=",
		deleteUrl : "/comm/cp/removeCommAttchFile.do",
		
		clsnNm : "", //분류체계명
		allowTypes : ["jpg","jpeg","gif","png","bmp","txt","zip","7z","gzip","doc","docx","ppt","pptx","xls","xlsx","pdf","hwp","alz","rep"],
		maxCount : 10,
		maxSize : "1GB",
		maxTotalSize : "1GB"		
	},
	
    	
	/**
	 * 유일한 ID 를 반환
	 * @public
	 * @param {string=} prefix id 앞에 붙일 문자열
	 * @param {string=} separator id 생성시 구분용 문자(default: '-' ).
	 * @return {string} id
	 * @example
	 *
	 * trace(NX.File.getUniqueId()); 
	 * // output : 3e52d1f6-f0d2-4970-a590-ba7656b07859
	 * 
	 * trace(NX.File.getUniqueId("Button_")); 
	 * // output : Button_4e601da1-63f4-4cfa-849b-01b8a7f14d40
	 * 
	 * trace(NX.File.getUniqueId("", "_")); 
	 * // output : 4e601da1_63f4_4cfa_849b_01b8a7f14d40
	 * 
	 * trace(NX.File.getUniqueId("Button_", "_")); 
	 * // output : Button_4e601da1_63f4_4cfa_849b_01b8a7f14d40
	 * 
	 * @memberOf NX.File
	 */
	getUniqueId: function(prefix, separator)
	{
		if ( Util.isNull(prefix) ) prefix = "";
		if ( Util.isNull(separator) ) {
			separator = 45;
		} else {
			separator = separator.charCodeAt(0);
		}
		
		var pThis = NX.File,
			charcode = pThis._ALPHA_CHAR_CODES,
			math = Math;
		var seq = 0;
		var seq0;
		var tmpArray = new Array(36);
		var idx = -1;
		
		while (seq < 8) 
		{
			tmpArray[++idx] = charcode[math.random() * 16 | 0];
			seq++;
		}
		seq = 0;
		while (seq < 3) 
		{
			tmpArray[++idx] = separator;//45 => "-", 95=> "_"
			seq0 = 0;
			while (seq0 < 4) 
			{
				tmpArray[++idx] = charcode[math.random() * 16  | 0];
				seq0++;
			}
			seq++;
		}
		tmpArray[++idx] = separator; //45 => "-", 95=> "_"
		// 끝에서 12자리을 random으로 처리하면 속도가 좀더 개선됨(10만건 생성 약 0.8초 ==> chrome)
		/*
		seq = 0;
		while (seq < 12) 
		{
			tmpArray[++idx] = charcode[math.random() * 16 | 0];
			seq++;
		}
		return prefix + String.fromCharCode.apply(null, tmpArray);
		*/
		// 원래 로직은 끝에서 12자리을 현재 time 구한 8자리 와 random 4자리를 조합한 처리임.(10만건 생성 약 1.3초 ==> chrome)
		/**/
		var tmpStr = (new Date()).getTime();
		tmpStr = ("0000000" + tmpStr.toString(16)).substr(-8);
		seq = 0;
		while (seq < 8) 
		{
			tmpArray[++idx] = tmpStr.charCodeAt(seq);
			seq++;
		}
		seq = 0;
		while (seq < 4) 
		{
			tmpArray[++idx] = charcode[math.random() * 16 | 0];
			seq++;
		}
		return prefix + String.fromCharCode.apply(null, tmpArray);
		
	},	

	/**
	* 지정된 속성의 값이 처음으로 일치하는 객체의 배열 위치를 뒤에서부터 찾아 반환한다.<br>
	* 배열의 각 항목은 하나 이상의 속성을 가진 객체이다.<br> 
	* @param {array} array 대상 Array.
	* @param {string} prop 기준 속성.
	* @param {string} item 기준 값.
	* @param {number=} from 검색 시작 위치(default: 0).
	* @param {boolean=} strict true: 형변환 없이 비교('==='), false: 형변환 후 비교('==') (default: false).
	* @return {number} 검색된 배열 위치. 없다면 -1 리턴.
	* @example
	* var users = [];
	* users[0] = {id:"milk", name:"park", age:33};
	* users[1] = {id:"apple", name:"kim"};
	* users[2] = {id:"oops", name:"joo", age:44};
	* users[3] = {id:"beans", name:"lee", age:50};
	* users[4] = {id:"zoo", age:65};
	* users[5] = {id:"milk", name:"", age:33};
	* users[6] = {id:"milk", name:"lee", age:33};
	* var index = NX.File.lastIndexOfProp(users, "name", "lee");
	* trace("index==>" + index);	// output : index==>6
	* var index = NX.File.lastIndexOfProp(users, "name", "lee", 5);
	* trace("index==>" + index);	// output : index==>3
	* @memberOf NX.File
	*/
	lastIndexOfProp: function(array, prop, item, from, strict)
	{
		var i, obj, 
			propValue;
		
		if (from == null)
		{
			from = array.length - 1;
		}
		else if (from < 0)
		{
			from = Math.max(0, array.length + from);
		}
		
		var strict = strict || false;
		
		if (strict)
		{
			for (i=from; i>=0; i--)
			{
				if (i in array && array[i])
				{
					obj = array[i],
					propValue = obj[prop];
					
					if (propValue === item)
					{
						return i;
					}
				}
			}
		}
		else
		{
			for (i=from; i>=0; i--)
			{
				if (i in array && array[i])
				{
					obj = array[i],
					propValue = obj[prop];
					
					if (propValue == item)
					{
						return i;
					}
				}
			}
		}
		
		return -1;
	},
	
	/**
	 * size를 byte로 변환처리한다.
	 * @param {string} fileSize file size
	 * @return {number} file size
	 * @example
	 *  var nSizeByte = NX.File.sizeToByte("10KB"); //nSizeByte ==>10240
	 *  var nSizeByte = NX.File.sizeToByte("10MB"); //nSizeByte ==>10485760
	 *  var nSizeByte = NX.File.sizeToByte("10GB"); //nSizeByte ==>10737418240
	 * @memberOf NX.File
	 */	
	sizeToByte : function(fileSize)
	{
		
		var unit = fileSize.match(/[^\d]+/g),
			size = fileSize.match(/\d+/);

		unit = unit ? unit[0].toLowerCase() : "";
		size = size ? size[0] : fileSize;
		
		if (unit == "mb")  
		{
			return size * 1024 * 1024;
		}
		else if (unit == "gb") 
		{
			return size * 1024 * 1024 * 1024;
		}
		else if (unit == "tb") 
		{
			return size * 1024 * 1024 * 1024 * 1024;
		}
		else if (unit == "kb") 
		{
			return size * 1024;
		}
		else 
		{
			return fileSize;
		}	
	},
	
	/**
	 * byte를 size로 변환처리한다.
	 * @param {number} filesize file size
	 * @param {string} type 표시형태
	 * @return {string} file size
	 * @example
     *   var sSize1 = NX.File.bytesToSize(102400);  //100.00KB
     *   var sSize2 = NX.File.bytesToSize(102400,1); //100.00KB (102400 bytes)
     *   var sSize3 = NX.File.bytesToSize(102400,2); //100.00
	 * @memberOf NX.File
	 */
	bytesToSize : function(filesize, type)
	{
		if (Util.isNull(filesize)) return;
		
		var size = filesize  + " bytes",
			multiples = ["KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
			idx = 0, 
			approx = 0;
		
		for (idx = 0, approx = filesize / 1024; approx > 1; approx /= 1024, idx++) 
		{
			if (type == 1)
			{
				size = approx.toFixed(2) + multiples[idx] + " (" + filesize + " bytes)";
			}
			else if (type == 2)
			{
				size = approx.toFixed(2);
			}
			else
			{
				size = approx.toFixed(2) + multiples[idx];
			}
		}
	  
		return size;
	},        
		
	/**
	* 파일 추가시 validate 체크
	* @param {object} cond 체크 대상 오브젝트 
	* @param {object} fileConfig 체크 항목정의 오브젝트
	* @example
	* var cond = {"name" : fileName, "length" : fileCount, "size" : fileSize, "totalSize" : fileSize};
	* var fileConfig = NX.File._DEFAULT_FILE_CONFIG;
	* if(validateFile(cond,fileConfig)) 
	* { 
    *     trace("true");
	* }
	* else
    * {
    *     trace("false");
	* }
	* @memberOf NX.File
	*/
	validateFile : function(cond,fileConfig)
	{
		var rtn = 1;
		Util.objEach(cond, function(prop, val, object) {
			var result = "";
			if (prop == "name")
			{
				var fileExt = val.slice(val.lastIndexOf(".")+1).toLowerCase();
				//if(!Eco.array.contains(fileConfig.allowTypes, fileExt))
				if(!fileConfig.allowTypes.contains(fileExt))
				{
					alert("'" + fileExt + "' 유형의 파일은 선택할 수 없습니다. [" + val + "]");
					rtn = 0;
					return false;
				}
			}
			else if (prop == "length")
			{
				if(fileConfig.maxCount > -1)
				{
					if (val >= fileConfig.maxCount)
					{
						alert(fileConfig.maxCount + "건 이하의 파일만 선택 할 수 있습니다.");
						rtn = -1;
						return false;
					}
				}
			}
			else if (prop == "size")
			{	
				
				if (!isNaN(val) && (val == 0))
				{
					alert("파일사이즈가 0입니다. 확인해주세요.");
					rtn = 0;
					return false;
				}
				
				if (!isNaN(val) && (val >= NX.File.sizeToByte(fileConfig.maxSize)))
				{
					alert(fileConfig.maxSize + " 이상의 파일 업로드는 허용되지 않습니다.");
					rtn = 0;
					return false;
				}
			}
			else if (prop == "totalSize")
			{	
				if (!isNaN(val) && (val >= NX.File.sizeToByte(fileConfig.maxTotalSize)))
				{
					alert(fileConfig.maxTotalSize + " 이상의 파일 업로드는 허용되지 않습니다.");
					rtn = -1;
					return false;
				}
			}
		}, this);
		
		return rtn;
	},
	
	/**
	 * file명과 size를 반환한다.
	 * @param {number} rowIndex Dataset current row
	 * @return {string} file + size
	 * @memberOf NX.File
	*/
	getFileNameWithSize : function(ds, rowIndex)
	{
		
		var fileName = ds.getColumn(rowIndex, "fileNm");
		if(Util.isNull(fileName)) return "";
		
		var fileSize = ds.getColumn(rowIndex, "fileSize");
		
		if(Util.isNull(fileSize))
		{
			return fileName;
		}

		var displayFileSize = Util.bytesToSize(fileSize);
		
		return fileName + " (" + displayFileSize + ")";
	},
	
	/**
	 * 파미열을 기준으로 이미지파일인지 체크한다. 
	 * 대상이미지는  ["jpg","jpeg","gif","png","bmp"] 이다
	 * @param {string} sFileNm 파일명
	 * @return {boolean} 이미지파일이면 true, 아니면 false 반환
	 * @memberOf NX.File
	*/	
	isImageFile : function(sFileNm)
	{
		 var aImgFile = ["jpg","jpeg","gif","png","bmp"];
		 
		 var fileExt = sFileNm.slice(sFileNm.lastIndexOf(".")+1).toLowerCase();
		 
		 if(!aImgFile.contains(fileExt))
	     {
	         return false;
	     }
		 else
		 {
			 return true;
		 }
		
	},
	
	/**
	 * 파일업로드 컴포넌트에 파일필터를 적용한다.
	 * @param {obj} obj 대상 파일업로드 컴포넌트
	 * @filefilter {array,string} 적용할 파일필터 내용
	 * @return {boolean} 이미지파일이면 true, 아니면 false 반환
	 * @example
	 *  
	 *   String FileFilter Info
	 *     - 오디오 파일 : audio/*
	 *     - 비디오 파일 : video/*
	 *     - 이미지 파일 : image/*
	 *     - 텍스트 파일 : text/plain
	 *     - HTML 파일 : text/html
	 *     - Excel Files 97-2003 : application/vnd.ms-excel
	 *     - Excel Files 2007+ : application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
	 *	  
	 *   Array FileFilter Info (default)
	 *     - 사용자 지정파일 :  ["jpg","jpeg","gif","png","bmp","txt","zip","7z","gzip","doc","docx","ppt","pptx","xls","xlsx","pdf","hwp","alz","rep"] 이중에서 필요한것만 셋팅
	 *
     * String Type => NX.File.setFileFilter(obj,"image/*");
	 * Array Type => NX.File.setFileFilter(obj,["jpg","jpeg","gif","png","bmp"]);
	 *
	 * @memberOf NX.File
	*/		
	setFileFilter : function(obj,fileFilter)
	{
		if(Util.isNull(fileFilter))
		{
			obj.set_filefilter("All(*.*)|*.*|");
			
			obj.on_apply_filefilter();
			return;
		}
		
		var sFileFilter = "";
		
		if(Util.isString(fileFilter))
		{
			sFileFilter = fileFilter;
		}
		else
		{
			for(var i=0; i<fileFilter.length; i++)
			{
				sFileFilter += "."+fileFilter[i]+",";
			}			
		}
		
		obj.set_filefilter(sFileFilter);
		
		obj.on_apply_filefilter();
	}
	
	});
}
