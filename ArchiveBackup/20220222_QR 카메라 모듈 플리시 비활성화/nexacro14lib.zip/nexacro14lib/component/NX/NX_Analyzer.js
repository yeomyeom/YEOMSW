﻿
if ( !JsNamespace.exist("NX.Analyzer") )
{
	/**
	 * @namespace
	 * @name NX.Analyzer
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("NX.Analyzer", {

		/**
		 * Nexacro 컴포넌트의 type을 반환한다.
		 * @private
		 * @param  {Object} o 컴포넌트
		 * @return {String} type
		 * @example NX.Analyzer._typeof(edtName)
		 * @memberOf NX.Analyzer
		 */
		_typeof : function(obj)
		{
			if (obj === null) return "null";
			var sTypeName = typeof(obj);
			if (sTypeName == "object")
			{
				var sValue = new String(obj).valueOf();
				var sStart = sValue.indexOf("[object ");
				var sEnd   = sValue.indexOf("]", sStart);	
				if (sStart > -1 && sEnd > -1) sTypeName = sValue.substr(8, sEnd-8);
			}
			
			return sTypeName.toLowerCase();
		},

		/**
		 * 컴포넌트의 경로를 반환한다.
		 * @param  {Object} o 경로를 구할 컴포넌트
		 * @param  {Object} p 기준이 되는 폼 객체(parent)
		 * @return {String} 폼 기준의 컴포넌트 경로
		 * @example
		 *   var strPath = NX.Analyzer.path(this.edtName, this); "div01.edtName"
		 * @memberOf NX.Analyzer
		 */
		path : function(o, p)
		{
			var sPath = "";
			try
			{
				if (o && this._typeof(o) != "form")
				{
					sPath = o.name;
					for (o=o.parent; o!=p; o=o.parent)
					{
						if (this._typeof(o) != "form")
							sPath = o.name + "." + sPath;
						else 
							break;
					}
				}
			}
			catch(e)
			{
				Util.trace("NX.Analyzer.path() " + e.message + ", " + this._typeof(o));
			}

			return sPath;
		},
		
		/**
		 * 현재Form 컨테이너의 부모를 반환한다.(modal : opener, modeless : parent)
		 * @param  {Object} o 컨테이너컴포넌트(form, div)
		 * @return {Object} 컴포넌트
		 * @example NX.Analyzer.opener(this)
		 * @memberOf NX.Analyzer
		 */
		opener : function(oForm)
		{
			var pThis, oForm = oForm.getOwnerFrame().form;
			
			if (oForm.fvFormType == NX.FORM_FRAME)
			{
				pThis = NX.getForm("work").divWorkMain;
			}
			else
			{
				pThis = oForm.getOwnerFrame().form.opener || oForm.parent;
			}
			
			return pThis;
		},

		/**
		 * 주어진 Form의 path의 컴포넌트를 반환한다.
		 * @param  {String} sPath 컴포넌트경로
		 * @param  {Object} oForm FORM객체
		 * @param  {Boolean} bFindParent 부모검색여부
		 * @return {Object} 컴포넌트
		 * @example NX.Analyzer.find("edtName");
		 * @memberOf NX.Analyzer
		 */
		find : function(sPath, oForm, bFindParent)
		{
			bFindParent = bFindParent || true;
			
			var returnObj = null;
			try
			{
				var arrPath = sPath.split(".");
				while (this._typeof(oForm) != "childframe" )
				{
					var checkForm = oForm;
					for (var i=0; i<arrPath.length; i++)
					{
						var obj = null;
						if (this._typeof(checkForm) == "tab")
						{
							// tab->tabpage 객체를 바로 참조한다. (tab에는 컴포넌트가 없다.)
							for (var j=0; j<checkForm.tabpages.length; j++)
							{
								if (checkForm.tabpages[j].name == arrPath[i])
								{
									obj = checkForm.tabpages[j];
									break;
								}
							}
						}
						else
						{
							obj = checkForm.all[arrPath[i]];
						}
						
						if (obj == null) break;
						
						// 전체 이름이 일치하는 경우
						if (i == arrPath.length-1)
						{
							returnObj = obj;
							break;
						}
						
						checkForm = obj;
					}
					
					if (bFindParent && returnObj == null)
					{
						oForm = oForm.parent;
					}
					else
					{
						break;
					}
				}
			} 
			catch(e){alert("A", e.message);}
			
			return returnObj;
		},

		/**
		 * 주어진 대상을 포함한 상위 범위로 지정된 이름에 최초로 일치하는 component, object 반환
		 * @public
		 * @param {Object} p 찾을 대상
		 * @param {string} name 찾을 대상 이름
		 * @return {Object} 검색된 component, object
		 * @memberOf NX.Analyzer
		 */
		lookup : function(p, name, visible)
		{
			var o;
			while (p)
			{
				if (visible)
				{
					o = p.components;
					if ( o && o[name] ) return o[name];
				}
				else {
					o = p.objects;
					if ( o && o[name] ) return o[name];
				}
				p = p.parent;
			}
			return null;
		},
		
		/**
		 * 주어진 c(Component) 가 사용하는 Form을 반환한다.
		 * @public
		 * @param {Object} c - 컴포넌트
		 * @return {Object} script 영역이 존재하는 Form
		 * @example
		 * trace(NX.Analyzer.form(grdList));	// output : [object Form]
		 * @memberOf NX.Analyzer
		 */		
		form: function(c)
		{
			var p = c;
			while (p)
			{
				if ( (p.url && p.url.length) || (p.parent instanceof ChildFrame) )
				{
					break;
				}
				p = p.parent;
			}
			return p;
		},
		
		/**
		 * 주어진 c(Container)에서 sPath(Component)를 찾아서 반환한다.
		 * @public
		 * @param {Object} c 검색할 컨테이너컴포넌트(form)
		 * @return {String} sPath 컴포넌트의 fullpath
		 * @example
		 * trace(NX.Analyzer.comp(this, "divGrid.grdList"));	// output : object Component
		 * @memberOf NX.Analyzer
		 */	
		comp: function(c, sPath)
		{
			var aPath = Util.trim(sPath).split(".");
			var oParent = c, oComp = null;
			for (var i=0, nCnt=aPath.length; i<nCnt; i++)
			{
				oComp = oParent[aPath[i]];
				if (oComp) oParent = oComp;				
			}
			return oComp;
		}

	});
}
