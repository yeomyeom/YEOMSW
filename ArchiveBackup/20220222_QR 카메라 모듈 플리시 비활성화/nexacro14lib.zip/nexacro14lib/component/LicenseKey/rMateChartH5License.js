// -----------------------------------------------------------------------------
// rMate Chart H5 License Key 
//
// Product Name : rMate Chart for HTML5 v5.0
// License Type : Enterprise Trial License
// Product No : 420B-0174-30FF-CAEV
// Authenticated server Info : undefined 
// Expiration date : 2019/07/31
//

var rMateChartH5License = "dd3ef9b53f6ea8a049ad31076c2f380baeab056eb1e102531357d7b91b065894:3100370b3448443a4f4220504c2056563a4532412e43302d2046504656303a33432d35342d3745314e302d2d35422e3030322d34453a564c41204c312033452f4c373a30742f203943313a303232303a31453920302a343a314839";

// -----------------------------------------------------------------------------
