﻿/**
 * @fileoverview Transaction 관련
 */
if (!JsNamespace.exist("NX.Service"))
{
	/**
	 * @namespace
	 * @name NX.Service
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("NX.Service", {

		/**
		 * inner item구분자(공통코드처리)
		 * @public
		 * @type string
		 * @memberOf GridEx
		 */
		_DELIM1	: "/",	// delimit to service group
		_DELIM2	: "@",	// delimit to binddataset info

		_SEARCH_CODE_COLUMN	: "commCd",
		_RESULT_GROUP_COLUMN : "grupCd",
		_RESULT_CODE_COLUMN : "code",
		_RESULT_DATA_COLUMN : "name",
		_RESULT_USEYN_COLUMN : "useYn",

		_PAGE_CNT	: 50,
		_DS_SVC_HEADER_NM	: "_dsCmmHeader",
		_DS_OUTPUT_META_NM	: "_meta",

		_RESULT_CNT_POP_NM	: "sta_popupMsg",	// for popup message
		_RESULT_CNT_COMP_NM	: "sta_resultCnt_",	// for result count
		_PAGE_NAVI_DIV_NM	: "div_page_",
		_PAGE_INDEX_DIV_NM	: "cmbCntPerPage_",

		_PAGE_SVC_SCROLL_	: "scroll",
		_PAGE_SVC_INDEX_	: "index",
		_PAGE_SVC_NEXTKEY_	: "nextkey",

		_PAGE_OUTPUT_PREFIX : "dsPage_",
		_PAGE_START_NUMBER	: 1,

		_BIZ_EXCEPTION_CODE : 9,

		_SVC_DEFAULT_GROUP	: ["comm"],

		_SVC_TYPE_CREATE 	: "C",
		_SVC_TYPE_READ 		: "R",
		_SVC_TYPE_UPDATE 	: "U",
		_SVC_TYPE_DELETE 	: "D",
		_SVC_TYPE_SAVE 		: "S",
		_SVC_TYPE_CMMCODE 	: "Z",

		/**
		 * constructor
		 * @param {Object} o 컨테이너컴포넌트(form)
		 * @memberOf NX.Service
		 */
		constructor : function(o)
		{
			this._this 			= o;
			this._errorcode		= null;
			this._errormsg		= null;
			this._svcid			= null;
			this._controller	= null;
			this._url			= null;
			this._inds			= null;
			this._outds			= null;
			this._inds			= null;
			this._outds			= null;
  			this._user_inds		= null;	// for log
  			this._user_outds 	= null; // for log
			this._args			= null;
			this._callback		= null;
			this._msgtype		= null;
			this._waitcursor	= null;
			this._errorpopup	= null;
			this._msg			= null;
			this._msgdisplay	= null;
			this._async			= null;
			this._starttime		= null;
			this._random		= null;
			this._realsvcid		= null;
			this._realcallback 	= null;
			this._headerds		= null;

			this._cmmcodeinfo	= null;
			this._menuid		= null;
			this._formid		= null;	// * add 2018.01.11
			this._frameid		= null;	// * add 2018.01.11
			this._pagetype		= null;
			this._pageindex		= null;
			this._nextpage		= null;
			this._autopageds  	= null;

			this._datatype		= NX.dataType;
			this._compress		= NX.compress;
			this.trans 			= NX.Service.trans;

			return this;
		},

		_getPage : function(o, sProp)
		{
			return o[sProp];
		},

		_setPage : function(o, sProp, oValue)
		{
			o[sProp] = oValue;
			return o;
		},

		// TimingLog를 남기는 함수
		_writeTimingLog : function(sType, oSvc)
		{
			if (NX.getApp().gvTimingLog)
			{
				var oLogDs	= NX.getApp()._gdsSvcLog;
				if (sType == "start")
				{
					var nAddRow = oLogDs.addRow();
					if (nAddRow >= 0)
					{
						oLogDs.setColumn(nAddRow, "frameid", 	"");
						oLogDs.setColumn(nAddRow, "realsvcid", 	oSvc._realsvcid);
						oLogDs.setColumn(nAddRow, "menuid", 	oSvc._menuid);
						oLogDs.setColumn(nAddRow, "frameid", 	oSvc._frameid);
						oLogDs.setColumn(nAddRow, "svcid", 		oSvc._svcid);
						oLogDs.setColumn(nAddRow, "ctrlr", 		oSvc._controller);
						oLogDs.setColumn(nAddRow, "starttime", 	oSvc._starttime);
						oLogDs.setColumn(nAddRow, "formpath", 	NX.Analyzer.path(oSvc._this, oSvc._this.getOwnerFrame().form));

						oLogDs.setColumn(nAddRow, "inds", 		Util.trim(oSvc._user_inds));
						oLogDs.setColumn(nAddRow, "outds", 		Util.trim(oSvc._user_outds));
						oLogDs.setColumn(nAddRow, "param", 		Util.trim(oSvc._args));
					}
				}
				else
				{
					var nFindRow = oLogDs.findRow("realsvcid", oSvc._realsvcid);
					if (nFindRow >= 0)
					{
						oLogDs.setColumn(nFindRow, "endtime", Util.toDateTime("ms"));
					}
					else
					{
						Util.trace("Not Found ReadlSvcId : " + oSvc._realsvcid);
					}
				}
			}
		},

		// 공통헤더 Dataset값 설정
		_setCmmHeader : function(oSvc)
		{
			var pThis 	= oSvc._this;
			var sSvcId	= oSvc._svcid;

			// 다음조회인경우 nextpage : true인경우 > 헤더정보유지
			// Dataset명 + "_page_dataset_"로 서버에서 response받은후에 append dataset처리
			var sDsSvcId = Util.trim(sSvcId).replace(/[\.\/]/g, "");
			var oDs = DatasetEx._get("_dsCmmHeader_" + sDsSvcId, pThis, {formatds:NX.getApp()._gdsCmmHeaderFormat});
			if (oDs)
			{
				if (oSvc._nextpage === true) // for nextpage (reuse commmon header)
				{
					// pageindex컬럼값에 plus처리
					var nCurPageIndex = parseInt(oDs.getColumn(0, "pageNo"));
					oDs.setColumn(0, "pageNo", ++nCurPageIndex);
					return oDs;
				}

				oDs.set_enableevent(false);
				oDs.clearData();
				oDs.addRow();
				oDs.setColumn(0, "svcId", 	oSvc._svcid);
				oDs.setColumn(0, "menuId", 	oSvc._menuid);
				oDs.setColumn(0, "formId", 	oSvc._formid);

				if (oSvc._pagetype) // "index" or "scroll"
				{
					oDs.setColumn(0, "pageNo", 	oSvc._pageindex || 1); // Page Index
					oDs.setColumn(0, "pageSize",oSvc._pagerowcount || NX.Service._PAGE_CNT);
				}
				oDs.set_enableevent(true);

				return oDs;
			}
			else
			{
				Util.trace("NX.Service._setCmmHeader : " + sDsSvcId);
			}
		},

		_getSvcGrp : function(sCtrl)
		{
			var sSvcGrp = NX.DEFAULT_SVC_GRP;
			if (!NX.isSystem("local") && NX.isSystemId(NX.SYS_ANGS))
			{
				// sCtrl의 처음그룹을 기준으로 분기처리 : "/"로 시작하면 제거하고 split처리
				if (sCtrl.charAt(0) == NX.Service._DELIM1) sCtrl = sCtrl.substr(1);

				var aCtrlToken 	= sCtrl.split(NX.Service._DELIM1);
				var sPkgGrp 	= aCtrlToken[0];
				if (NX.Service._SVC_DEFAULT_GROUP.indexOf(sPkgGrp) < 0)
				{
					if (NX.getApp().gdsSvcUrl.findRow("svcGrp", sPkgGrp) >= 0)
					{
						sSvcGrp = NX.SVC_PREFIX + sPkgGrp;
					}
					else
					{
						Util.trace("NX.Service._getSvcGrp() :: not found service group : " + sCtrl + " / " + sPkgGrp);
					}
				}
			}

			return sSvcGrp;
		},

		_getCmmHeader : function(sDsSvcId, p)
		{
			return p.objects["_dsCmmHeader_" + sDsSvcId.replace(/[\.\/]/g, "")];
		},

		_info : function(oTr)
		{
			if (NX.getApp().gvLogLevel >= 4)
			{
				trace("===================================================================================================");
				trace("서비스ID 	: " + oTr._svcid + " [" + oTr._url + "] " + oTr._msgdisplay);
				trace("===================================================================================================");
				trace("IN  Dataset	: " + oTr._user_inds);
				trace("OUT Dataset	: " + oTr._user_outds);
				trace("Arguments 	: " + oTr._args);
				trace("콜백함수 	: " + oTr._callback);
				trace("메시지Type 	: " + oTr._msgtype);
				trace("비동기여부 	: " + oTr._async);
				trace("호출시간 	: " + oTr._starttime);
				trace("실행FORM 	: " + oTr._this.name);
				if (oTr._bindinfo) trace("바인드정보 	: " + oTr._bindinfo);
				trace("===================================================================================================");
			}
		},

		_getMsgDisplay : function(pThis, sType)
		{
			var sFormType = pThis.fvFormType;
			return sType || (sFormType == NX.FORM_POP ? "popup" : (sType || "statusbar"));
		},

		_getPageType : function(oTrCfg)
		{
			return oTrCfg.pagetype || (Util.isBoolean(oTrCfg.nextpage) ? NX.Service._PAGE_SVC_SCROLL_ : (!Util.isNull(oTrCfg.pageindex) ? NX.Service._PAGE_SVC_INDEX_ : ""));
		},

		/**
		* Service 처리(일반 Service 호출에 적용).
		* @param sServiceId	서비스ID
		* @param sCtrlr		컨트롤러
		* @param sInData 	Input DatasetList
		* @param sOutData 	Output DatasetList
		* @param sArgs 		Argument (key=value 쌍으로 구성되며 “ “로 구분됨)
		* @param sCallBackFnc - Transaction 수행 후 결과 Return Fuctnion
		* @paran oTrCfg
		* 		 --------------------------------------------------------------------------------------
		*        paging정보처리
		*        --------------------------------------------------------------------------------------
		*        pageindex		- index방식 페이지처리 (1~???)
		*        pagerowcount	- page당 조회건수 설정
		*        page(제거) 	- scroll방식 페이지서비스 여부(true/false) <------(*****)
		*        nextpage 		- scroll방식 nextpage여부(true/false)
		*        autopageds 	- scroll방식 paging서비스용 dataset자동 생성(true:default)
		*        --------------------------------------------------------------------------------------
		*        serviceid		- 화면내 unique한 서비스Id 지정시 사용(미지원)
		*        waitcursor		- 서버와통신중에는화면상에 WaitCursor 표시여부(true : 미출력, false : 출력(default)) => 사용불가
		* 		 usermsg		- 출력 메시지코드(서비스 호출후 Status메시지)
		*		 msgdisplay		- 거래Type이 "F"인경우 메시지처리방식 'popup', 'statusbar', 'none'
		* 		 errorpopup		- 에러발생시 화면에 공통에러창 팝업여부 (true : 팝업미호출, false : 팝업호출(default))

		* @return  CallBack Function에서 처리
		* @example NX.Service.trans(sServiceId, sMethod, sInData, sOutData, sArgs, sCallBackFnc, oTrCfg)
		* @memberOf NX.Service
		*/
		trans : function(sServiceId, sCtrlr, sInData, sOutData, sArgs, sCallBackFnc, oTrCfg)
		{
			var sMsgType	= oTrCfg.msgtype 	|| NX.Service._SVC_TYPE_READ;
			var sMsg		= oTrCfg.usermsg 	|| ""; // 코드로 설정해야함
			var aMsgParam	= oTrCfg.msgparam 	|| "";
			var sPageIndex	= oTrCfg.pageindex	|| "";
			var bAutoPageDs = oTrCfg.autopageds === false	|| true;
			var sMsgDisplay = NX.Service._getMsgDisplay(this._this, Util.trim(oTrCfg.msgdisplay));
			var sPageType	= NX.Service._getPageType(oTrCfg);
			var bNextPage	= oTrCfg.nextpage === true;
			var nPageRowCnt = oTrCfg.pagerowcount;
			var bWaitCursor	= oTrCfg.waitcursor === false ? oTrCfg.waitcursor : true;
			var bErrorPopup = oTrCfg.errorpopup === false ? oTrCfg.errorpopup : true;
			var sAsync		= oTrCfg.async === false ? oTrCfg.async : true;
			var sDsPageNm, oDsPage;

			try
			{
	  			this._menuid	= this._this.gfn_getFormInfo("menuid");
	  			this._formid	= this._this.gfn_getFormInfo("formid");
	  			this._frameid	= this._this.gfn_getFormInfo("frameid");

	  			switch (sPageType)
	  			{
	  				case NX.Service._PAGE_SVC_SCROLL_ 	:
	  					// TODO. check for output_dasaset count (only one)
	  					if (bAutoPageDs)
	  					{
	  						sDsPageNm   = sOutData.split("=")[0];
	  						oDsPage  	= DatasetEx._get(NX.Service._PAGE_OUTPUT_PREFIX + sDsPageNm, this._this);
	  						sOutData    = sOutData.replace(sDsPageNm, oDsPage.name);
	  					}
	  					break;
	  				case NX.Service._PAGE_SVC_INDEX_	:
	  				case NX.Service._PAGE_SVC_NEXTKEY_	:
	  					break;
	  			}

	  			this._svcid		= oTrCfg.serviceid 	|| sServiceId; // callback service_id;
	  			this._controller= sCtrlr;
//	  			this._url		= "svc::" + sCtrlr;
	  			this._url		= NX.Service._getSvcGrp(sCtrlr) + "::" + sCtrlr;

	  			this._args		= Util.trim(sArgs);
	  			this._callback	= Util.trim(sCallBackFnc) || "fn_callback";

	  			this._msgtype		= Util.trim(sMsgType);
	  			this._waitcursor 	= bWaitCursor;
	  			this._errorpopup 	= bErrorPopup;
	  			this._msg		 	= Util.getComMsg(sMsg, aMsgParam); // get message code
	  			this._msgdisplay  	= sMsgDisplay;
	  			this._async		 	= sAsync;
	  			this._user_inds		= sInData;
	  			this._user_outds 	= sOutData

	  			this._pagetype		= sPageType;
	  			this._pageindex 	= sPageIndex;
	  			this._nextpage		= bNextPage;
	  			this._pagerowcount	= nPageRowCnt;
	  			this._autopageds  	= bAutoPageDs;

	  			// create meta dataset
	  			var oDsHeader 	= NX.Service._setCmmHeader(this); // header dataset depend on serviceid
	  			var _sInData	= NX.Service._DS_SVC_HEADER_NM + "=" + oDsHeader.name + (sInData ? " " : "") + sInData;
	  			var _sOutData 	= oDsHeader.name + "=" + NX.Service._DS_SVC_HEADER_NM + (sOutData ? " " : "") + sOutData;

	  			this._inds		= _sInData;
	  			this._outds		= _sOutData;
	  			this._headerds	= oDsHeader;
	  			this._indslist	= NX.Service._getDatasetList(_sInData, "in");
	  			this._outdslist	= NX.Service._getDatasetList(_sOutData, "out");

	  			if (NX.Service._validate(this) == false) return; // except product_system

	  			NX.Service._clearDataOutDsList(this);

	  			this._starttime		= Util.toDateTime("ms");
	  			this._random		= Math.random().toString();
	  			this._realsvcid		= NX.Service._createTrSvcID(this);
	  			this._realcallback 	= oTrCfg.realcallback 	|| "_gfn_callback";
	  			this._cmmcodeinfo	= oTrCfg.cmmcodeinfo	|| "";

	   			NX.Service._setTrBeginProc(this);

	   			if (!this._async) 		this._this.setWaitCursor(true);
	  			if (!this._waitcursor)	this._this.setWaitCursor(false);

	  			this._this[this._realsvcid] = this;

	  			NX.Service._info(this);

  				NX.Service._writeTimingLog("start", this);
  				  				
  				this._this.transaction(	"tokenCheckSvc",
  						NX.svrorigin+"/angs/tokenCheck.jsp",
						"",
						"",
						"",
						"",
						false,
						2, // Default : 0 (0: XML타입, 1: 이진 타입, 2: SSV 타입)
						this._compress
						);
  				
  				var _ssoToken = NX.getApp().gvSsoToken;
  				
  				this._args += (Util.isNull(this._args)) ? "ssotoken="+_ssoToken : " ssotoken="+_ssoToken;
  				
  				Util.trace("******************************************************************");
  				Util.trace("this._realsvcid ============= " + this._realsvcid);
  				Util.trace("this._url :: " + this._url);
  				Util.trace("this._realcallback :: " + this._realcallback);
  				Util.trace("******************************************************************");
				this._this.transaction(	this._realsvcid,
										this._url,
										this._inds,
										this._outds,
										this._args,
										this._realcallback,
										this._async,
										this._datatype, // Default : 0 (0: XML타입, 1: 이진 타입, 2: SSV 타입)
										this._compress
										);
			}
			catch(e){Util.trace(e.message);}

			if (!sAsync)
			{
				var aRtn = [this._errorcode, this._errormsg];

				this._errorcode	= null;
				this._errormsg	= null;

				return aRtn;
			}
		},

		/**
		 * Common CallBack Function.
		 * @private
		 * @param  sSvcId     - Transaction을 구분하기 위한 ID
		 * @param nErrorCode  - Error Code
		 * @param sErrorMsg - Error Message
		 * @return  N/A
		 * @example  NX.Service._callback(sSvcId, nErrorCode, sErrorMsg)
		 * @memberOf NX.Service
		 */
		_callback : function(sSvcId, nErrorCode, sErrorMsg)
		{
			var oTr = this[sSvcId];
			try
			{
				if (oTr)
				{
					NX.Service._writeTimingLog("end", oTr);

					oTr._errorcode = nErrorCode;
					oTr._errormsg  = sErrorMsg;

					// for sync transaction
					if (!oTr._async) oTr._this.setWaitCursor(false);

					if (oTr._errorcode < 0)
					{
						NX.Service._errorProcess(oTr);
					}
					else
					{
						if (!NX.updatecontrol)
						{
							NX.Service._applyData(oTr); // _autoupdate가 true인 Dataset에 대한 emptystring설정(_rowtype)
						}

						NX.Service._setTrEndProc(oTr);

						if (oTr._errorcode == NX.Service._BIZ_EXCEPTION_CODE) // 9
						{
							this.gfn_msgBox("A", oTr._errormsg, {icon:"info"});
						}
					}

					var oSvcCallback = oTr._callback;
					if (Util.isFunction(oTr._callback))
					{
						oSvcCallback(oTr._svcid, nErrorCode, sErrorMsg);
					}
					else
					{
						if (oSvcCallback && Util.isValidFunc(this, oSvcCallback))
						{
							this[oSvcCallback](oTr._svcid, nErrorCode, sErrorMsg);
						}
					}
				}
				else
				{
					Util.trace("NX.Service._callback :: not found transaction object");
				}
			}
			catch(e)
			{
				Util.trace(e.message);
			}
			finally
			{
				delete this[sSvcId];
			}
		},

		// Statusbar 에 메시지를 출력한다.
		_setStatusMsg : function(sMsg, nSec)
		{
			// 첫번째 parameter로 oTr추가 : oTr의 _this속성의 formType을 체크해서 POPUP화면일 경우 하단 naming rule에 맞는 영역에 메시지 출력
			var sSysMsg	= Util.trim(sMsg).replace("\n", " ");
			var oBottomFrame = NX.getForm("bottom");
			if (oBottomFrame) oBottomFrame.setMsg(sSysMsg);
		},

		/**
		 * Service 호출 후 에러코드에 대한 처리
		 * @private
		 * @param  {Object} objTr Transaction정보를 가지고 있는 객체
		 * @return  N/A
		 * @example  _errorProcess(oTr)
		 * @memberOf NX.Service
		 */
		_errorProcess : function(oTr)
		{
			// BusinessException [oTr._errorcode == -100]
			if (oTr._errorpopup) NX.Service._popupError(oTr);
		},

		// Error Popup 호출
		_popupError : function(oTr)
		{
			var pThis 	= oTr._this;
			var oParam 	= {}, sMsgCd = oTr._errorcode;

			if (sMsgCd == "-100" || sMsgCd == "-200") // 특정코드 메시지박스형태로 제공
			{
				return pThis.gfn_msgBox("A", oTr._errormsg, {restrict:true});
			}
			else if (-1000 >= sMsgCd) // SSO관련 에러
			{
				var sExtMsg = "아래와 같은 오류가 발생하여 종료됩니다.\n\n" + oTr._errormsg;
				return pThis.gfn_msgBox("A", sExtMsg, {restrict:true, callback:"_gfn_sso_callback"});
			}
			else
			{

				var oOwnerFrame = pThis.getOwnerFrame();
				var sPopupFormID = NX.getUniqueId("com_errortrace_", pThis); // get unique_id
				var oFrame = new ChildFrame();
					oFrame.set_openalign("center middle");
					oFrame.set_formurl("com::com_errortrace.xfdl");
					oFrame.set_resizable(false);
					oFrame.set_showtitlebar(false);
					oFrame.set_showstatusbar(false);
					oFrame.set_autosize(true);
					oFrame.init(sPopupFormID, 0, 0);

				oParam.svcid		= Util.trim(oTr._svcid);
				oParam.svcurl		= Util.trim(oTr._url);
				oParam.errorcode	= Util.trim(oTr._errorcode);
				oParam.errormsg		= Util.trim(oTr._errormsg);
				oParam.statuscode	= Util.trim(oTr._statuscode);
				oParam.requesturi	= Util.trim(oTr._requesturi);
				oParam.form_url		= pThis.url; //pThis.gfn_getFormInfo("formurl"); // menu사용해서 처리고려
				oParam.form_title	= Util.trim(oTr._menuid);
				oParam.headerds		= oTr._headerds;

				return oFrame.showModal(sPopupFormID, oOwnerFrame, oParam);
			}
		},

		// 실제 통신 할 Transaction Service ID를 생성한다.
		_createTrSvcID : function(p)
		{
			return p._svcid + "|" + p._callback + "|" + p._starttime + "|" + p._random;
		},

		_getDatasetList : function(sDsList, sType)
		{
			sType = sType || "in";
			var aRtnDs 	= [], sDsNm	= "", aDsList = Util.trim(sDsList).split(" ");
			var nIndex 	= sType == "in" ? 1 : 0;
			for (var i=0, nLen=aDsList.length; i<nLen; i++)
			{
				sDsNm = aDsList[i].split("=")[nIndex];
				if (sDsNm.indexOf("_") == 0) continue;
				aRtnDs[aRtnDs.length] = sDsNm;
			}
			return aRtnDs.length > 0 ? aRtnDs : "";
		},

		_getDatasetNm : function(sDsNm)
		{
			var nColonIdx = sDsNm.indexOf(":");
			if (nColonIdx > 0) sDsNm = sDsNm.substring(0, nColonIdx);
			return sDsNm;
		},

		_applyData : function(oTr)
		{
			// input으로 전달된 Dataset에 _rowtype 컬럼이 존재할 경우 emptystring으로 설정처리
			var pThis 		= oTr._this;
			var aInDsLst	= oTr._indslist;
			var aOutDsLst	= oTr._outdslist;
			var sInDsNm, oInDs, aRowIdx = [];
			for (var i=0, nCnt=aInDsLst.length; i<nCnt; i++)
			{
			  // TODO. pageing인경우 orging output_dataset명이 필요한 경우 _getDatasetList 함수에서 처리

				sInDsNm = NX.Service._getDatasetNm(aInDsLst[i]);

				if (aOutDsLst.indexOf(sInDsNm) >= 0) continue; // output dataset에 설정된 경우 제외처리

				oInDs = pThis.objects[sInDsNm];
				if (oInDs) NX.Service._applyChange(oInDs);
			}
		},

		/**
		* Dataset 임의상태컬럼을 초기화처리
		* @private
		* @param oDs	대상Dataset
		* @return  N/A
		* @example  NX.Service._applyChange(this.dsList1);
		* @memberOf NX.Service
		*/
		_applyChange : function(oDs)
		{
			if (oDs._autoupdate) // oInDs._autoupdate -> DatasetEx.updateControl()에서 설정
			{
				if (oDs.rowcount > 0)
				{
					oDs.set_enableevent(false);
					// for delete row
					aRowIdx = DatasetEx._findRowsExpr(oDs, NX.rowtype + "=='D'");
					oDs.deleteMultiRows(aRowIdx);
					// for insert row or update row
					aRowIdx = DatasetEx._findRowsExpr(oDs, NX.rowtype + "=='C' || " + NX.rowtype + "=='U'");
					for (var j=0, nLen=aRowIdx.length; j<nLen; j++)
					{
						oDs.setColumn(aRowIdx[j], NX.rowtype, "");
					}
					oDs.applyChange();
					oDs.set_enableevent(true);
				}
			}
			else
			{
//				Util.trace("NX.Service._applyChange() skip dataset : " + oDs.name + " / " + oDs._autoupdate);
			}
		},

		// 조회 일 때 Output Dataset을 찾아서 clearData 처리(Dataset의 userproperty(_cleardata) 체크해서 처리대상 선택)
		_clearDataOutDsList : function(oSvc)
		{
			var pThis		= oSvc._this;
			var aOutDsList 	= oSvc._outdslist;
			var aInDsList 	= oSvc._indslist;
			var sTrType 	= oSvc._msgtype;
			var sPageType	= oSvc._pagetype;
			var bNextPage 	= oSvc._nextpage;
			var oCmmHeader	= oSvc._headerds;

			if (sTrType != NX.Service._SVC_TYPE_READ) return;
			if (Util.isNull(aOutDsList)) return;

			var sOutDs, oOutDs, nDsCnt = aOutDsList.length;
			if (sPageType == NX.Service._PAGE_SVC_SCROLL_ && nDsCnt == 1)
			{
				var sPageOutDs, oPageOutDs;
				for (var i=0; i<nDsCnt; i++)
				{
					// common function for grid : output dataset
					// clear dataset : output dataset(first trans), temporary dataset(next page)
					sPageOutDs = Util.trim(aOutDsList[i]);
					oPageOutDs = pThis.objects[sPageOutDs];
					sOutDs = sPageOutDs.replace(NX.Service._PAGE_OUTPUT_PREFIX, "");
					oOutDs = pThis.objects[sOutDs];
					if (bNextPage)
					{
						// clear temporary dataset
						if (oPageOutDs) oPageOutDs.clearData();
					}
					else
					{
						if (oOutDs && aInDsList.indexOf(sOutDs) < 0) oOutDs.clearData(); // skip userproperty : _cleardata()
					}

					if (oOutDs) NX.Service._setDsClearProperty(pThis, oOutDs);
				}
			}
			else
			{
				// except to transaction for paging
				for (var i=0, nOutDsCnt = aOutDsList.length; i<nOutDsCnt; i++)
				{
					sOutDs = aOutDsList[i]; //.replace(NX.Service._PAGE_OUTPUT_PREFIX, "");
					oOutDs = pThis.objects[sOutDs];
					if (oOutDs)
					{
						// not use inputdataset && _cleardata(userproperty) undefined
						if (aInDsList.indexOf(sOutDs) < 0 && !oOutDs._nocleardata) oOutDs.clearData();
						NX.Service._setDsClearProperty(pThis, oOutDs);
					}
				}
			}
		},

		_setDsClearProperty : function(pThis, oOutDs)
		{
			// check about dataset property (loadfiltermode, loadkeymode)
			if (oOutDs.bindgrid)
			{
				var bClrFilterStr = false, bClrKeyString = false, bFixedGrid = oOutDs._clearfixgrid, bNodataGrid = oOutDs._nodatagrid;
				var sCurFilterStr = DatasetEx.getFilter(oOutDs);
				var sDftFilterStr = DatasetEx.getFilter(oOutDs, false);
				if (sCurFilterStr)
				{
					bClrFilterStr = sCurFilterStr != sDftFilterStr;
					if (bClrFilterStr) DatasetEx.setFilter(oOutDs, sDftFilterStr);  // default
				}

				var sCurKeystring = DatasetEx.getKeystr(oOutDs);
				var sDftKeystring = DatasetEx.getKeystr(oOutDs, false);
				if (sCurKeystring)
				{
					bClrKeyString = sCurKeystring != sDftKeystring;
					if (bClrKeyString) DatasetEx.setKeystr(oOutDs, sDftKeystring); // default
				}

				oOutDs._rowfilterxml	= ""; // 컬럼필터링  처리시 정보저장
				oOutDs._keystrxml 		= ""; // 소트/그룹핑 처리시 정보저장
				oOutDs._cmmsfilter 		= "";

				if (bClrFilterStr || bClrKeyString || bFixedGrid || bNodataGrid) // initalize header string
				{
					var aGridList = Util.trim(oOutDs.bindgrid).split(",");
					for (var j=0, nCompCnt=aGridList.length; j<nCompCnt; j++)
					{
						var sClrGrd = aGridList[j];
						var oClrGrd = sClrGrd.indexOf(".") < 0 ? pThis.components[sClrGrd] : NX.Analyzer.comp(pThis, sClrGrd);

						if (bFixedGrid === true)
						{
							GridEx.clearFix(oClrGrd);
							oOutDs._clearfixgrid = false;
						}

						if (bNodataGrid === true)
						{
//							oClrGrd.set_nodataimage("");
//							oClrGrd.set_nodatatext("");
							oOutDs._nodatagrid = false;
						}

						if (bClrFilterStr || bClrKeyString)
						{
							if (oClrGrd && oClrGrd.visible)
							{
								if (bClrKeyString) GridEx._clearSortMark(oClrGrd);
								if (bClrFilterStr) GridEx._clearFilterMark(oClrGrd);
							}
						}
					}
				} // end if
			}
			else
			{
				// 페이징처리인 경우
			}
		},

		// 조회후 후처리 및 Output Dataset List의 결과정보(조회건수)를 반환합니다.
		_postProcForResult : function(oSvc)
		{
			var aRowCnt = [];
			var pThis 	= oSvc._this;
			var sDsList = Util.trim(oSvc._outds);

			if (Util.isNull(sDsList) == true) return;

			var sTempDs, sOutDs, oOutDs, oPageOutDs, nRowCnt;
			var oDivResultCnt, aBindGrid;
			var bScrollPage = oSvc._pagetype == NX.Service._PAGE_SVC_SCROLL_;
			var aOutDsList 	= oSvc._outdslist; // sDsList.split(" ");

			// output dataset 갯수만큼 처리
			for (var i=0, nCnt=aOutDsList.length; i<nCnt; i++)
			{
				sOutDs = aOutDsList[i];

				if (Util.isNull(sOutDs) || sOutDs.indexOf("_") == 0) continue;

				if (bScrollPage && oSvc._autopageds)
				{
					oPageOutDs = pThis.objects[sOutDs];
					sOutDs = sOutDs.replace(NX.Service._PAGE_OUTPUT_PREFIX, "");
				}

				oOutDs = pThis.objects[sOutDs];
				if (oOutDs)
				{
					nRowCnt = oOutDs.getRowCount();
					aRowCnt[aRowCnt.length] = nRowCnt;

					try
					{
						if (oOutDs.bindgrid)
						{
							var aBindGrid = oOutDs.bindgrid.split(",");
							var oGrid, sGridNm = "";
							for (var j=0, nGridCnt=aBindGrid.length; j<nGridCnt; j++)
							{
								sGridNm = aBindGrid[j];
								oGrid 	= sGridNm.indexOf(".") < 0 ? pThis.components[sGridNm] : NX.Analyzer.comp(pThis, sGridNm);

								if (GridEx.isFixedRow(oGrid)) oGrid.setFixedRow(-1);
								if (oOutDs._autoupdate) GridEx.clearCheck(oGrid);

								if (!oGrid || oGrid.visible === false) continue;

								if (nRowCnt == 0)
								{
//									oGrid.set_nodataimage("");
//									oGrid.set_nodatatext(GridEx.NODATA_TEXT); // GridEx.NODATA_TEXT
									oOutDs._nodatagrid = true;
								}

								if (oSvc._pagetype)
								{
									switch (oSvc._pagetype)
									{
										case NX.Service._PAGE_SVC_SCROLL_ :
											// scroll방식의 서비스 호출후 append처리 : 임의dataset지정해서 사용시 공통처리 불가능
											if (oSvc._autopageds)
											{
												var oDs = NX.Service._getCmmHeader(oSvc._svcid, oSvc._this);
												
												oDivResultCnt = NX.Service._getResultComp(pThis, sGridNm);
												
												var sScrollMsg = "0 / 0";
												
												if (oDivResultCnt)
												{
													if(oPageOutDs.rowcount > 0)
													{
														oOutDs.appendData(oPageOutDs, true);
														oPageOutDs.clearData();
														GridEx._adjustScroll(oGrid); // adjust vscrollbar on Grid(currow)
													
														sScrollMsg = Util.setComma(oOutDs.rowcount) + " / " + Util.setComma(oDs.getColumn(0, "totalCnt"));
														NX.Service._setResultCnt(oDivResultCnt, sScrollMsg, false);													
													}
													else
													{
														oOutDs.clearData();
														oDs.setColumn(0, "pageNo",1);
														
														if(Util.isNull(oSvc._retry))
														{
															oSvc._retry = "retry";
															oSvc._realsvcid = oSvc._realsvcid+"_retry";
															pThis[oSvc._realsvcid] = oSvc
															pThis.transaction(oSvc._realsvcid,
																					oSvc._url,
																					oSvc._inds,
																					oSvc._outds,
																					oSvc._args,
																					oSvc._realcallback,
																					oSvc._async,
																					oSvc._datatype, // Default : 0 (0: XML타입, 1: 이진 타입, 2: SSV 타입)
																					oSvc._compress
																					);		
															return;																				
														}
														else
														{
															NX.Service._setResultCnt(oDivResultCnt, sScrollMsg, false);
														}
											
													}
												}
												else
												{
													Util.trace("NX.Service.js :: _postProcForResult() => Static component not found " + (NX.Service._RESULT_CNT_COMP_NM + sGridNm));
												}

											}
											break;

										case NX.Service._PAGE_SVC_INDEX_ :
											oPageDiv = NX.Service._getPageComp(pThis, sGridNm);
											if (oPageDiv)
											{
												oPageDiv.set_visible(true);
												var oDs = NX.Service._getCmmHeader(oSvc._svcid, oSvc._this);
												var nPage = parseInt(oDs.getColumn(0, "pageNo")); // oSvc._pageindex
												var nCurPage = oPageDiv.getPage();
												var nTotlcnt = oDs.getColumn(0, "totalCnt");
												
												if(nTotlcnt > 0)
												{
												    if (oDs && (nPage == NX.Service._PAGE_START_NUMBER || nPage != nCurPage)) oPageDiv.setPage(oDs.getColumn(0, "totalCnt"), nPage);	
												}
												else
												{
												   oDs.setColumn(0, "pageNo",1);

												   if(Util.isNull(oSvc._retry))
												   {
													   oSvc._retry = "retry";
													   oSvc._realsvcid = oSvc._realsvcid+"_retry";
													   pThis[oSvc._realsvcid] = oSvc
													   //oPageDiv.setPage(oDs.getColumn(0, "totalCnt"), 1);	
													   pThis.transaction(oSvc._realsvcid,
																				oSvc._url,
																				oSvc._inds,
																				oSvc._outds,
																				oSvc._args,
																				oSvc._realcallback,
																				oSvc._async,
																				oSvc._datatype, // Default : 0 (0: XML타입, 1: 이진 타입, 2: SSV 타입)
																				oSvc._compress
																				);		
                                                       return;																				
												   }
												   else
												   {
													   oPageDiv.setPage(oDs.getColumn(0, "totalCnt"), 1);
												   }
												   
												
												}
												
												//if (oDs && nPage == NX.Service._PAGE_START_NUMBER) oPageDiv.setPage(oDs.getColumn(0, "totalCnt"), NX.Service._PAGE_START_NUMBER);
											}
											else
											{
												Util.trace("NX.Service.js :: _postProcForResult() => Index page division not found " + (NX.Service._PAGE_INDEX_DIV_NM + sGridNm));
											}
											break;
									}

								}
								else
								{
									// normal retrieve service
									oDivResultCnt = NX.Service._getResultComp(pThis, sGridNm);
									if (oDivResultCnt)
									{
										NX.Service._setResultCnt(oDivResultCnt, nRowCnt);
									}
								}
								
								
								// output dataset과 binding된 grid의 selecttype이 multirow인경우 selectRow처리
								// multirow경우만 bindgrid 설정됨 (bindgrid속성 사용해야할 경우 lib_com.xjs에서 추가속성등록)
								if (oOutDs._multirowgrid)
								{
									if (oOutDs.rowposition == 0) oGrid.selectRow(0);
								}								
																
							}
						}
						else
						{
							// Dataset의 bindgrid속성이 미지정된 경우의 처리(Tr마다 수행되어 주석)
//							if (oSvc._pagetype == NX.Service._PAGE_SVC_NEXTKEY_ && oOutDs.appendgrid) //mapping정보 체크 : NextKey방식의 페이징인경우 조회건수 설정
//							{
//								oDivResultCnt = NX.Service._getResultComp(pThis, oOutDs.appendgrid.name);
//								if (oDivResultCnt)
//								{
//									NX.Service._setResultCnt(oDivResultCnt, pThis.gfn_getTotalCount(oSvc._svcid));
//								}
//							}
						}
					}
					catch(e)
					{
						Util.trace("NX_Service.js :: _postProcForResult() => " + e.message);
					}

				}
			}

			return aRowCnt;
		},

		// 페이지 네비게이션을 설정하는 컴포넌트 반환함수
		_getPageComp : function(pThis, sCompNm)
		{
			var oComp, nLstDotIdx = sCompNm.lastIndexOf(".");
			if (nLstDotIdx > 0)
			{
				var sConvCompNm = sCompNm.substring(0, nLstDotIdx+1) + NX.Service._PAGE_NAVI_DIV_NM + sCompNm.substr(nLstDotIdx+1);
				oComp = NX.Analyzer.comp(pThis, sConvCompNm);
			}
			else
			{
				oComp = pThis.components[NX.Service._PAGE_NAVI_DIV_NM + sCompNm];
			}
			return oComp;
		},

		// 조회건수 표기하는 컴포넌트 반환함수
		_getResultComp : function(pThis, sCompNm)
		{
			var oComp, nLstDotIdx = sCompNm.lastIndexOf(".");
			if (nLstDotIdx > 0)
			{
				var sResultCompNm = sCompNm.substring(0, nLstDotIdx+1) + NX.Service._RESULT_CNT_COMP_NM + sCompNm.substr(nLstDotIdx+1);
				oComp = NX.Analyzer.comp(pThis, sResultCompNm);
			}
			else
			{
				oComp = pThis.components[NX.Service._RESULT_CNT_COMP_NM + sCompNm];
			}
			return oComp;
		},

		_setResultCnt : function(o, nCnt, bConvMsg)
		{
			if (o.usedecorate !== true) o.set_usedecorate(true);
			o.set_text("총<fc v='#fc6100'><b v='true'> " + (bConvMsg === false ? nCnt : Util.setComma(nCnt)) + "</b></fc>건");
		},

		// Transaction 전 메시지 처리
		_setTrBeginProc : function(oSvc)
		{

			var oTopForm = oSvc._this.getOwnerFrame().form;

			switch (oTopForm.fvFormType)
			{
				case NX.FORM_FRAME :
					return;
					break;

				case NX.FORM_POP :
					var oStatusBar = oTopForm.components[NX.Service._RESULT_CNT_POP_NM];
					if(oSvc._msgdisplay != "none")
					{
						if (oStatusBar)
						{
							oStatusBar.set_text(oSvc._msg || NX.Service._getStatusMsg(oSvc._msgtype, true));
						}
					}
					break;

				default :
					if (NX.isStatusbar() && oSvc._msgdisplay != "none")
					{
						if (!Util.isNull(oSvc._msg))
						{
							NX.Service._setStatusMsg(oSvc._msg);
						}
						else {
							var sSvcMsg = NX.Service._getStatusMsg(oSvc._msgtype, true);
							NX.Service._setStatusMsg(sSvcMsg, -1);
						}
					}
					break;
			}
		},

		// Transaction 완료 후 메시지 처리
		_setTrEndProc : function(oSvc)
		{
			var oTopForm = oSvc._this.getOwnerFrame().form;
			switch (oTopForm.fvFormType)
			{
				case NX.FORM_FRAME :
					return;
					break;

				case NX.FORM_POP :
					var aResultRowCnt = NX.Service._postProcForResult(oSvc); // post process about transaction

					if(oSvc._msgdisplay != "none")
					{
						var oStatusBar = oTopForm.components[NX.Service._RESULT_CNT_POP_NM];
						if (oStatusBar)
						{
							oStatusBar.set_text(oSvc._msg || oSvc._errormsg);
						}
						else
						{
							NX.Service._setStatusMsg(oSvc._msg || oSvc._errormsg);
						}
					}
					break;

				default :
					var aResultRowCnt = NX.Service._postProcForResult(oSvc); // post process about transaction
					if (NX.isStatusbar() && oSvc._msgdisplay != "none")
					{
						if (!Util.isNull(oSvc._msg))
						{
							NX.Service._setStatusMsg(oSvc._msg);
						}
						else
						{
							switch(oSvc._msgtype)
							{
								case NX.Service._SVC_TYPE_READ :
	//								NX.Service._setRetrieveEndMsg(oSvc, aResultRowCnt);	break; // <- inner call NX.Service._setStatusMsg
								case NX.Service._SVC_TYPE_CREATE :
								case NX.Service._SVC_TYPE_UPDATE :
								case NX.Service._SVC_TYPE_DELETE :
								case NX.Service._SVC_TYPE_SAVE :
									NX.Service._setStatusMsg(oSvc._errormsg);
									break;

	//							case NX.Service._SVC_TYPE_CMMCODE : // 2018.01.10 공통팀요청 메시지 제거
	//								var sSvcMsg = NX.Service._getStatusMsg(oSvc._msgtype);
	//								NX.Service._setStatusMsg(sSvcMsg);
	//								break;

	//							case "F" : // 서비스에서 응답된 메시지 사용하는 경우
	//		 						var sSvcMsg = Util.decodeJson(oSvc._errormsg).RSP_DTL_IZ;
	//		 						if (oSvc._msgdisplay == "popup")
	//		 						{
	//		 							oSvc._this.gfn_msgBox("M", sSvcMsg, {callback:"fn_msgBoxCallback_" + oSvc._svcid});
	//		 						}
	//		 						else
	//		 						{
	//		 							NX.Service._setStatusMsg(sSvcMsg);
	//		 						}
	//								break;
							}
						}
					}
					break;
			}
		},

		_getStatusMsg : function(sType, bStart)
		{
			var sStatusMsg = "";
			if (bStart)
			{
				switch (sType)
				{
					case NX.Service._SVC_TYPE_CREATE  :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0017", "등록");				break; 	// 등록중입니다
					case NX.Service._SVC_TYPE_READ :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0017", "조회");				break;	// 조회중입니다
					case NX.Service._SVC_TYPE_UPDATE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0017", "수정");				break;	// 수정중입니다
					case NX.Service._SVC_TYPE_DELETE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0017", "삭제");				break;	// 삭제중입니다
					case NX.Service._SVC_TYPE_SAVE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0017", "저장");				break;	// 저장중입니다
//					case NX.Service._SVC_TYPE_CMMCODE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0017", "공통코드 조회");	break;	// 공통코드 조회중입니다
				}
			}
			else
			{
				switch (sType)
				{
					case NX.Service._SVC_TYPE_CREATE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0009", "자료 등록");		break;	// 자료 등록을 완료하였습니다
					case NX.Service._SVC_TYPE_UPDATE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0009", "자료 수정");		break;	// 자료 수정을 완료하였습니다
					case NX.Service._SVC_TYPE_DELETE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0009", "자료 삭제");		break;	// 자료 삭제를 완료하였습니다
					case NX.Service._SVC_TYPE_SAVE  :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0009", "자료 저장");		break;	// 자료 저장를 완료하였습니다
//					case NX.Service._SVC_TYPE_CMMCODE :	sStatusMsg = Util.getComMsg("I.ZZ.ZZ.0009", "공통코드 조회");	break;	// 공통코드 조회를 완료하였습니다
				}
			}

			return sStatusMsg;
		},

		// 조회 완료 후 메시지 처리
		/* 2018.10.22 사용안함으로 인한 주석처리
		_setRetrieveEndMsg : function(oSvc, aRowCount)
		{
			var sOutds = oSvc._outds;
			if (Util.isNull(sOutds)) return;

			var sSvcMsg	= "";
			if (aRowCount)
			{
				if (aRowCount.length == 1)
				{
					// 메시지처리 : {0} 건 조회되었습니다 or 조회된 결과값이 없습니다.
					sSvcMsg = aRowCount[0] > 0 ? NX._getUiMsg("UI027", aRowCount[0]) : GridEx.NODATA_TEXT;
				}
				else if (aRowCount.length > 1)
				{
					var nTotCnt	= 0;
					var sRowCnt	= "";
					for (var i=0, nCnt=aRowCount.length; i<nCnt; i++)
					{
						var nRowCnt	= parseInt(aRowCount[i]);
						nTotCnt	+= nRowCnt;
						sRowCnt += (Util.isNull(sRowCnt)==true) ? nRowCnt : (", " + nRowCnt);
					}

					sSvcMsg = nTotCnt > 0 ? NX._getUiMsg("UI027", sRowCnt) : GridEx.NODATA_TEXT;
				}
			}

			NX.Service._setStatusMsg(sSvcMsg); // 하단 메시지 출력
		},
*/
		// Transaction Argument Validate
		_validate : function(oTr)
		{
			if (NX.isSystem(NX.SYS_PROD)) return true;	// 운영에서는 제외처리

			if (Util.isNull(oTr._svcid))
			{
				Util.trace("Transaction Service ID를 입력하세요.");
				return false;
			}

			// Dataset List를 배열형태로 반환하는 함수추가 고려
			if (Util.isNull(oTr._outds) == false)
			{
				var aOutDsList = oTr._outds.split(" ");
				for (var i=0, nCnt=aOutDsList.length; i<nCnt; i++)
				{
					var sTempDs	= Util.trim(aOutDsList[i]);
					if (Util.isNull(sTempDs) == true) continue;

					var aOutDs = sTempDs.split("=");
					if (aOutDs.length == 2)
					{
						var sOutDs = Util.trim(aOutDs[0]);
						if (oTr._this.isValidObject(sOutDs) == false)
						{
							if (sOutDs.toLowerCase().substr(0, 3) != "gds")
							{
								Util.trace(sOutDs + "는 존재하지 않는 Output Dataset 입니다.");
								return false;
							}
						}
					}
				}
			}

			if (Util.isNull(oTr._inds) == false)
			{
				var aInDsList = oTr._inds.split(" ");
				for (var i=0, nCnt=aInDsList.length; i<nCnt; i++)
				{
					var sTempDs	= Util.trim(aInDsList[i]);
					if (Util.isNull(sTempDs) == true) continue;

					var aInDs = sTempDs.split("=");
					if (aInDs.length == 2)
					{
						var aInDsTemp = Util.trim(aInDs[1]).split(":");
						var sInDs = Util.trim(aInDsTemp[0]);
						if (oTr._this.isValidObject(sInDs) == false)
						{
							if (sInDs.toLowerCase().substr(0, 3) != "gds")
							{
								Util.trace(sInDs + "는 존재하지 않는 Input Dataset 입니다.");
								return false;
							}
						}
					}
				}
			}

			return true;
		},

		// callback of commoncode service
		_cmmCodeCallback : function(sSvcId, nErrorCode, sErrorMsg)
		{
			var pThis = this;
			var oTr = pThis[sSvcId];
			try
			{
				if (oTr)
				{
					NX.Service._writeTimingLog("end", oTr);

					oTr._errorcode = nErrorCode;
					oTr._errormsg  = sErrorMsg;

					if (oTr._errorcode < 0)
					{
						NX.Service._errorProcess(oTr);
					}
					else
					{
						NX.Service._setTrEndProc(oTr);

						if (oTr._errorcode == NX.Service._BIZ_EXCEPTION_CODE) // 9
						{
							pThis.gfn_msgBox("A", oTr._errormsg, {icon:"info"});
						}

						var oResultDs = pThis["_dsCmmCodeRsltLst_"]; // distribute for codelist (separator : '@', '^')
						if (oResultDs)
						{
							var oOutDs, oInquiry, oType, sType, sAddValue, sFilterStr, sBindInfo, aInquiry = oTr._cmmcodeinfo;
							var _sRESULT_DATA_COLUMN, _sRESULT_CODE_COLUMN = NX.Service._RESULT_CODE_COLUMN;

							for (var i=0, nLength=aInquiry.length; i<nLength; i++)
							{
								sType = "";

								oInquiry = aInquiry[i];
								if (Util.isNull(oInquiry.dataset)) continue;

								_sRESULT_DATA_COLUMN = oInquiry.datacolumn || NX.Service._RESULT_DATA_COLUMN;

								sFilterStr = NX.Service._RESULT_GROUP_COLUMN + "=='" + oInquiry.code + "'" + (oInquiry.filterstr ? " && (" + oInquiry.filterstr + ")" : "");

								oResultDs.filter(sFilterStr);
								oOutDs = DatasetEx._get(oInquiry.dataset, pThis);

								if (oOutDs.colcount < 1) oOutDs.copyData(NX.getApp()._gdsCmmCodeResultFormat);

								oOutDs.copyData(oResultDs, true);

								if(!Util.isNull(oInquiry.sort))
								{
								    var sSort = "";
								    
								    oOutSortDs = DatasetEx._get(oInquiry.dataset+"_sort", pThis);
								    
								    oOutSortDs.assign(oOutDs);
								    
									switch(oInquiry.sort)
									{
									    case "code+" : sSort = "S:+"+_sRESULT_CODE_COLUMN; break;
									    case "code-" : sSort = "S:-"+_sRESULT_CODE_COLUMN; break;
									    case "name+" : sSort = "S:+"+_sRESULT_DATA_COLUMN; break;
									    case "name-" : sSort = "S:-"+_sRESULT_DATA_COLUMN; break;
									}
									
									
									oOutSortDs.set_keystring(sSort);
									
									oOutDs.copyData(oOutSortDs, true);
									
									pThis.removeChild(oInquiry.dataset+"_sort");
									DatasetEx._destroy(oOutSortDs);
									
								}
								// format 지정한 경우
								if (oInquiry.format == "all")
								{
									var sCmmCode, sCmmCodeNm;
									for (var j=0, nRowCnt=oOutDs.rowcount; j<nRowCnt; j++)
									{
										sCmmCode 	= oOutDs.getColumn(j, _sRESULT_CODE_COLUMN);
										sCmmCodeNm 	= oOutDs.getColumn(j, _sRESULT_DATA_COLUMN);
										oOutDs.setColumn(j, _sRESULT_DATA_COLUMN, Util.format("[{0}] {1}", [sCmmCode, sCmmCodeNm]));
									}
								}
								else if (oInquiry.format == "code")
								{
									var sCmmCode, sCmmCodeNm;
									for (var j=0, nRowCnt=oOutDs.rowcount; j<nRowCnt; j++)
									{
										sCmmCode 	= oOutDs.getColumn(j, _sRESULT_CODE_COLUMN);
										oOutDs.setColumn(j, _sRESULT_DATA_COLUMN, sCmmCode);
									}
								}

								// addrow 지정한 경우(행추가)
								oType = oInquiry.addrow;

								if (oType)
								{
									sType = oType, sAddValue = "";

									if (Array.isArray(oType))
									{
										sType = oType[0];
										sAddValue = Util.trim(oType[1]);
									}

									switch (sType)
									{
										case "all" 		:
											oOutDs.insertRow(0);
											oOutDs.setColumn(0, _sRESULT_CODE_COLUMN, sAddValue);
											oOutDs.setColumn(0, _sRESULT_DATA_COLUMN, NX.Comps.ADDROW_TEXT_ALL);
											break;
										case "select" 	:
											oOutDs.insertRow(0);
											oOutDs.setColumn(0, _sRESULT_CODE_COLUMN, sAddValue);
											oOutDs.setColumn(0, _sRESULT_DATA_COLUMN, NX.Comps.ADDROW_TEXT_SELECT);
											break;
										case "direct" 	:
											oOutDs.insertRow(0);
											oOutDs.setColumn(0, _sRESULT_CODE_COLUMN, sAddValue);
											oOutDs.setColumn(0, _sRESULT_DATA_COLUMN, NX.Comps.ADDROW_TEXT_DIRECT);
											break;
										default :
											oOutDs.insertRow(0);
											oOutDs.setColumn(0, _sRESULT_CODE_COLUMN, sAddValue);
											oOutDs.setColumn(0, _sRESULT_DATA_COLUMN, sType);
											break;
									}
								}
								else
								{
									sType = "";
									sAddValue = "";
								}

								// 바인딩항목(combo) 지정한 경우 : exist bindinfomation about component (grid, combo 일괄처리 확인필요)
								sBindInfo = Util.trim(oInquiry.combo); // || oInquiry.grid;
								if (sBindInfo)
								{
									var oComp = pThis.components[sBindInfo] || NX.Analyzer.find(sBindInfo, pThis); // Combo binding (sBindInfo에 dot notation이 있는 경우)
									if (oComp && (oComp instanceof Combo))
									{
										oComp._cmmcodeinfo = oInquiry;
										oComp.set_innerdataset(oOutDs.name);
										oComp.set_codecolumn(_sRESULT_CODE_COLUMN);
										oComp.set_datacolumn(_sRESULT_DATA_COLUMN);
										if (oInquiry.index > -1)
										{								
											oComp.set_index(oInquiry.index);
										}
										else
										{
											if (sType || oComp.readonly)
											{
												oComp.set_index(-1);
												oComp.set_index(0);
											}
										}
									}
									else
									{
										Util.trace("NX.Service._cmmCodeCallback() => not defined [Combo] object : " + sBindInfo);
									}
								}

								// 바인딩항목(radio) 지정한 경우
								sBindInfo = Util.trim(oInquiry.radio);
								if (sBindInfo)
								{
									var oComp = pThis.components[sBindInfo] || NX.Analyzer.find(sBindInfo, pThis); // Combo binding (sBindInfo에 dot notation이 있는 경우)
									if (oComp && (oComp instanceof Radio))
									{
										oComp.set_innerdataset(oOutDs.name);
										oComp.set_codecolumn(_sRESULT_CODE_COLUMN);
										oComp.set_datacolumn(_sRESULT_DATA_COLUMN);
										if (oInquiry.index) oComp.set_index(oInquiry.index);
									}
									else
									{
										Util.trace("NX.Service._cmmCodeCallback() => not defined [Radio] object : " + sBindInfo);
									}
								}

								// 바인딩항목(grid) 지정한 경우
								sBindInfo = Util.trim(oInquiry.grid);
								if (sBindInfo)
								{
									var aGridBind = sBindInfo.split(NX.Service._DELIM2); 	// inner item delimiter
									var oComp = pThis.components[aGridBind[0]] || NX.Analyzer.find(aGridBind[0], pThis);	// Grid Component
									var sColumnId = Util.trim(aGridBind[1]);	// Column
									if (sColumnId && (oComp instanceof Grid))
									{
										// setting binding info about binding cell
										var nCell = oComp.getBindCellIndex("body", sColumnId)
										if (nCell >= 0)
										{
											if (Util.trim(oComp.getCellProperty("body", nCell, "displaytype")).indexOf("combo") >= 0)
											{
												oComp.setCellProperty("body", nCell, "combocodecol", _sRESULT_CODE_COLUMN);
												oComp.setCellProperty("body", nCell, "combodatacol", _sRESULT_DATA_COLUMN);
												oComp.setCellProperty("body", nCell, "combodataset", oOutDs.name);
												if (sType)
												{
													oComp.setCellProperty("body", nCell, "combodisplaynulltext", (sType=="all" ? NX.Comps.ADDROW_TEXT_ALL : NX.Comps.ADDROW_TEXT_SELECT));
												}
											}
										}
										else
										{
											Util.trace("NX.Service._cmmCodeCallback() => Grid column id[" + sColumnId + "] not found : " + nCell);
										}
									}
									else
									{
										Util.trace("NX.Service._cmmCodeCallback() => Grid bind column " + sColumnId + ", Grid Info : " + oComp);
									}
								}
							}

							oResultDs.filter("");
						}
					}

					var oSvcCallback = oTr._callback;
					if (Util.isFunction(oTr._callback))
					{
						oSvcCallback.call(pThis, oTr._svcid, nErrorCode, sErrorMsg);
					}
					else
					{
						if (oSvcCallback && Util.isValidFunc(pThis, oSvcCallback))
						{
							pThis[oSvcCallback].call(pThis, oTr._svcid, nErrorCode, sErrorMsg);
						}

					}
				}
				else
				{
					Util.trace("NX.Service._cmmCodeCallback() : not found transaction information");
				}
			}
			catch(e)
			{
				Util.trace("NX.Service._cmmCodeCallback() : " + e.message);
			}
			finally
			{
				delete pThis[sSvcId];
			}
		}

	});
}
