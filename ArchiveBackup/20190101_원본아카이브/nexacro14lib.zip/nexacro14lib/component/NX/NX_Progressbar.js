﻿if ( !JsNamespace.exist("NX.Progressbar") )
{
	/**
	 * @namespace
	 * @name NX.Progressbar
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("NX.Progressbar", {
	
		/**
		 * 프로그래스바 객체명의 접두어
		 * @public
		 * @type string
		 * @memberof NX.Progressbar
		 */	
		_PROGRESSBAR_NM_PREFIX : "_nxProgressbar_",
		
	  /**
		* 공통 Progressbar 함수 (개발자 사용금지)
		* @param {Object} pThis 컨테이너
		* @param {Object} oCfg 설정객체(속성 : title, max, toppos, async)
		* @example NX.Progressbar._showProgressBar(this, {title:"엑셀출력"});
		* @memberof NX.Progressbar
		*/
		_showProgressBar : function(_this, oCfg)
		{
			if (!oCfg) oCfg = {};

			var oDiv, oContainer = _this.gfn_isFormType(NX.FORM_POP) ? _this.getOwnerFrame().form : _this.gfn_getFrame("main");
			var sDivNm 	= NX.getUniqueId(this._PROGRESSBAR_NM_PREFIX, oContainer);
			var nTopPos = oCfg.toppos;
			var sTitle  = oCfg.title;
			var nMax	= oCfg.max || 100;

			if (oContainer.isValidObject(sDivNm))
			{
				oDiv = oContainer.components[sDivNm];
			}
			else
			{
				oDiv = new Div(sDivNm, "absolute", 0, 0, NX.FRAME_WIDTH, NX.FRAME_HEIGHT);
				oContainer.addChild(sDivNm, oDiv);
				oDiv.set_async(false);
				oDiv.set_visible(false);
				oDiv.set_url("com::com_progressbar.xfdl");
				oDiv.style.set_background("#00000099");
				oDiv.show();
			}
			
			oDiv.fnSetResizeProc({cx:oContainer.getOffsetWidth(), cy:oContainer.getOffsetHeight()});
			oDiv.fnSetComps({message:sTitle, max:nMax});
			oDiv.set_visible(true);
		},
		
		/** 배치프로그래스바 초기화 처리
		 * @return n/a
		 * @example init()
		 * @memberof NX.Progressbar
		 */
		init : function(o)
		{
			var oPbar = this.getContainer(o);
			if (oPbar) oPbar.set_visible(false);
		},
		
		/** 배치프로그래스바 반환
		 * @return {Object} Container객체(form)
		 * @example getContainer()
		 * @memberof NX.Progressbar
		 */
		getContainer : function(o)
		{
			var oForm 	= o.gfn_isFormType(NX.FORM_POP) ? o.getOwnerFrame().form : o.gfn_getFrame("main");
			var sDivNm 	= NX.getUniqueId(this._PROGRESSBAR_NM_PREFIX, oForm);
			return oForm.components[sDivNm];
		}
		
	});
}
