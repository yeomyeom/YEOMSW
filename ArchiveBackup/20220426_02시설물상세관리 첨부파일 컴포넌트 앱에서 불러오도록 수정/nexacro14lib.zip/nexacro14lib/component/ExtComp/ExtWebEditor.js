if (!nexacro.ExtWebEditor)
{
	/***********************************************************************************
	* SYSTEM		: 공통(CM)
	* PROGRAM ID	: ExtWebEditor
	* PROGRAM NAME	: 웹에디터
	* DESCRIPTION	: 웹에디터
	* DATE			: 2018.04.05
	* PROGRAMMER	: 양경호
	*----------------------------------------------------------------------------------
	* MODIFY DATE   	PROGRAMMER		DESCRIPTION
	*----------------------------------------------------------------------------------
	* 2018.04.05		양경호			최초 작성
	***********************************************************************************/

    nexacro.ExtWebEditor = function(id, position, left, top, width, height, right, bottom, parent)
    {
        nexacro.Div.call(this, id, position, left, top, width, height, right, bottom, parent);

        this.isEditorLoad = false;
        this.isViewerLoad = false;
        this.editorObject;
        this.editorData;
        this._enableedAct = true;
        this.viewmode = false;
        this.nCompletedimer = 13532;
        this.nCompLoadTimer = 13533;
        this.nEnbaleTimer = 13534;
        this.style.set_border("1 solid #a1a1a1ff ");
    };

    var _pExtWebEditor = nexacro._createPrototype(nexacro.Div);
    nexacro.ExtWebEditor.prototype = _pExtWebEditor;
    _pExtWebEditor._type = "ExtWebEditor";
    _pExtWebEditor._type_name = "ExtWebEditor";

    _pExtWebEditor.on_created_contents = function ()
    {
    	this.addEventHandler("ontimer",this.webeditor_ontimer,this);
    	var oWebEditor = new WebBrowser("web_editor", "absolute", 0, 0, null, null, 0, 0);
    	oWebEditor.set_visible(true);
    	this.addChild("web_editor", oWebEditor);
    	oWebEditor.show();

    	var oWebViewer = new WebBrowser("web_viewer", "absolute", 0, 0, null, null, 0, 0);
    	oWebViewer.set_visible(false);
    	this.addChild("web_viewer", oWebViewer);
    	oWebViewer.show();

        var sHost = application.services[NX.DEFAULT_SVC_GRP].url;
        var sEditorUrl = sHost+"/webeditor/webEditor.html";
        var sViewerUrl = sHost+"/webeditor/webViewer.html";

    	oWebEditor.addEventHandler("onloadcompleted",this.web_editor_onloadcompleted,this);
    	oWebViewer.addEventHandler("onloadcompleted",this.web_view_onloadcompleted,this);

    	oWebEditor.set_url(sEditorUrl);
    	oWebViewer.set_url(sViewerUrl);


    }


    _pExtWebEditor.web_editor_onloadcompleted = function (obj,e)
    {
    	this.isEditorLoad = true;
    	var oEditorDocument = obj.getProperty("document");
    	var oEditorForm = oEditorDocument.getProperty("editorForm");
    	this.editorObject = oEditorForm.getProperty("editorData");

    	this.web_editor.callMethod("setHeight",(this.getOffsetHeight()));
    }

    _pExtWebEditor.web_view_onloadcompleted = function(obj,e)
    {
    	this.isViewerLoad = true;
    }

    //에디터에 데이터를 넣는다.
    _pExtWebEditor.setData = function(sData)
    {
        var isLoad = (this.viewmode) ? this.isViewerLoad : this.isEditorLoad;
    	var targetWeb = (this.viewmode) ?  this.web_viewer : this.web_editor;

        if(isLoad)
        {
            this.editorData = sData;
            targetWeb.callMethod("setData",sData);
        }
        else
        {
            this.editorData = sData;
            this.setTimer(this.nCompletedimer,100);
        }
    }

    //에디터에 있는 데이터를 가져온다. 뷰모드일경우에는 반환안함
    _pExtWebEditor.getData = function()
    {
        if(this.viewMod) return;

        if(this.isEditorLoad)
        {
             this.web_editor.callMethod("getData");
             var sData = this.editorObject.getProperty("value");
             return sData;
        }
    }

    //에디터 포커스 주기
    _pExtWebEditor.setFocusEx = function()
    {
        var isLoad =  this.isEditorLoad;


        if(isLoad)
        {
        	if(!this.viewmode) this.web_editor.callMethod("setFocus");
        }
        else
        {
            this.setTimer(this.nEnbaleTimer,100);
        }
    }

    //에디터를 활성화 비활성화 적용 *뷰모드시에는 미적용
    _pExtWebEditor.set_editable = function(bAct)
    {
        var isLoad =  this.isEditorLoad;

    	if(typeof(bAct) == "string")
    	{
    		bAct = (bAct=="false") ? false : true;
    	}

        if(isLoad)
        {
        	if(!this.viewmode) this.web_editor.callMethod("setEditable",bAct);
        }
        else
        {
        	this._enableedAct = bAct;
            this.setTimer(this.nEnbaleTimer,100);
        }
    }

    //뷰모드 설정
    _pExtWebEditor.set_viewmode = function(bAct)
    {
    	if(typeof(bAct) == "string")
    	{
    		bAct = (bAct=="false") ? false : true;
    	}

        this.viewmode = bAct;

        if(Util.isNull(this.web_editor) || Util.isNull(this.web_viewer))
        {
        	if(!this.viewmode) return;

        	this.setTimer(this.nCompLoadTimer,100);
        	return;
        }

        if(this.viewmode)
        {
            //에디터에 넣은 데이터가 있는 경우에는 데이터설정
            if(!Util.isNull(this.editorData))
            {
                this.setData(this.editorData);
            }

            this.web_editor.set_visible(false);
            this.web_viewer.set_visible(true);
        }
        else
        {
            this.web_editor.set_visible(true);
            this.web_viewer.set_visible(false);
        }

    }

    //에디터 포커스 주기
    _pExtWebEditor.set_focus = function()
    {
        var isLoad =  this.isEditorLoad;


        if(isLoad)
        {
        	if(!this.viewmode) this.web_editor.callMethod("setFocus");
        }
        else
        {
            this.setTimer(this.nEnbaleTimer,100);
        }
    }

    //에디터 또는 뷰모드가 로딩되기 전에 SetData를 호출할 경우 로딩될때까지 타이머로 체크하고 로딩된 후에 데이터를 넣는다.
    _pExtWebEditor.webeditor_ontimer = function(obj,e)
    {
    	switch(e.timerid)
    	{
    	   case  this.nCompletedimer :
                var isLoad = (this.viewmode) ? this.isViewerLoad : this.isEditorLoad;

	           	if(isLoad)
	           	{
	           	    var targetWeb = (this.viewmode) ? this.web_viewer : this.web_editor;
	           	    this.killTimer(e.timerid);
	                   targetWeb.callMethod("setData",this.editorData);
	           	}
           break;

    	   case this.nCompLoadTimer :
    		   if(!Util.isNull(this.web_editor) && !Util.isNull(this.web_viewer))
    		   {
    			   this.killTimer(e.timerid);
    			   this.set_viewmode(this.viewmode);
    		   }
    	   break;

    	   case this.nEnbaleTimer :
               var isLoad = this.isEditorLoad;

	           	if(isLoad)
	           	{
	           	    this.killTimer(e.timerid);
	           	    if(!this.viewmode) this.web_editor.callMethod("setEditable",this._enableedAct);
	           	}
    	   break;
    	}

    }
    delete _pExtWebEditor;
}