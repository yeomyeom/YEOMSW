﻿/**
 * @fileoverview 엑셀 처리 관련
 */
if (!JsNamespace.exist("NX.Excel") )
{
	/**
	 * @namespace
	 * @name NX.Excel
	 * @memberof! <global>
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 */
	JsNamespace.declare("NX.Excel", {
	
		// Export시 Excel Sheet명 최대자릿수
		_EXCEL_SHEETNM_MAXLEN 		: 31, 
		_EXCEL_EXP_HEADER_GRIDNM 	: "_gridHeaderExport_",
		_EXCEL_EXP_TARGET_GRIDNM	: "_gridExport_",
		
		_GET_SHEET_DATA	: "getsheetdata",
					
		/**
		 * constructor
		 * @param {Object} o 컨테이너컴포넌트(form)
		 * @memberof NX.Excel
		 */
		constructor : function(o)
		{
			this._this = o;
			this.exportitems = [];
			this.importitems = [];
			
			this.addExpItem	= NX.Excel.addExpItem;
			this.addImpItem	= NX.Excel.addImpItem;
//			this.clearItem	= NX.Excel.clearItem;
			
			return this;
		},
		
		/**
		* 객체의 속성
		* @param {object} o addItemObject
		* type : Export 하고자 하는 Item의 종류
		* grid : ExportItemType별 Export 할 Source(grid) / dataset : ExportItemType별 Export 할 Source(dataset)
		* rnage : Export 될 Target의 위치
		* head : ExportItemType이 Grid인 경우 
		* select : ExportItemType이 Grid인 경우 Select의 출력방식
		* merge : ExportItemType이 Grid인 경우 Suppress의 출력방식
		* value : ExportType이 Excel일 경우 value 출력방식
		* image : Image를 Export할지 여부
		* style : Export 에서 제외되는 Style 옵션 ( ',' 로 복수개 나열가능)
		* size : Grid의 width,height설정을 엑셀에 그대로 적용할지 지정
		* acceptstyle : 추가하고자 하는 cell Style -현재 "cellline" 만 지원
		* @memberof NX.Excel
		*/
		addExpItem : function(o, key)
		{
			if (!key) key = this.exportitems.length;
			
			// o : ExportItem Object인경우의 처리
			this.exportitems[key] = o;
		},
		
		addImpItem : function(o, key)
		{
			if (!key) key = this.importitems.length;
			
			// o : ExportItem Object인경우의 처리
			this.importitems[key] = o;
		},
		
		clearItem : function(sType)
		{
			if (sType) sType = "exp";
			
			if (Util.trim(sType).toLowerCase().indexOf("exp"))
			{
				this.exportitems = [];
			}
			else
			{
				this.importitems = [];
			}
			
			this.clear();
		},

		/**
		* 그리드헤더를 CSV로 리턴하는 함수
		* @param  {Grid} 	objGrid	대상그리드객체 배열
		* @return {String} 	그리드 헤더에 대한 csv데이터
		* @example getGridHeader(arrObjGrid, aTitle)
		* @memberOf NX.Excel
		*/
// 		getGridHeader : function(oGrid:Grid, sSep)
// 		{
// 			if (Util.isNull(sSep)) sSep = "," // Default값
// 			
// 			var sHeader 	= "";
// 			var nCellCnt 	= oGrid.getCellCount("head");
// 			var nMaxRow		= GridEx.getGridMaxRow(objGrid);
// 			var nBeforeCol	= 0;
// 			
// 			for (var i=0; i<=nMaxRow; i++)
// 			{
// 				nBeforeCol = 0;		
// 				for (var j=0; j<nCellCnt; j++)
// 				{
// 					var nRow 	= oGrid.getCellProperty("head", j, "row");
// 					var nCol 	= oGrid.getCellProperty("head", j, "col");
// 					var sText 	= Util.trim(oGrid.getCellProperty("head", j, "text")).replace("\r\n", "");
// 						sText 	= sText.replace("▲", "").replace("▼", "");
// 
// 					if (i == nRow)
// 					{
// 						// 빈컬럼 채우기
// 						for (var k=1; k<(nCol-nBeforeCol); k++) 
// 						{
// 							sHeader += sSep;
// 						}				
// 						sHeader += (j == 0 ? "" : sSep) + sText;				
// 						nBeforeCol = nCol;
// 					}
// 				}
// 				sHeader += "\r\n";
// 			}
// 			return sHeader;
// 		},

		/**
		 * 특정Cell의 mask값이 Percent형태일 경우 Export를 위한 추가처리
		 * @param  {Object} 	obj	그리드객체(필수)
		 * @param  {String} 	sBand	그리드Band(필수)
		 * @param  {Number} 	nCell	그리드 CellIndex(필수)
		 * @param  {String} 	sMask	Cell의 mask(필수)
		 * @example _setExprForPercentExport(ObjGrd, "body", 1)
		 * @memberOf NX.Excel
		 */
// 		_setExprForPercentExport : function(obj:Grid, sBand, nCell, sMask)
// 		{
// 			var sExpr 	= Util.trim(obj.getCellProperty(sBand, nCell, "expr"));
// 			var sText 	= Util.trim(obj.getCellProperty(sBand, nCell, "text"));
// 			var sBindInfo = sExpr || sText;
// 
// 			// 부정제외, mask값에 따라 undefined, ''의 설정값 변경가능
// 			var sText 	= sBindInfo.indexOf("bind:") == 0 || sBindInfo.indexOf("expr:") == 0 ? sBindInfo.slice(5) : sBindInfo;
// 			var sExpr 	= "";
// 			if (sMask.indexOf("expr:") == 0)
// 			{
// 				sMask = sMask.slice(5);
// 				sExpr = "expr:(" + sMask + ").indexOf('%') < 0 ? (" + sText + "==undefined ? '' : " + sText + ") : (" + sText + "==0 ? 0 : (isNaN(parseFloat(" + sText + ")) ? 0 : (" + sText + ")/100) )";
// 			}
// 			else {
// 				sExpr = sText + "==0 ? 0 : (isNaN(parseFloat(" + sText + ")) ? 0 : (" + sText + ")/100)";
// 			}
// 				
// 			obj.setCellProperty(sBand, nCell, "expr", sExpr);
// 		},

		/**
		 * Export그리드 속성 및 format변경
		 * @private
		 * @param  {Object} 	obj	그리드객체(필수)
		 * @param  {Object} 	oOrgGrd	원본그리드객체(필수)
		 * @example NX.Excel._convGridFormat(obj, oOrgGrd)
		 * @memberOf NX.Excel
		 */
		_convGridFormat : function(obj, oOrgGrd)
		{
			var nBodyCnt = obj.getCellCount("body");
			for (var j=0; j<nBodyCnt; j++)
			{
/* 2017.10.23 주석처리				
				if (j == 0)
				{
					obj.setCellProperty("body", j, "background", {color:"white"});
					obj.setCellProperty("body", j, "background2", {color:"white"});
				}
				
 				var sCssClass = obj.getCellProperty("body", j, "cssclass");
 				if (sCssClass == "cellgrd_WF_Address1")
 				{
 					obj.setCellProperty("body", j, "cssclass", "");
 				}
*/

// 				var oStyleBg = obj.getCellProperty("body", j, "background");
// 				if (oStyleBg && oStyleBg._bindexpr)
// 				{
// 					oStyleBg._value 	= "";
// 					oStyleBg._bindexpr 	= "";
// 					obj.setCellProperty("body", j, "background", oStyleBg);
// 				}
					
// 				var oStyleBg2 = obj.getCellProperty("body", j, "background2");
// 				if (oStyleBg2 && oStyleBg2._bindexpr)
// 				{
// 					oStyleBg2._value 	= "";
// 					oStyleBg2._bindexpr = "";
// 					obj.setCellProperty("body", j, "background2", oStyleBg2);
// //					obj.setCellProperty("body", j, "align", "right middle");
// 				}
				
// 				var sCssClass = Util.trim(obj.getCellProperty("body", j, "cssclass"));
// 				if (sCssClass) obj.setCellProperty("body", j, "cssclass", "");
				
// 				var sMask 			= Util.trim(obj.getCellProperty("body", j, "mask"));
// 				var sDisplayType 	= Util.trim(obj.getCellProperty("body", j, "displaytype"));
// 				if (sMask)
// 				{
// // 					if (sDisplayType == "number" && sMask.indexOf("%") > 0) // sMask.charAt(sMask.length-1) == "%" : expr관련처리
// // 					{
// // 						NX.Excel._setExprForPercentExport(obj, "body", j, sMask);
// // 						sDisplayType = "percent";
// // 					}
// 					// date형일때 일괄변형하여 처리(String으로 변형)
// 					if (sDisplayType == "date" && sMask == "yyyy-MM")
// 					{
// 						obj.setCellProperty("body", j, "displaytype", "text");
// 						obj.setCellProperty("body", j, "mask", "####-##");
// 						obj.setCellProperty("body", j, "align", "center");
// 					}
// 					else
// 						obj.setCellProperty("body", j, "mask", NX.Excel._convertMask(sMask, sDisplayType));
// 				}
// 
// 				if (sDisplayType == "tree") obj.setCellProperty("body", j, "displaytype", "normal");
			}
			
 			var nSumCnt = obj.getCellCount("summ");
 			for (var j=0; j<nSumCnt; j++)
 			{
 				var sText = Util.trim(obj.getCellProperty("summ", j, "text"));
 				if (sText.indexOf("expr:") < 0 && sText.indexOf("bind:") < 0)
 				{
					obj.setCellProperty("summ", j, "text", oOrgGrd.getCellText(-2, j)); 				
 				}
 				
// 				var sMask = Util.trim(obj.getCellProperty("summ", j, "mask"));
// 				if (sMask)
// 				{
// 					var sDisplayType = Util.trim(obj.getCellProperty("summ", j, "displaytype"));
// 					if (sDisplayType == "number" && sMask.charAt(sMask.length-1) == "%")
// 					{
// 						NX.Excel._setExprForPercentExport(obj, "summ", j, sMask);
// 						sDisplayType = "percent";
// 					}
// 					obj.setCellProperty("summ", j, "mask", NX.Excel._convertMask(sMask, sDisplayType));
// 				}
 			}

			if (oOrgGrd.summarytype == "top") obj.set_summarytype("top");
		},

		/**
		 * 그리드의 displaytype & mask값의 조건에 따라 변경되는 mask값 반환
		 * @private
		 * @param  {String} 	sMask	셀의mask(필수)
		 * @param  {String} 	sDisplayType	셀의displaytype(필수)
		 * @example _convertMask(ObjGrd)
		 * @memberOf NX.Excel
		 */
		_convertMask : function(sMask, sDisplayType)
		{
			switch(sDisplayType)
			{
				case "number" : 
					sMask = sMask.replace("9", "0"); // 엑셀 "9" format 미인식("9" -> "0")
					sMask = sMask.replace("%", "");	 // 엑셀 "%" format 미인식("%" -> "")
					break;
				case "percent" :
					sMask = sMask.replace("9", "0");
					break;
			}
			return sMask;
		},

		// 엑셀Export시 portrait의 위치관련 사용
// 		_getFormatRowCount : function(obj, sBand)
// 		{
// 			var nHeadRowCnt = 0, nSummRowCnt = 0;
// 			
// 			for (var i=0; i<obj.getFormatRowCount(); i++)
// 			{
// 				switch (obj.getFormatRowProperty(i, "band"))
// 				{
// 					case "head" : nHeadRowCnt++; break;
// 					case "summ" : nSummRowCnt++; break;
// 				}
// 			}
// 			return {head:nHeadRowCnt, summ:nSummRowCnt};
// 		},

		// 엑셀Export시 임시생성 그리드의 binding정보 clear
		_clearExpBindDs : function(aGrid)
		{	
// 			for (var i=0, nCnt=aGrid.length; i<nCnt; i++)
// 			{
// 				aGrid[i].set_binddataset(""); // 바인딩정보 초기화
// 			}
		},

		/** 
		 * Excel Export에서 가로형식을 사용할때 열위치를 반환하는 함수
		 * @private
		 * @param {String} objDs Export정보를 가지고 있는 Dataset
		 * @return Cell위치에 해당하는 Alphabet 
		 * @example NX.Excel._getExcelSheetPos(30);
		 * @memberOf NX.Excel
		*/
		_getColPos : function(nCol)
		{
			var nRtnPos = "";
			var nTarget = nexacro.toNumber(nCol);
			while (true)
			{
				var nQuotient = Math.floor(nTarget / 26);
				var nConvCell = Util.decode(nTarget % 26, 1, "A", 2, "B", 3, "C", 4, "D", 5, "E", 6, "F", 7, "G", 8, "H", 9, "I", 10, "J", 
										   11, "K", 12, "L", 13, "M", 14, "N", 15, "O", 16, "P", 17, "Q", 18, "R", 19, "S", 20, "T", 
										   21, "U", 22, "V", 23, "W", 24, "X", 25, "Y", 0, "Z");
				nRtnPos = nConvCell + nRtnPos;
				if (nQuotient > 0)
				{
					nTarget = nQuotient;
					if (nConvCell == "Z")
					{
						nTarget -= 1;
						if (nTarget == 0) break;
					}
				}
				else {break;}
			}
			return nRtnPos;
		},
		
		/**
		 * 그리드를 엑셀파일 Export(Sheet별로 출력 : 기존그리드를 복재하여 처리)
		 * 공통Sort처리시 Sort문자관련 제거, Cell의 edittype이 masknumber의 경우 제거후 Export->재설정
		 * @param {Object} 	oExcel	Export대상 정보
		 * @param {Object} 	oCfg 	Export설정 정보(layout설정시 sheetname동일하게 지정해야함)
		 * @return {Number} ExportItem의 개수
		 * @example export(oExcel)
		 * @memberOf NX.Excel
		 */
		"export" : function(oExcel, oCfg)
		{
			if (!oCfg) oCfg = {};
			
			var pThis = oExcel._this;
			var nCnt = oExcel.exportitems.length;
			if (nCnt <= 0) return pThis.gfn_msgBox("A", "Export 대상을 설정하세요.");
			
			var sExpNm = NX.getUniqueId("_expItem_", pThis);
			var oExp = pThis.objects[sExpNm];
			if (oExp)
			{
				oExp.clear();
			}
			else
			{
				oExp = new ExcelExportObject();
				pThis.addChild(sExpNm, oExp);
			}
			
			oExp.set_exporttype(nexacro.ExportTypes.EXCEL2007);
			
			var oExpItem, oSrchGrid, oDynGrid, oHeaderGrid, sExpLayout;
			var sSheetNm, sFileNm;
			var nExpMaxRowCnt = 0, nExpMaxColCnt = 1, sLstColPos = "A", nLstRowPos = 1;
			var sSuppress = (!Util.isNull(oCfg.suppress) && oCfg.suppress == "Y") ? "suppress" : "nosuppress";
			
			//oExp.set_exportmessageprocess("      %d번째 [ %d / %d]     ");
			//oExp.set_exportuitype("exportprogress");
			//oExp.set_exporteventtype("itemrecord");
			
			for (var i=0; i<nCnt; i++)
			{
				oExpItem = oExcel.exportitems[i];
				if (oExpItem.grid instanceof nexacro.Grid)
				{
					sSheetNm 	= NX.Excel.getExportName(oExpItem.sheetname || oExpItem.grid.name, {lengthcheck:true});
					sFileNm 	= oExpItem.grid.name;
					sExpLayout	= oExpItem.layout;
					if (i == 0)
					{
						oExp.set_exportfilename(NX.Excel.getExportName(oCfg.filename || (sFileNm + "_" + Util.getUserInfo("usrId") + "_" + Util.toDateTime())));
						oExp.set_exporteventtype("totalrecord");
						oExp.set_exporturl(NX.getSvcUrl("excel") + "/XExportImport");
						
						oExp.addEventHandler("onsuccess", 	NX.Excel._export_onsuccess, pThis);
						oExp.addEventHandler("onerror", 	NX.Excel._export_onerror, 	pThis);
						oExp.addEventHandler("onprogress", 	NX.Excel._export_onprogress,pThis);

						oExp.__onsuccess 	= Util.trim(oCfg.onsuccess);
						oExp.__onerror 		= Util.trim(oCfg.onerror);
						oExp.__dynamicgrid	= [];
					}
					
					if (Util.isNull(sExpLayout) || sExpLayout == "horizontal")	nLstRowPos 		= 1;
					if (Util.isNull(sExpLayout) || sExpLayout == "vertical") 	nExpMaxColCnt 	= 1;

					sLstColPos 	= NX.Excel._getColPos(nExpMaxColCnt);
					oSrchGrid 	= oExpItem.searchgrid;
					oDynGrid 	= NX.Excel._getExportGrid(pThis, oExpItem);
					if (oDynGrid)
					{
						oHeaderGrid = NX.Excel._getHeaderGrid(pThis, oExpItem);
						if (oHeaderGrid)
						{
							oExp.addExportItem(nexacro.ExportItemTypes.GRID, oHeaderGrid, sSheetNm + "!" + sLstColPos + nLstRowPos, "" , "" , sSuppress , "" , "" , "" , "" , "cellline");
							nLstRowPos += oHeaderGrid.getFormatRowCount()-1;
						}
						
						if (oSrchGrid && oSrchGrid instanceof nexacro.Grid)
						{
							oExp.addExportItem(nexacro.ExportItemTypes.GRID, oSrchGrid, sSheetNm + "!" + sLstColPos + nLstRowPos , "" , "" , sSuppress , "" , "" , "background,color" , "" , "");
							nLstRowPos += oSrchGrid.getFormatRowCount() + 1;
						}
						
						try
						{
							nExpMaxRowCnt += oDynGrid.getBindDataset().rowcount; // 2018.01.17 Grid->Dataset으로 변경	
						}
						catch(ex)
						{
							nExpMaxRowCnt += 1;
						}
						
						nExpMaxColCnt += oDynGrid.getFormatColCount() + 2;

						oExp.__dynamicgrid.push(oDynGrid);
						oExp.addExportItem(nexacro.ExportItemTypes.GRID, oDynGrid, sSheetNm + "!" + sLstColPos + nLstRowPos
											, "" // strExportHead
											, "" // strExportSelect
											, sSuppress // strExportMerge
											, "" // strExportValue
											, "" // strExportImage
											, "" // strExceptStyle
											, "" // strExportSize
											, "cellline" // strAcceptStyle
											);
											
						nLstRowPos += oDynGrid.rowcount + 5; // set the position of next export
					}
				}
				else
				{
					Util.grace("NX_Excel.xjs :: export() >> Grid 컴포넌트를 확인하세요. " + oExpItem.grid);
				}
			}
			
			NX.Progressbar._showProgressBar(pThis, {title:"엑셀출력 준비중입니다.",max:nExpMaxRowCnt-1});
			return oExp.exportData();
		},
		
		/**
		 * Export 가 완료되었을때 발생되는 이벤트
		 * @private
		 * @param {Object} 	obj	Event가 발생한 Object
		 * @param {Object} 	e 	Event Object
		 * @return N/A
		 * @memberOf NX.Excel
		 */
		_export_onsuccess : function(obj, e)
		{
			NX.Excel._clearExpBindDs(obj.parent.__dynamicgrid);
			NX.Progressbar.init(this);

			var oFunc = this[obj.__onsuccess || "fn_excelExportOnsuccess"]; 
			if (Util.isFunction(oFunc)) oFunc.call(this, obj, e);
		},
		
		/**
		 * Export 도중 오류가 발생되었을때 발생되는 이벤트
		 * @private
		 * @param {Object} 	obj	Event가 발생한 Object
		 * @param {Object} 	e 	Event Object
		 * @return N/A
		 * @memberOf NX.Excel
		 */
		_export_onerror : function(obj, e)
		{
			NX.Excel._clearExpBindDs(obj.parent.__dynamicgrid);
			NX.Progressbar.init(this);

			this.gfn_msgBox("A", e.errormsg + "[" + e.statuscode + "]");
			
			var oFunc = this[obj.__onerror || "fn_excelExportOnerror"]; 
			if (Util.isFunction(oFunc)) oFunc.call(this, obj, e);
		},
		
		/**
		 * Export 수행도중 진행 상태별로 발생하는 이벤트
		 * @private
		 * @param {Object} 	obj	Event가 발생한 Object
		 * @param {Object} 	e 	Event Object
		 * @return N/A
		 * @memberOf NX.Excel
		 */
		_export_onprogress : function(obj, e)
		{
			var oPbar = NX.Progressbar.getContainer(this);
			if (oPbar && oPbar.visible)
			{
				oPbar.fnSetProgressBar(e, "엑셀출력중입니다.");
			}
		},
		
		_destroyGrid : function(pThis, o)
		{
			pThis.removeChild(o.name);
			o.destroy(); 
			o = null;
		},
		
		_getDynGridNm : function(o)
		{
			var sPrefix = o.prefix || this._EXCEL_EXP_TARGET_GRIDNM;
			return sPrefix + NX.Analyzer.path(o.grid, o.container).replace(/\./g,"_");
		},
		
		_getExportGrid : function(pThis, oExpItem)
		{
			var aExceptColId, oBindDs, oGrid = oExpItem.grid;
			var oDynGridNm 	= NX.Excel._getDynGridNm({container:pThis, grid:oGrid});
			var oParent = oGrid.parent;
			var oDynGrid 	= oParent.components[oDynGridNm];
			if (oDynGrid)
			{}
			else
			{
				oDynGrid = new Grid(oDynGridNm, "absolute", 0, 0, oGrid.getOffsetWidth(), 200/*oGrid.getOffsetHeight()*/);
				oParent.addChild(oDynGridNm, oDynGrid);
				oDynGrid.show();
			}
			
			oDynGrid.set_enableevent(false);
			oDynGrid.set_enableredraw(false);
			
			//Export시 필수 표시 제거
			var sGridFormat = GridEx._getCurFormatString(oGrid, oGrid.formatid);		 
			sGridFormat = nexacro.replaceAll(sGridFormat,' cssclass="Cell_P"',''); 
			oDynGrid.set_formats(sGridFormat);
//			oDynGrid.set_cssclass("grd_WF_Basic");
			
			// 특정컬럼 제거처리
			aExceptColId = oExpItem.exceptcolumns;
			if (!Array.isArray(aExceptColId)) aExceptColId = [aExceptColId];
			for (var i=0, nCnt=aExceptColId.length; i<nCnt; i++) // _chk 컬럼에 대한 제외여부 지정
			{
				var nCell = oDynGrid.getBindCellIndex("body", aExceptColId[i]); // cell과 col은 동일해야함(전제조건)
//				var nCol = oDynGrid.getCellProperty("body", nCell, "col");
				if (nCell >= 0) oDynGrid.deleteContentsCol(nCell);
			}
	
			/* 2017.10.23 주석처리
//			NX.Excel._convGridFormat(oDynGrid, oGrid);
			*/
			oDynGrid.set_visible(false);
			oDynGrid.set_binddataset(oGrid.getBindDataset());

//			if (bCurColSize) GridEx._setCurColSize(oDynGrid, aObjGrd[i]);
			oDynGrid.set_enableredraw(true);
			oDynGrid.set_enableevent(true);


			return oDynGrid;
		},
		
		_getHeaderGrid : function(pThis, oExpItem)
		{
			var nColCnt 	= 0;
			var nCurRow 	= 0;
			var sTitle 		= oExpItem.title;
			var sTitleAlign = oExpItem.titlealign;
			var oSrchCond 	= oExpItem.search;
			var oGrid 		= oExpItem.grid;
			var nEndCol		= 0; // merge to column index(End)
			var nFirstCell	= 0; // merge to column index(End)
			var nHeadCell 	= -1;
			
			if (!Util.isNull(sTitle) || oSrchCond)
			{
				var oDynGridNm 	= NX.Excel._getDynGridNm({container:pThis, grid:oGrid, prefix:this._EXCEL_EXP_HEADER_GRIDNM});
				var oDynGrid 	= pThis.components[oDynGridNm];
				if (oDynGrid)
				{
					GridEx.clearFormat(oDynGrid);
				}
				else
				{
					oDynGrid = new Grid(oDynGridNm, "absolute", 0, 0, oGrid.getOffsetWidth(), oGrid.getOffsetHeight());
					pThis.addChild(oDynGridNm, oDynGrid);
					oDynGrid.show();
//					oDynGrid.set_cssclass("grd_WF_Basic");
				}

 				oDynGrid.set_enableevent(false);
 				oDynGrid.set_enableredraw(false);
				oDynGrid.set_visible(false);
				
				oDynGrid.appendContentsRow("head");
//				oDynGrid.appendContentsRow("body");
				// exceptcolumns관련 반영하여면 아래 colcount부분 수정
				for (var i=0, nCnt=oGrid.getFormatColCount()-1; i<nCnt; i++)
				{
					oDynGrid.appendContentsCol();
				}
				
				nColCnt = oDynGrid.getFormatColCount();
				nEndCol = nColCnt-1 < 0 ? 0 : nColCnt-1;
				if (Util.isNull(sTitle))
				{
					oDynGrid.deleteContentsRow("head", 0);
				}
				else
				{
					var nMergeCell = nEndCol == 0 ? 0 : oDynGrid.mergeContentsCell("head", nCurRow, 0, nCurRow, nEndCol, 0, false); // nFirstCell must be zero
					if (nMergeCell >= 0)
					{
						oDynGrid.setCellProperty("head", nMergeCell, "text", sTitle);
						if (sTitleAlign) oDynGrid.setCellProperty("head", nMergeCell, "align", sTitleAlign);
					}
				}
				
				// for condition phrase
				if (oSrchCond)
				{
					var nSepIdx;
					nCurRow 	= oDynGrid.insertContentsRow(-1, nCurRow+1);
					nFirstCell	= GridEx.getCellIndex(oDynGrid, nCurRow, 0, "head");
 					nHeadCell 	= nEndCol == 0 ? nFirstCell : oDynGrid.mergeContentsCell("head", nCurRow, 0, nCurRow, nEndCol, nFirstCell, false);
 					if (nHeadCell >= 0)
 					{
//						oDynGrid.setCellProperty("head", nHeadCell, "celltype", "body");
//						oDynGrid.setCellProperty("head", nHeadCell, "background", {color:"white"});
//						oDynGrid.setCellProperty("head", nHeadCell, "color", "black");
					}
					
					for (var prop in oSrchCond)
					{
						nCurRow 	= oDynGrid.insertContentsRow(-1, nCurRow+1);
						nSepIdx 	= NX.Excel.getMergeCell(nColCnt); // 기준값을 중심으로 2번수행 (nSepIdx ~ nColCnt-1, 0 ~ nSepIdx-1)
						nFirstCell 	= GridEx.getCellIndex(oDynGrid, nCurRow, 0, "head"); // right
						nFirstCell	= oDynGrid.mergeContentsCell("head", nCurRow, 0, nCurRow, nSepIdx-1, nFirstCell, false);
						nHeadCell 	= oDynGrid.mergeContentsCell("head", nCurRow, nSepIdx, nCurRow, nColCnt-1, nFirstCell+1, false);
/* before modify about condition merage
						nFirstCell 	= GridEx.getCellIndex(oDynGrid, nCurRow, 1, "head"); // right
						nHeadCell 	= oDynGrid.mergeContentsCell("head", nCurRow, 1, nCurRow, nColCnt-1, nFirstCell, false);
 */
						if (nHeadCell >= 0)
						{
							oDynGrid.setCellProperty("head", nHeadCell-1, "text", String(prop).replace(/\@\d\@$/g, ""));
//							oDynGrid.setCellProperty("head", nHeadCell-1, "celltype", "body");
//							oDynGrid.setCellProperty("head", nHeadCell-1, "background", {color:"white"});
//							oDynGrid.setCellProperty("head", nHeadCell-1, "color", "black");
							
							oDynGrid.setCellProperty("head", nHeadCell, "text", oSrchCond[prop]);
//							oDynGrid.setCellProperty("head", nHeadCell, "celltype", "body");
//							oDynGrid.setCellProperty("head", nHeadCell, "background", {color:"white"});
//							oDynGrid.setCellProperty("head", nHeadCell, "color", "black");
							oDynGrid.setCellProperty("head", nHeadCell, "align", "left");
						}
					}
				}
				
				// for datetime
				nCurRow 	= oDynGrid.insertContentsRow(-1, nCurRow+1);
				nFirstCell	= GridEx.getCellIndex(oDynGrid, nCurRow, 0, "head");
				nHeadCell 	= nEndCol == 0 ? nFirstCell : oDynGrid.mergeContentsCell("head", nCurRow, 0, nCurRow, nEndCol, nFirstCell, false);
				if (nHeadCell >= 0)
				{
//					oDynGrid.setCellProperty("head", nHeadCell, "celltype", "body");
					oDynGrid.setCellProperty("head", nHeadCell, "align", "right");
//					oDynGrid.setCellProperty("head", nHeadCell, "background", {color:"white"});
//					oDynGrid.setCellProperty("head", nHeadCell, "color", "black");
					oDynGrid.setCellProperty("head", nHeadCell, "text", Util.getDateFormatString(new Date(), "yyyy-MM-dd HH:mm:ss"));
				}
				
				oDynGrid.appendContentsRow();
				oDynGrid.set_enableredraw(true);
				oDynGrid.set_enableevent(true);
				
				return oDynGrid;
			}
		},

		/**
		 * 조회조건의 Merge처리시 기준index값을 반환
		 * @param {Number} 	 nColCnt 전체Col Count
		 * @example getMergeCell(30)
		 * @memberOf NX.Excel
		 */
		getMergeCell : function(nColCnt)
		{
			var nColIdx = parseInt(nColCnt / 3);
			if (nColIdx < 1) nColIdx = 1;
			return nColIdx;
		},
		
		/**
		 * 파일명 및 엑셀Sheet명 반환 하는 함수 (길이체크 추가)
		 * @param {String}	sFileNm 파일명/Sheet명
		 * @param {Object}	oCfg 설정객체 (lengthcheck속성 : 길이체크여부)
		 * @return {String} 변환된 파일/Sheet명
		 * @example getExportName("테스트/임시파일")
		 * @memberOf NX.Excel
		 */
		getExportName : function(sFileNm, oCfg)
		{
			if (!oCfg) oCfg = {};
			var bLenCheck 	= oCfg.lengthcheck === true ? true : false;
			var oExpItems 	= oCfg.sheetcheck;			
			var sConvFileNm = Util.trim(sFileNm).replace(/[\[\]\/\:\*\?\<\>\|\.]/g, "_"); 	// 특수문자로 포함된 파일의 경우 Export불가 ("."의 경우 확장자 미지정관련추가)
			
			if (bLenCheck && (sConvFileNm.length > NX.Excel._EXCEL_SHEETNM_MAXLEN)) 		// 엑셀시트명 31자까지인식
			{
				sConvFileNm = sConvFileNm.substr(0, NX.Excel._EXCEL_SHEETNM_MAXLEN);
			}
			
			return sConvFileNm;
		},
		
		/*
		 * dataset : import transaction을 처리 결과를 받을 Dataset의 ID 들입니다.
		 * arg : import transaction을 위한 인자값.a=b의 형태로 입력하고, 빈칸으로 구분합니다.
		 * onsuccess : 
		 * onerror : 
		 */
		"import" : function(oExcel, oCfg)
		{
			if (!oCfg) oCfg = {};
		
			var pThis 	= oExcel._this;
			var nCnt 	= oExcel.importitems.length;
			
			var sServerFile		= oCfg.serverfile || "";
			var sArgs			= oCfg.args || "";			
			var sOnSuccessFunc 	= Util.trim(oCfg.onsuccess) || "fn_excelImportOnsuccess";
			var sOnErrorFunc 	= Util.trim(oCfg.onerror) 	|| "fn_excelImportOnerror";
			var sFileDialogPath = oCfg.filedialogpath || "";
			var sFileFilter		= oCfg.filefilter || "Worksheet Files (*.xls,*.xlsx)|*.xls;*.xlsx|All Files (*.*)|*.*|";
			
			var oImpItem, sCommand, sOutput, sHead, sBody, sDataset, oDyncDs, bClear, sHeadRow, sAreaPos;
			var sRange = "", sOutDs = "";
			var oOpt = [];
			
			for (var i=0; i<nCnt; i++)
			{
				oImpItem	= oExcel.importitems[i];
				sDataset 	= oImpItem.dataset;
				oDyncDs 	= DatasetEx._get("_import_" + sDataset, pThis);
				sCommand 	= oImpItem.command || NX.Excel._GET_SHEET_DATA;
				sOutput		= ";output=output" + i;
				sHead 		= oImpItem.head ? ";head=" + oImpItem.head : "";
				sHeadRow   	= sCommand != NX.Excel._GET_SHEET_DATA ? "0" : (Util.isNull(oImpItem.headrow)) ? "1" : oImpItem.headrow;
				
				sAreaPos = "!A"+(parseInt(sHeadRow)+1);
				sBody 		= (Util.isNull(oImpItem.body)) ? ";body="+sAreaPos : ";body="+oImpItem.body;

				bClear	 	= !(oImpItem.clear === false);
				
				oDyncDs.clearData();
				oOpt[i] = {dataset:sDataset, clear:bClear, headrow:sHeadRow, dyncdataset:oDyncDs.name};
				sRange += "[command=" + sCommand + sOutput + (sHead ? sHead : "") + sBody + "]";
				
				sOutDs += (i==0 ? "" : ",") + oDyncDs.name + "=output" + i;
			}

			var sImpNm	= NX.getUniqueId("_excel_import_", pThis);
			var oImp 	= pThis.objects[sImpNm];
			if (oImp)
			{}
			else
			{
				oImp = new ExcelImportObject(sImpNm, pThis);				
				oImp.addEventHandler("onsuccess", NX.Excel._import_onsuccess, pThis);
				oImp.addEventHandler("onerror", NX.Excel._import_onerror, pThis);
				
				oImp.set_importfilemode(sServerFile ? "server" : "local");
				oImp.set_filedialogpath(sFileDialogPath);
				oImp.set_filefilter(sFileFilter);
				oImp.set_importurl(NX.getSvcUrl("excel") + "/XImport");
				pThis.addChild(sImpNm, oImp);
			}
			
			oImp.__onsuccess 	= sOnSuccessFunc;
			oImp.__onerror 		= sOnErrorFunc;
			oImp.__option       = oOpt;
		
			if (NX.getApp().gvLogLevel >= 4)
			{
				var sLogMsg = "===== Excel Import =====\r\n"
							+ " 1.URL 		: " + oImp.importurl+ "\r\n"
							+ " 2 FileMode	: " + oImp.importfilemode + "\r\n"
							+ " 3.범위 		: " + sRange 		+ "\r\n"
							+ " 4.dataset 	: " + sOutDs 		+ "\r\n"
							+ " 5.onsuccess : " + sOnSuccessFunc+ "\r\n" 
							+ " 6.onerror 	: " + sOnErrorFunc 	+ "\r\n"
							+ "========================\r\n";
				Util.trace(sLogMsg);
			}


			oImp.importData(sServerFile, sRange, "[" + sOutDs + "]", sArgs);
		},
		
		_import_onsuccess : function(obj, e)
		{
			var oRtn, oDs, oDyncDs, aOption = obj.__option;
			var bClear, nHeadRow = 0;
			
			// 컬럼index순으로처리
			for (var i=0, nCnt=aOption.length; i<nCnt; i++)
			{
				oRtn   	= aOption[i];
				oDs	   	= this.objects[oRtn.dataset];
				oDyncDs = this.objects[oRtn.dyncdataset];
				nHeadRow= parseInt(oRtn.headrow);
				bClear  = oRtn.clear;

				/*
				for (var j=nHeadRow; j>0; j--)
				{
					oDyncDs.deleteRow(j-1);
				}
				*/
				if (bClear) oDs.clearData();
					
				oDs.appendData(oDyncDs, false);
//				this.removeChild(oDyncDs);
			}

			if (NX.isStatusbar())
			{
				//var sMsg = NX._getUiMsg("UI009", ["엑셀 업로드가"]);
				var sMsg = Util.getComMsg("I.ZZ.ZZ.0009","엑셀 업로드");
				NX.Service._setStatusMsg(sMsg);				
			}

			var oFunc = this[obj.__onsuccess]; 
			if (Util.isFunction(oFunc)) oFunc.call(this, obj, e);
		},
		
		_import_onerror : function(obj, e)
		{
//			if (e.statuscode == 9901)
//			{
//				e.errormsg = "암호화된 파일은 현재 지원하지 않습니다.\n\n" + e.errormsg;
//			}
			this.gfn_msgBox("A", "E.ZZ.ZZ.0050");
			
			var oFunc = this[obj.__onerror]; 
			if (Util.isFunction(oFunc)) oFunc.call(this, obj, e);
		}
		
	});
}
