﻿/**
 * @fileoverview Util와 관련된 함수.
 */

if ( !JsNamespace.exist("Util") )
{
	/**
	 * @namespace
	 * @name Util
	 * @author Dong-min Kim <hefaitos@tobesoft.com>
	 * @memberof! <global>
	 */
	JsNamespace.declare("Util", {
		
		/**
		 * 소수점 표시자 (locale에 따라 정의)
		 * @public
		 * @type string
		 * @example "." ==> "0.01"
		 * @memberOf Util
		 */
		point: ".",

		/**
		 * 숫자 단위 구분 표시자 (locale에 따라 정의)
		 * @public
		 * @type string
		 * @example "," ==> "1,234"
		 * @memberOf Util
		 */		
		separator: ",",
		
		/**
		 * 통화 표시에서 separator 규칙 정의 (locale에 따라 정의)
		 * @public
		 * @type string
		 * @example 
		 *  "\\3" ==> 10,000,000 
		 *  "\\1\\2\\3" ==> 1,000,00,0 
		 *  "\\3\\1" ==> 1,0,0,0,000
		 * @memberOf Util
		 */			
		separatorGrouping: "\\3",
		
		/**
		 * mask format cache.
		 * @private
		 * @memberOf Util
		 */
		_numberMaskCache: {},		
		
		/**
		 * 요일명칭 정의<br>
		 * getDateFormatString 함수에서 masking 할때 사용하는 명칭이다.<br>
		 * 필요에 따라 수정 하여 사용한다.(보통 locale에 따라 정의 될 것으로 예상됨.)
		 * @example : ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
		 * @public
		 * @type array
		 * @memberOf Util
		 */			
		weekName: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"],
		//weekName: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],				
		
		/**
		 * 축약 요일명칭 정의<br>
		 * getDateFormatString 함수에서 masking 할때 사용하는 명칭이다.<br>
		 * 필요에 따라 수정 하여 사용한다.(보통 locale에 따라 정의 될 것으로 예상됨.)
		 * @example
		 * ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]
		 * @public
		 * @type array
		 * @memberOf Util
		 */	
		weekShortName: ["일", "월", "화", "수", "목", "금", "토"],
		//weekShortName: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],		
		
		/**
		 * 월명칭 정의<br>
		 * getDateFormatString 함수에서 masking 할때 사용하는 명칭이다.<br>
		 * 필요에 따라 수정 하여 사용한다.(보통 locale에 따라 정의 될 것으로 예상됨.)
		 * @example
		 * ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
		 * @public
		 * @type array
		 * @memberOf Util
		 */	
		monthName: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
		//monthName: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
		
		/**
		 * 축약 월명칭 정의<br>
		 * getDateFormatString 함수에서 masking 할때 사용하는 명칭이다.<br>
		 * 필요에 따라 수정 하여 사용한다.(보통 locale에 따라 정의 될 것으로 예상됨.)
		 * @example
		 * ["Jan ", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
		 * @public
		 * @type array
		 * @memberOf Util
		 */	
		monthShortName: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
		//monthShortName: ["Jan ", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
		
		/**
		 * 오전/오후<br>
		 * getDateFormatString 함수에서 masking 할때 사용하는 명칭이다.<br>
		 * 필요에 따라 수정 하여 사용한다.(보통 locale에 따라 정의 될 것으로 예상됨.)
		 * @example
		 * ["AM", "PM"]
		 * @public
		 * @type array
		 * @memberOf Util
		 */	
		ttName: ["오전", "오후"],
		//ttName: ["AM", "PM"]	
		
		/**
		 * mask format cache.
		 * @private
		 * @memberOf Util
		 */
		_dateMaskCache: {},
		
		/**
		 * 전화번호 지역코드
		 * @private
		 * @type string
		 * @memberOf Util
		 */
		_areaCode : ["031", "032", "033", "041", "042", "043", "044", "051", "052", "053", "054", "055", "061", "062", "063", "064"],
		/**
		 * 통신망식별부호
		 * @private
		 * @type string
		 * @memberOf Util
		 */
		_cellCode : ["010", "011", "016", "017", "018", "019"],		
		
		_MSG_ID_COL		: "code",
		_MSG_CNTN_COL	: "name"
	});
	
	/**
	 * value의 string 여부 반환
	 * @param {*} value 확인할 value.
	 * @return {boolean} string 여부.
	 * @example
	 * trace(Util.isString("test string!!!"));	// output : true
	 * trace(Util.isString(1234));	// output : false
	 * @memberOf Util
	 */
	Util.isString = function(value) 
	{
		return typeof value === 'string';
	}
		
	/**
	 * sText를 String으로 형변환(undefined, null, ""  -> "")
	 * @param {String} sText	변환할 문자열
	 * @return {String} 결과값
	 * @example Util.toString("abcd");
	 * @memberOf Util
	 */
	Util.toString = function(sText)
	{
		if (sText == undefined) return "";
		if (sText == null) return "";
		if (sText instanceof String) return sText;

		return ""+sText;
	}

/**
	 * 문자열의 좌측 공백(제거문자)을 제거
	 * @param {String} sOrg		좌측 공백문자 제거대상 문자열
	 * @param {String} sTrim	치환대상 문자열(default:" ")
	 * @return {String} 결과값
	 * @example Util.ltrim(sOrg, " ");
	 * @memberOf Util
	 */
	Util.ltrim = function(sOrg, sTrim)
	{
		sOrg = this.toString(sOrg);

		if (Util.isNull(sOrg))		return "";
		if (Util.isNull(sTrim))		sTrim = "\\s";

		return sOrg.replace(new RegExp("\^[" + sTrim + "]\+", "g"), "");
	}

	/**
	 * 문자열의 우측 공백을 제거
	 * @param {String} sOrg		우측 공백문자 제거대상 문자열
	 * @param {String} sTrim	치환대상 문자열(default:" ")
	 * @return {String} 결과값
	 * @example Util.rtrim(sOrg, " ");
	 * @memberOf Util
	 */
	Util.rtrim = function(sOrg, sTrim)
	{
		sOrg = this.toString(sOrg);

		if (Util.isNull(sOrg))		return "";
		if (Util.isNull(sTrim))		sTrim = "\\s";

		return sOrg.replace(new RegExp("[" + sTrim + "]\+\$", "g"), "");
	}

	/**
	 * 문자열의 좌/우측 공백을 제거
	 * @param {String} sOrg		좌/우측 공백문자 제거대상 문자열
	 * @param {String} sTrim	치환대상 문자열(default:" ")
	 * @return {String} 결과값
	 * @example Util.trim(sOrg, " ")
	 * @memberOf Util
	 */
	Util.trim = function(sOrg, sTrim)
	{
		sOrg = this.toString(sOrg);
		
		if (Util.isNull(sOrg))		return "";
		if (Util.isNull(sTrim))		sTrim = "\\s";

		var sRegExp = "\^[" + sTrim + "]\+\|[" + sTrim + "]\+\$";
		var objRegExp = new RegExp(sRegExp, "g");

		return sOrg.replace(objRegExp, "");
	}

	/**
	 * 문자열을 지정된 길이만큼 좌측부터 채우는 함수
	 * @param {String} sOrg		원본 문자열
	 * @param {String} sPad		왼쪽에 채울 문자(default=" ")
	 * @param {Number} nCnt		출력될 문자열의 길이(default=sOrg길이)
	 * @return {String} 결과값
	 * @example Util.lpad(sOrg, " ", 3)
	 * @memberOf Util
	 */
	Util.lpad = function(sOrg, sPad, nCnt)
	{
		var sRet = "";
		
		if (this.isNull(sOrg))		sOrg = "";
		if (this.isNull(sPad))		sPad = " ";
		if (this.isNull(nCnt))		nCnt = sOrg.length;

		for (var i=0; i<nCnt-sOrg.length; i++)	sRet += sPad;

		return (sRet += sOrg);
	}

	/**
	 * 문자열을 지정된 길이만큼 우측부터 채우는 함수
	 * @param {String} sOrg		원본 문자열
	 * @param {String} sPad		오른쪽에 채울 문자
	 * @param {Number} nCnt		출력될 문자열의 길이
	 * @return {String} 결과값
	 * @example rpad("2", "0", 2)
	 * @memberOf Util
	 */
	Util.rpad = function(sOrg, sPad, nCnt)
	{
		var sRet = "";

		if (this.isNull(sOrg))	sOrg = "";
		if (this.isNull(sPad))	sPad = " ";
		if (this.isNull(nCnt))	nCnt = sOrg.length;

		sRet += sOrg;
		
		for (var i = 0; i < nCnt-sOrg.length; i++ )	sRet += sPad;

		return sRet;
	}

	/**
	 * 문자열의 우측부터 지정한 길이만큼 가져오는 함수
	 * @param {String} sOrg		원본 문자열
	 * @param {Number} nSize	출력될 문자열의 길이
	 * @return {String} 결과값
	 * @example Util.right("abcd", 2)
	 * @memberOf Util
	 */
	Util.right = function(sOrg, nSize)
	{
		if (this.isNull(sOrg) || this.isNull(nSize))	return "";

		if (sOrg.length < nSize)
			return sOrg;
		else
			return sOrg.substr(sOrg.length-nSize, nSize);
	}

	/**
	 * 문자열에서 Count할 문자열이 포함되어 있는 갯수를 반환
	 * @param {String} sOrg		원본 문자열
	 * @param {String} sCnt		출력될 문자열의 길이
	 * @return {Number} 결과값
	 * @example Util.count("abcd", "bc")
	 * @memberOf Util
	 */
	Util.count = function(sOrg, sCnt)
	{
		var i, sRet="";
		var nCnt = 0;

		if (this.isNull(sOrg) || this.isNull(sCnt))	return -1;

		for(i=0; i<sOrg.length; i+= sCnt.length)
		{
			if (sOrg.substr(i, sCnt.length) == sCnt) nCnt++;
		}
		return nCnt;
	}

	/**
	 * 문자열의 전체 길이 계산(한글,한자:2 / 나머지 1)
	 * @param {String} sVal		길이를 확인 할 문자열
	 * @param {String} sCnt		출력될 문자열의 길이
	 * @return {Number} 결과값
	 * @example Util.lenb("abcdefg")
	 * @memberOf Util
	 */
	Util.lenb = function(sVal)
	{
		var len = 0;
        var sChar = "";
		if (this.isNull(sVal)) 	return -1;

		for (i=0; i<sVal.length; i++)
		{
			sChar = sVal.charCodeAt(i);
			if (sChar > 127)
			{
				len += 2;
			}
			else
			{
				switch(sChar) 
				{
				    case 60 : len += 4; break; //< : &lt;
					case 62 : len += 4; break; //> : &gt;
				    case 38 : len += 5; break; //& : &amp;
				    case 34 : len += 6; break; //" : &quot;
				    case 92 : len += 6; break; //\ : &apos;
				    default: len += 1; break;
				}				
			}
		}
		return len;
	}

	/**
	 * 숫자형식 여부 확인(소수점적용)
	 * @param {String} sNum		숫자형식 확인 대상 문자열
	 * @return {Boolean} 결과값(true/false)
	 * @example Util.isDigit("123.45")
	 * @memberOf Util
	 */
	Util.isDigit = function(sNum)
	{
		var c;
		var point_cnt=0;
		var ret=true;

		if ( this.isNull(sNum) )	return false;

		for (var i=0; i<sNum.length; i++)
		{
			c = sNum.charAt(i);
			if (i == 0 && (c == "+" || c == "-"));
			else if (c >= "0" && c <= "9");
			else if (c == ".")
			{
				point_cnt++;
				if ( point_cnt > 1 )
				{
					ret = false;
					break;
				}
			}
			else
			{
				ret = false;
				break;
			}
		}
		return ret;
	}

	/**
	 * 숫자에 천단위 "," 적용
	 * @param {String} sNum		숫자형식 확인 대상 문자열
	 * @param {String} isSign 	양수인경우 "+" 표기
	 * @return {String} 결과값
	 * @example Util.setComma("12345678")
	 * @memberOf Util
	 */
	Util.setComma = function(sNum, isSign)
	{
		sNum = Util.trim(sNum);
		
		var ppos, sDigit, nEnd, nStart=0, sRet="", sPlus="";

		if (this.isNull(sNum))		return "";
		if (this.isNull(isSign))	isSign = "N";

		if (sNum.charAt(0) != "-" && sNum.charAt(0) != "+") 
		{
			if (isSign == "Y") sPlus = "+";
		}
		
		if (sNum.charAt(0) == "+" || sNum.charAt(0) == "-")
		{
			sRet += sNum.charAt(0);
			nStart = 1;
		}

		ppos = sNum.indexOf(".", nStart);
		if ( ppos < 0 )
			nEnd = sNum.length;
		else
			nEnd = ppos;
		sDigit = sNum.substr(nStart, nEnd-nStart);
		for( pos = 0 ; pos < sDigit.length ; pos ++ )
		{
			if ( pos != 0 && (sDigit.length-pos)%3 == 0 )
				sRet += ",";
			sRet += sDigit.charAt(pos);
		}
		
		sRet += sNum.substr(nEnd);
		sRet = sPlus + sRet;
		
		return sRet;
	}

	/**
	 * IP Address 체크
	 * @param {String} sValue	IP Address
	 * @return {Boolean} sValue가 IP Address에 유효한 값인지 체크하여 Boolean값 반환
	 */
	Util.isIP = function(sValue)
	{
		var oRegExp = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		return oRegExp.test(sValue);
	}
	
	/**
	 * 전화번호 확인
	 * @param {String} sTelNo	전화번호
	 * @return {Boolean} 전화번호형식 준수여부
	 * @example Util.isTelNo("02-123-1234")
	 * @memberOf Util
	 */
	Util.isTelNo = function(sTelNo)
	{
		var sRegExp = "(^02.{0}|^01.{1}|^[0-9]{3})([-\\t\\n\\x0B\\f\\r]?)(\\d{3,4})([-\\t\\n\\x0B\\f\\r]?)(\\d{4}$)";
		var oRegExp = new RegExp(sRegExp);
		return oRegExp.test(sTelNo);
	}

	/**
	 * 주민 등록번호 확인
	 * @param {String} sValue	주민 등록 번호
	 * @return {Boolean} sValue가 주민등록번호 형식에 맞는 경우 = true
	 *                   sValue가 없거나, 주민등록번호 형식에 맞지 않는 경우 = false
	 * @example Util.isRsrNo("XXXXXXXXXXXXX")
	 * @memberOf Util
	 */
	Util.isRsrNo = function(sValue)
	{
		if (this.isNull(sValue))	return false;
		
		var v_JuminNo = sValue.replace("-", "");
		var v_JuminChkDgt = [2,3,4,5,6,7,8,9,2,3,4,5];
		var v_FNum = new Number();
		var v_LNum = new Number();
		var v_iSum = new Number();
		var v_RtnVal;
		var v_YY;

		if (v_JuminNo.length != 13)
		{
			return false;
		}
		
		v_FNum = v_JuminNo.substr(0, 6).toString();
		v_LNum = v_JuminNo.substr(6).toString();
	  
		if (v_LNum.substr(0,1) == '1' ||  v_LNum.substr(0,1) == '2')
			v_YY  = '19';
		else if (v_LNum.substr(0,1) == '3' ||  v_LNum.substr(0,1) == '4') 
			v_YY  = '20';
		else
			return false;
		
		if (Util.isValidDate(v_YY + v_FNum) == false)
		{
			return false;
		}

		if (this.isDigit(v_JuminNo) == false)
		{
			return false;
		}

		for ( ix = 0; ix < 12 ; ix++)
		{
			v_iSum += (parseInt(v_JuminNo.substr(ix, 1)) * v_JuminChkDgt[ix]);
		}
			
		v_iSum = 11 - (v_iSum%11);
		v_iSum = v_iSum % 10;
		if (v_iSum != (parseInt(v_JuminNo.substr(12, 1))))
			return false;

		return true; 
	}

	/**
	 * 문자열이 알파벳(a~z, A~Z), 숫자만으로 구성되어 있는지 체크
	 * @param {String} sVal		체크할 문자열
	 * @return {Boolean} 알파벳, 숫자만 있는경우 = true
	 *                   알파벳, 숫자가 아닌 글자가 하나라도 있는 경우 = false
	 * @example Util.isAlpaNum("aAzZ09")
	 * @memberOf Util
	 */
	Util.isAlpaNum = function(sVal)
	{
		if (this.isNull(sVal))	return false;

		if (sVal.search("[^A-Za-z0-9]") >= 0)
			return false;
		else
			return true;
	}

	/**
	 *  문자열이 한글로만 구성되어 있는지 체크
	 * @param {String} sVal		체크할 문자열 ( 예 :  ) 
	 * @return {Boolean} 한글만 있는경우 = true
	 *                   한글이 아닌 글자가 하나라도 있는 경우 = false
	 * @example Util.isKor("가나다")
	 * @memberOf Util
	 */
	Util.isKor = function(sVal)
	{
		if (this.isNull(sVal))	return false;
			
		for (var i = 0; i < sVal.length; i++)
		{
			if( !((sVal.charCodeAt(i) > 0x3130 && sVal.charCodeAt(i) < 0x318F) || (sVal.charCodeAt(i) >= 0xAC00 && sVal.charCodeAt(i) <= 0xD7A3)))
				return false;
		}
		
		return true;
	}

	/**
	 *  대소문자 구분없이 문자갯수 세기
	 * @param {String} sOrg		원래 문자열
	 * @param {String} sCnt		갯수를 셀 문자열
	 * @return {Number} 일치하는 문자열의 갯수
	 * @example Util.countCase("aaBBbbcc","BB")
	 * 
	 * @memberOf Util
	 */
	Util.countCase = function(sOrg, sCnt)
	{
		var i, sRet="";
		var nCnt = 0;

		if( this.isNull(sOrg) || this.isNull(sCnt) )		return -1;
			
		for( i = 0 ; i < sOrg.length ; i += sCnt.length )
		{
			if( sOrg.toLowerCase().substr(i, sCnt.length) == sCnt.toLowerCase() )
				nCnt++;
		}
		return nCnt;
	}

	/**
	 * 조건에 따른 Value 처리
	 * @param {Object} 함수의 Arguments에서 확인
	 * @return 결과값
	 * @example Util.decode( sCmp, "abc", true, false)
	 * @memberOf Util
	 */
	Util.decode = function()
	{
		var varRtnValue	= null;
		var aArgument	= this.decode.arguments;
		var varValue	= aArgument[0];
		var bIsDefault	= false;
		var nCount		= 0;

		if ((aArgument.length % 2) == 0)
		{
			nCount		= aArgument.length-1;
			bIsDefault	= true;
		}
		else
		{
			nCount		= aArgument.length;
			bIsDefault	= false;
		}

		for (var i=1; i<nCount; i+=2)
		{
			if (varValue == aArgument[i])
			{
				varRtnValue	= aArgument[i+1];
				break;
			}
		}

		if (varRtnValue == null && bIsDefault) {
			varRtnValue = aArgument[aArgument.length-1];
		}

		return varRtnValue;
	}

	/**
	 * 알파벳문자에 대해서 9이후의 숫자로 변환하여 반환
	 * Tab화면 로딩시 사용됨 예) A : 10, B : 11, C : 12...
	 * @param {String} 숫자로구성된문자열
	 * @return {String} 문자
	 * @memberOf Util
	 */
	Util.num2alpha = function(chr)
	{
		return this.decode(chr, "10", "A", "11", "B", "12", "C", "13", "D", "14", "E", "15", "F", 
								"16", "G", "17", "H", "18", "I", "19", "J", "20", "K", "21", "L", 
								"22", "M", "23", "N", "24", "O", "25", "P", "26", "Q", "27", "R", 
								"28", "S", "29", "T", "30", "U", "31", "V", "32", "W", "33", "X", 
								"34", "Y", "35", "Z", chr);
	}

	/**
	 * 조건에 따른 Value 처리
	 * @param {Object} 조건식
	 * @param {Object} true반환값 		조건식 결과가 true일때 반환하는 Value
	 * @param {Object} false반환값 	조건식 결과가 false일때 반환하는 Value
	 * @return {Object} 결과값
	 * @example Util.iif( sVal=="test", true, false)
	 * @memberOf Util
	 */
	Util.iif = function()
	{
		var aArgument = this.iif.arguments;

		if (arrArgument[0]) {
			return aArgument[1];
		}
		else {
			return aArgument[2];
		}
	}
	
	/**
	 * value의 Boolean 여부 반환.
	 * @param {boolean} value 확인할 value.
	 * @return {boolean} Boolean 여부.
	 * @example
	 * var a = false;
	 * trace(Util.isBoolean(a));	// output : true
	 *
	 * var a = true;
	 * trace(Util.isBoolean(a));	// output : true 	 
	 * @memberOf Util
	 */
	Util.isBoolean = function(value)
	{
		return typeof(value) === "boolean";
	}

	/**
	 * Null에 해당하는 값 체크.
	 * @param {String} sValue	Null 확인 밗
	 * @return {Boolean} 결과값(true/false)
	 * @example Util.isNull("abcd")
	 * @memberOf Util
	 */
	Util.isNull = function(sValue, bTrim)
	{
		if (bTrim === true) sValue = this.trim(sValue);
		
		if (new String(sValue).valueOf() == "undefined")
			return true;
		if (sValue == null)
			return true;
		if (("x"+sValue == "xNaN") && ( new String(sValue.length).valueOf() == "undefined" ) )
			return true;
		if (sValue.length == 0)
			return true;
		
		return false;
	}

	/**
	 * Null 값을 체크하여 다른값을 반환
	 * @param {String} sValue 	체크할 대상 값
	 * @param {String} sRepValue 	Null일경우 반환 할 값
	 * @return {Boolean} 결과값(true/false)
	 * @example Util.nvl("abcd")
	 * @memberOf Util
	 */
	Util.nvl = function(sValue, sRepValue)
	{
		if (this.isNull(sValue)) return sRepValue;
		else return sValue;
	}
	
	/**
	 * 전달받은 대상에 대해서 문자열,Boolean,숫자형으로 참/거짓인지 판단 <- FRAME에서 사용
	 * @param {Object} p 체크할 대상 값
	 * @return {Boolean} 결과값(true/false)
	 * @example Util.isTrue("abcd")
	 * @memberOf Util
	 */
	Util.isTrue = function(p)
	{
		switch(typeof(p))
		{
			case "string" :
				return p == "true" || p == "1";
			case "boolean" :
				return p;
			case "number" :
				return Boolean(p);
		}
	}
	
	/*********************************************************************************************************
		Number관련 스크립트 Function (Begin) 
	*********************************************************************************************************/
	/**
	 * value의 number 여부 반환.
	 * @param {*} value 확인할 value.
	 * @return {boolean} number 여부.
	 * @example
	 * trace(Util.isNumber(1234));	// output : true
	 * trace(Util.isNumber("1234"));	// output : false		 
	 * @memberOf Util
	 */		
	Util.isNumber = function(value)
	{
		return typeof value === 'number' && isFinite(value);
	}
	

	/**
	 * 소수점 처리에 대한 보정(개발자 사용금지)
	 * @private
	 * @example Util._roundDight(2.155, 2)
	 * @memberOf Util
	 */
	Util._roundDight = function(n, digits)
	{
		if (digits >= 0) 
		{
			return parseFloat(n.toFixed(digits)); 
		} else {
			digits = Math.pow(10, digits); 
			var t = Math.round(n * digits); // digits;
			return parseFloat(t.toFixed(0));
		}
	}

	/*********************************************************************************************************
		Date 관련 스크립트 Function (Begin) 
	*********************************************************************************************************/
	/**
	 * value의 Date 여부 반환.
	 * @param {date} value 확인할 value.
	 * @return {boolean} Date 여부.
	 * @example
	 * var a = new Date();
	 * trace(Util.isDate(a));	// output : true
	 *
	 * var a = "20130501";
	 * trace(Util.isDate(a));	// output : false 	 
	 * @memberOf Util
	 */
	Util.isDate = function(value)
	{
		return Object.prototype.toString.call(value) === "[object Date]";
	}
	
	/**
	 * value의 Function 여부 반환.
	 * @param {*} value 대상
	 * @return {Boolean} Function여부.
	 * @example
	 * trace(Util.isFunction(Util.isFunction));	// output : true
	 *
	 * this.fnTest = function(){}
	 * trace(Util.isFunction(this.fnTest));	// output : true
	 * @memberOf Util
	 */
	Util.isFunction = function(value)
	{
		return Object.prototype.toString.call(value) === "[object Function]";
	},
	
	/**
	 * 날짜 형식이 맞는지 확인
	 * @param {String} sDate	yyyyMMdd형태의 날짜
	 * @return {Boolean} 날짜형식이 맞는 경우 = true
	 *                   날짜형식이 맞지 않거나, sDate가 입력되지 않은 경우 = false
	 * @example Util.isValidDate("20151122")
	 * @memberOf Util
	 */
	Util.isValidDate = function(sDate)
	{
		if (this.isNull(sDate))	return false;
		
		sDate = sDate.toString().replace(/[\-]/g, ""); // 2014.01.02 요청으로 수정(-추가)
		
		if (sDate.length != 8) return false;
		if (this.isDigit(sDate) != true) return false;

		var nMonth  = parseInt(sDate.substring(4,6), 10);
		var nDate  	= parseInt(sDate.substring(6,8), 10);
		
		if (nMonth < 1 || nMonth > 12) return false;
		if (nDate < 1 || nDate > this.getLastDay(sDate)) return false;
		if (sDate < "19000101")
		{
			this.trace("Util.xjs :: isValidDate() 입력날짜는 1900년 01월01일 이상 이어야 합니다. =" + sDate);
			return false;
		}

		return true;
	}
	
	/**
	 * 오늘 날짜를 yyyymmdd형태로 가져오는 함수
	 * @return {String} 로컬시스템의 오늘날짜(yyyymmdd)
	 * @example Util.today()
	 * @memberOf Util
	 */
	Util.today = function()
	{
		var sTrDt = "", oDs = NX.getApp().gdsTrDate;
		if (NX.isFrame() && oDs.rowcount == 1)
		{
			sTrDt = Util.trim(oDs.getColumn(0, "trDt"));
		}
		
		return Util.isValidDate(sTrDt) ? sTrDt : Util.getDateFormatString(new Date(), "yyyyMMdd");
	}

	/**
	 * 현재 일시를 yyyymmddhhmmss형태로 가져오는 함수
	 * @param {String} sType	"ms"기술할 경우 millisecond까지 추가(optional)
	 * @return {String} 로컬시스템의 오늘날짜(yyyymmddhhmmss)
	 * @example Util.toDateTime()
	 * @memberOf Util
	 */
	Util.toDateTime = function(sType)
	{
		var oDate = new Date();
		var sDate = Util.getDateFormatString(oDate, "yyyyMMdd") + oDate.getHours() + oDate.getMinutes() + oDate.getSeconds();
		if (this.isNull(sType) == false && sType.toLowerCase() == "ms")
		{
			sDate += this.lpad(String(oDate.getMilliseconds()), "0", 3);
		}
		
		return sDate;
	}

	/**
	 * yyyy, yyyyMM, yyyyMMdd, yyyyMMddhh, yyyyMMddhhmm, yyyyMMddhhmmss 형태의 String을 Date객체로 만들기.
	 * @param {String} value yyyy ~ yyyyMMddhhmmss형태의 날짜String ( 예 : "20121122" ).
	 * @return {Date} Date Object.
	 */
	Util.strToDate = function(sDt)
	{
		var dt = new Date();
		if (sDt.length == 4) //yyyy
		{
			dt.setFullYear(parseInt(value), 0, 0);
			dt.setHours(0, 0, 0);
			dt.setMilliseconds(0);
		}
		else if (sDt.length == 6) //yyyyMM
		{
			dt.setFullYear(parseInt(sDt.substr(0,4)), parseInt(sDt.substr(4,2))-1, 0);
			dt.setHours(0, 0, 0);
			dt.setMilliseconds(0);
		}
		else if (sDt.length == 8) //yyyyMMdd
		{
			dt.setFullYear(parseInt(sDt.substr(0,4)), parseInt(sDt.substr(4,2))-1, parseInt(sDt.substr(6,2)));
			dt.setHours(0, 0, 0);
			dt.setMilliseconds(0);
		}
		else if (sDt.length == 10) //yyyyMMddhh
		{
			dt.setFullYear(parseInt(sDt.substr(0,4)), parseInt(sDt.substr(4,2))-1, parseInt(sDt.substr(6,2)));
			dt.setHours(parseInt(sDt.substr(8,2)), 0, 0);
			dt.setMilliseconds(0);
		}
		else if (sDt.length == 12)//yyyyMMddhhmm
		{
			dt.setFullYear(parseInt(sDt.substr(0,4)), parseInt(sDt.substr(4,2))-1, parseInt(sDt.substr(6,2)));
			dt.setHours(parseInt(sDt.substr(8,2)), parseInt(sDt.substr(10,2)), 0);
			dt.setMilliseconds(0);
		}
		else if (sDt.length == 14) //yyyyMMddhhmmss
		{
			dt.setFullYear(parseInt(sDt.substr(0,4)), parseInt(sDt.substr(4,2))-1, parseInt(sDt.substr(6,2)));
			dt.setHours(parseInt(sDt.substr(8,2)), parseInt(sDt.substr(10,2)), parseInt(sDt.substr(12,2)));
			dt.setMilliseconds(0);
		}
		return dt;
	}

	/**
	 * 주어진 날짜 개체의 Mask Format 처리된 문자열을 반환합니다.<br>
	 * 요일명칭, 달명칭, 오전오후 명칭 표시 처리는 Util에 정의된 값으로 처리된다.<br>
	 * <pre>
	 * Util.weekName : 요일명칭(Array value), 
	 * Util.weekShortName : 요일축약명칭(Array value),
	 * Util.monthName : 월명칭(Array value),
	 * Util.monthShortName : 월축약 명칭(Array value),
	 * Util.ttName : 오전/오후 명칭(Array value)
	 * </pre>
	 * @param {date} dt Date 개체.
	 * @param {string} sMask mask할 format 문자열.
	 * @return {string} 변환된 문자열.
	 * @example
	 * var dt = Util.strToDate("20130430123412"); // convert Date type from "20130430123412".
	 * trace(Util.getDateFormatString(dt, "yyyy년 MM월 dd일 tt hh시 mm분 ss초")); // output : 2013년 04월 30일 오후 12시 34분 12초
	 * trace(Util.getDateFormatString(dt, "yyyy-MM-dd")); // output : 2013-04-30
	 * trace(Util.getDateFormatString(dt, "yy MM.dd")); // output : 13 04.30
	 * trace(Util.getDateFormatString(dt, "yyyy-MM-dd W \\Week")); // output : 2013-04-30 18 Week
	 * trace(Util.getDateFormatString(dt, "MMMM dddd")); // output : 4월 화요일
	 * @memberOf Util
	 */
	Util.getDateFormatString = function(dt, sMask)
	{
		var arrMask = Util._parseDateMask(sMask),
			arrDt = [], mask, h;
		for ( var i = 0, len = arrMask.length; i < len ; i++ )
		{
			mask = arrMask[i];
			if ( mask > -1 )
			{
				arrDt[arrDt.length] = sMask.charAt(mask);
			}
			else
			{
				switch (mask)
				{
					case "yyyy": arrDt[arrDt.length] = new String(dt.getFullYear()); break;
					case "MMMM": arrDt[arrDt.length] = Util.monthName[dt.getMonth()]; break;
					case "dddd": arrDt[arrDt.length] = Util.weekName[dt.getDay()]; break;
					case "MMM": arrDt[arrDt.length] = Util.monthShortName[dt.getMonth()]; break;
					case "ddd": arrDt[arrDt.length] = Util.weekShortName[dt.getDay()]; break;
					case "sss": arrDt[arrDt.length] = new String(dt.getMilliseconds()).padLeft(3,'0'); break;
					case "yy": arrDt[arrDt.length] = new String(dt.getFullYear() % 1000).padLeft(2,'0'); break;
					case "MM": arrDt[arrDt.length] = new String(dt.getMonth() + 1).padLeft(2,'0'); break;
					case "WW": arrDt[arrDt.length] = new String(getWeekNumber(dt)).padLeft(2,'0'); break;
					case "dd": arrDt[arrDt.length] = new String(dt.getDate()).padLeft(2,'0'); break;
					case "HH": arrDt[arrDt.length] = new String(dt.getHours()).padLeft(2,'0'); break;
					case "hh": arrDt[arrDt.length] = new String(((h = dt.getHours() % 12) ? h : 12)).padLeft(2,'0'); break;
					case "mm": arrDt[arrDt.length] = new String(dt.getMinutes()).padLeft(2,'0'); break;
					case "ss": arrDt[arrDt.length] = new String(dt.getSeconds()).padLeft(2,'0'); break;
					case "tt": arrDt[arrDt.length] = dt.getHours() < 12 ? Util.ttName[0] : Util.ttName[1]; break;
					case "M": arrDt[arrDt.length] = new String(dt.getMonth() + 1); break;
					case "d": arrDt[arrDt.length] = new String(dt.getDate()); break;
					case "H": arrDt[arrDt.length] = new String(dt.getHours()); break;
					case "h": arrDt[arrDt.length] = new String(((h = dt.getHours() % 12) ? h : 12)); break;
					case "m": arrDt[arrDt.length] = new String(dt.getMinutes()); break;
					case "s": arrDt[arrDt.length] = new String(dt.getSeconds()); break;
					case "W": arrDt[arrDt.length] = new String(Util.getWeekOfYear(dt)); break;
				}
			}
		}
		return arrDt.join("");
	}
	
	
	/**
	 * 숫자형 문자에서 부호, 소수점, 정수부, 소수부 분리.
	 * @private
	 * @param {string} sText 숫자형 문자.
	 * @return {array} 분리 정보
	 * @memberOf Util
	 */
	Util._numberSplit = function(sText) 
	{
		// 부호 분리.
		var nBegin = 0, nSign;
		if ((nBegin = sText.indexOf('+')) >= 0) 
		{
			nSign = +1;
			nBegin = 1;
		}
		else if((nBegin = sText.indexOf('-')) >= 0) 
		{
			nSign = -1;
			nBegin = 1;
		}
		else 
		{
			nSign = 0;
			nBegin = 0;
		}

		var nPoint = sText.indexOf(Util.point ,nBegin),
			sNumber = "", bPoint, sDecimal = "";
		if (nPoint < 0)
		{
			sNumber = sText.substr(nBegin);
			bPoint = false;
		}
		else 
		{
			sNumber = sText.substr(nBegin, nPoint - nBegin);
			sDecimal = sText.substr(nPoint + 1);
			bPoint = true;
		}
		return [nSign, bPoint, sNumber, sDecimal];
	}
	
	/**
	 * mask 제거.
	 * @private
	 * @param {string} strText 숫자형 문자.
	 * @return {string} 변환된 문자열
	 * @memberOf Util
	 */	
	Util._removeMask = function(str) 
	{
		str = str.trim();
		var ntxtLen = str.length,
			i,
			pointVal = Util.point,
			separatorVal = Util.separator;
			bPoint = false, // 소숫점은 1개만 인정.
			bInside = false, // 부호는 숫자가 나오기 전에만 인정.
			buf = [];
		for(i = 0 ; i < ntxtLen ; i++ ) 
		{
			var c = str.charAt(i);
			if( ( c == '+' || c == '-') && ( bInside === false) ) 
			{
				// 부호는 숫자가 나오기 전에만 인정.
				buf.push(c);
				bInside = true;
			}
			else if( nexacro.isNumeric(c) ) 
			{
				// 숫자인경우 인정.
				buf.push(c);
				bInside = true;
			}
			else if( c == pointVal && bPoint === false ) 
			{
				// 소숫점은 1회만 인정.
				buf.push(c);
				bPoint = true;
				bInside = true;
			}
			else if( c != separatorVal ) 
			{
				return "";
			}
		}
		return buf.join("");
	}
	
	/**
	 * 숫자 단위 적용.
	 * @private
	 * @param {string} sNumber 숫자형 문자.
	 * @return {string} 변환된 문자열
	 * @memberOf Util
	 */
	Util._applyComma = function(sNumber) 
	{
		var grouping = Util.separatorGrouping;
		var thousands_sep = Util.separator;
		if( thousands_sep.length > 0 )
		{
			var	dec_buf = sNumber.split(""),
				dec_size = sNumber.length,
				out_size = (thousands_sep.length + 1) * sNumber.length,
				out_buf = [],
				cur_group = 0, d_size = dec_size,
				endpos = out_size,
				groupingIdx = 0,
				g;

			grouping = grouping.split("");

			while (grouping[groupingIdx] && d_size > 0 ) 
			{	
				g = grouping[groupingIdx];
				if ( g == "\\" ) 
				{
					groupingIdx++;
					g = parseInt(grouping[groupingIdx]);
				}
				if (g > 0 ) 
				{
					cur_group = g;
					while (g-- > 0 && d_size > 0)
						out_buf[--endpos] = dec_buf[--d_size];
					if (d_size > 0)
						out_buf[--endpos] = thousands_sep;
				}
				else if (g == 0 && d_size > cur_group) 
				{
					g = cur_group;
					while (g-- > 0)
						out_buf[--endpos] = dec_buf[--d_size];
					if (d_size > 0)
						out_buf[--endpos] = thousands_sep;
				}
				else if (g == 0 && d_size <= cur_group && d_size > 0 ) 
				{
					g = d_size;
					while (g-- > 0)
						out_buf[--endpos] = dec_buf[--d_size];
				}
				else 
				{
					break;
				}
			}
			return out_buf.slice(endpos,out_size + endpos).join("");
		}
		return sNumber;
	}
	
	/**
	 * 숫자형 변환
	 * @private
	 * @param {string} sValue 숫자형 문자.
	 * @param {boolean} bTrim 공백제거 여부.
	 * @return {string} 변환된 문자열.
	 * @memberOf Util
	 */	
	Util._normalizeValue = function(sValue, bTrim) 
	{
		if (sValue.length<=0) return sValue;
		if ( bTrim === undefined ) bTrim = true;
			
		// 좌우 공백 제거, 마스크 제거.
		sValue = Util._removeMask(sValue);
		// 정규형식으로 만듬.
		if( sValue.charAt( sValue.length -1 ) == Util.point )
			sValue = sValue + "0";

		if(bTrim) 
		{
			// 0 Trim 하기 전에 부호 있는 경우 주의.
			var bSign = ( sValue.charAt(0) == '-' ) ? 1 : 0;
			var pointVal = Util.point;

			// 0000~~ 에 대해서 첫 자리 0을 삭제
			// -0000~~ 에 대해서 부호 뒷 자리 0을 삭제.
			while( sValue.charAt( 0+bSign ) == '0' 
					&& sValue.charAt( 1+bSign ) != pointVal
					&& sValue.length != (1+bSign) ) 
			{
					sValue = sValue.substring(0, 0+bSign) + sValue.substr(0+bSign+1, sValue.length);
			}
			// .~~0000에 대해서 0을 Trim
			var nPoint = sValue.indexOf(pointVal);
			if( nPoint >= 0 ) 
			{
				var i;
				for( i = sValue.length - 1 ; i > nPoint+1 ; i -- ) 
				{
					if( sValue.charAt( i ) != '0' )
							break;
				}
				sValue = sValue.substring(0, i + 1 );
			}
		}

		// 부호에 대해 정규형으로.
		if( sValue.charAt(0) == '+' ) 
		{
			sValue = sValue.substr(1);
		}
		else if( sValue.length <= 0 || parseFloat(sValue) == 0.0 ) 
		{
			// 값이 0.0인경우 부호 제거.
			if( sValue.charAt(0) == '-' )
				sValue = sValue.substr(1);
		}
		return sValue;
	}
	
	/**
	 * mask format 변환 정보 반환.
	 * @private
	 * @param {string} sMask mask할 format 문자열.
	 * @return {array} mask format 변환 정보
	 * @memberOf Util
	 */	
	Util._parseNumberMask = function(sMask)
	{
		var res = Util._numberMaskCache[sMask];
		if ( res ) return res;
	
		var dispComma = false,
			nMin = 0,
			nMax = 0,
			nDecimalMin = -1,
			nDecimalMax = 0;

		sMask = Util.toString(sMask).ltrim();

		if (sMask.length <= 0 ) 
		{
			return [dispComma, nMin, nMax, nDecimalMin, nDecimalMax];
		}

		nDecimalMax = 0;
		nDecimalMin = 0;
		dispComma = (sMask.indexOf(",") >= 0);

		var c,
			bFindPoint = false;

		for( var i = 0, n = sMask.length; i < n; i++ ) 
		{
			c = sMask.charAt(i);
			if ( c == '.' )
			{
				bFindPoint = true;
			}
			else if ( c == '#' || c == '0' || c == '9' || c == ',' ) 
			{
				if ( bFindPoint ) 
				{
					if ( c == '0' ) 
					{
						nDecimalMax++;
						nDecimalMin = nDecimalMax;
					}
					else
					{
						nDecimalMax++;
					}
				}
				else 
				{
					if ( c == '0' )
					{
						nMin++;
					}
					else if ( nMin > 0)
					{
						nMin++;
					}
					nMax++;
				}
			}
		}// end of for.
		
		res = [dispComma, nMin, nMax, nDecimalMin, nDecimalMax];
		Util._numberMaskCache[sMask] = res;
		return res;
	}
		
	/**
	 * 주어진 숫자 형식값에 Mask Format 처리된 문자열을 반환합니다.
	 * @param {string|number} sNum 숫자형식 값
	 * @param {string} sMask mask할 format 문자열.
	 * @return {string} 변환된 문자열.
	 * @example
	 * var val = 1234.567;
	 * var result = Util.getNumberFormatString(val, "99.99");
	 * trace(result); // output : 1234.56
	 * result = Util.getNumberFormatString(val, "9900.0099");
	 * trace(result); // output : 1234.567
	 * result = Util.getNumberFormatString(val, "9,999.9");
	 * trace(result); // output : 1,234.5
	 *
	 * val = 1.2;
	 * result = Util.getNumberFormatString(val, "99.99");
	 * trace(result); // output : 1.2
	 * result = Util.getNumberFormatString(val, "9900.0099");
	 * trace(result); // output : 01.20
	 * result = Util.getNumberFormatString(val, "9,999.9");
	 * trace(result); // output : 1.2
	 * @memberOf Util
	 */	
 	Util.getNumberFormatString = function(nNum, sMask)
 	{
		var sText = nNum + "";
		sText = Util._normalizeValue(sText, true);

		var nDecimalLen = 0;		// 소수부 길이.
		var nIntegerLen = 0;		// 정수부 길이.

		// Split : value를 정수부, 소수부로 나누고 소수점 유무, 양음부호부 까지 판별한다.
		var ret = Util._numberSplit(sText),
			nSign = ret[0],
			bPoint = ret[1],
			sNumber = ret[2],
			sDecimal = ret[3];

		// 각 부분의 길이구함.
		nIntegerLen = sNumber.length;
		nDecimalLen = sDecimal ? sDecimal.length : 0;

		var maskInfo = Util._parseNumberMask(sMask),
			dispComma = maskInfo[0],
			nMin = maskInfo[1],
			nMax = maskInfo[2],
			nDecimalMin = maskInfo[3],
			nDecimalMax = maskInfo[4];

		if (nMin > nIntegerLen) 
		{
			var tmpStr = "";
			for(var i=0, n =  nMin - nIntegerLen; i < n ; i++) 
			{
				tmpStr += "0";
			}
			sNumber = tmpStr + sNumber;
		}

		if (nDecimalMin > nDecimalLen) 
		{
			var tmpStr = "";
			for(var i=0, n = nDecimalMin - nDecimalLen; i < n ; i++) 
			{
				tmpStr += "0";
			}
			sDecimal = sDecimal + tmpStr;
		}
		else if (nDecimalMax != -1 && nDecimalMax < nDecimalLen) 
		{
			sDecimal = sDecimal.substring(0, nDecimalMax) + sDecimal.substr(nDecimalLen, sDecimal.length);
		}
		// 정수부분에 Comma적용.
		if (dispComma) sNumber = Util._applyComma(sNumber);

		if (nSign < 0) sText = "-";
		else if (nSign > 0) sText = "+";
		else sText = "";
		
		// 정수부.
		sText += sNumber;
		
		// 소수부.
		if (sDecimal.length > 0) 
		{
			sText += Util.point;
			sText += sDecimal;
		}
		return sText;
 	}		
	
	/**
	 * 아규먼트로 받은 날짜문자열의 요일에 해당하는 index를 가져오는 함수
	 * @param {String} sDate	문자열(날짜)
	 * @return {Number} 요일index(일:0,월:1,화:2,수:3,목:4,금:5,토:6)
	 * @example Util.getDay("2011620")
	 * @memberOf Util
	 */
	Util.getDay = function(sDate)
	{
		var oDate = Util.isDate(sDate) ? sDate : ((Util.isNull(sDate) == false && sDate.length >= 8) ? Util.strToDate(sDate) : new Date());
		return oDate.getDay();
	}
	
	/**
	 * 날짜의 휴일여부(토,일요일)를 반환하는 함수
	 * @param {String} sDate	문자열(날짜)
	 * @example Util.isHoliday("2011620")
	 * @memberOf Util
	 */
	Util.isHoliday = function(sDate)
	{
		var oDs = NX.getApp().gdsTrDate;
		if (oDs)
		{
			var nIdx = oDs.findRow("trDt", sDate);
			if (nIdx >= 0)
			{
				var sHolidayYn = oDs.getColumn(nIdx, "holidayYn");
				return sHolidayYn == "Y";
			}
			else
			{
				var nDay = Util.getDay(sDate);
				return nDay == 0 || nDay == 6; // (일:0, 토:6)
			}
		}
		else
		{
			var nDay = Util.getDay(sDate);
			return nDay == 0 || nDay == 6; // (일:0, 토:6)
		}
	}

	/**
	 * 아규먼트로 받은 nOffset만큼 날짜에 가감하여 문자열로 반환
	 * @param {String} sDate	문자열(날짜)
	 * @param {Number} nOffSet	가감할offset
	 * @return {String} 반환문자열(날짜)
	 * @example Util.addDate("2010620", 20)
	 * @memberOf Util
	 */
	Util.addDate = function(sDate, nOffSet)
	{
		var oDate;
		if (Util.isDate(sDate))
		{
			oDate = new Date();
			oDate.setFullYear(oDate.getFullYear(), oDate.getMonth(), oDate.getDate() + nOffSet);
			oDate.setHours(oDate.getHours(), oDate.getMinutes(), oDate.getSeconds());
			oDate.setMilliseconds(oDate.getMilliseconds());
			return oDate;
		}
		else
		{
			oDate = Util.strToDate(sDate);
			var oNewDate = new Date(oDate.addDate(nOffSet));
			return Util.getDateFormatString(oNewDate, "yyyyMMdd");
		}
	}

	/**
	 * 아규먼트로 받은 nOffset만큼 월에 가감하여 문자열로 반환
	 * @param {String} sDate	문자열(날짜)
	 * @param {Number} nOffSet	가감할offset
	 * @return {String} 반환문자열(날짜)
	 * @example Util.addMonth("2010620", 1)
	 * @memberOf Util
	 */
	Util.addMonth = function(sDate, nOffSet)
	{
		var nDate = parseInt(sDate.substr(6, 2));
		var oDate = new Date();
			oDate.setFullYear(parseInt(sDate.substr(0, 4)), parseInt(sDate.substr(4, 2)-1) + nOffSet, 1);
			oDate.setDate(nDate == Util.getLastDay(sDate) ? Util.getLastDay(oDate) : Math.min(nDate, Util.getLastDay(oDate)));
		return Util.getDateFormatString(oDate, "yyyyMMdd");
	}

	/**
	 * 아규먼트로 받은 날짜문자열 일수차이를 구하는 함수
	 * @param {String} sFromDate	문자열(날짜)
	 * @param {String} sToDate	문자열(날짜)
	 * @return {Number} 일수차이
	 * @example Util.diffDate("20100620", "20100831")
	 * @memberOf Util
	 */
	Util.diffDate = function(sFromDate, sToDate)
	{
		if (this.isNull(sFromDate) || this.isNull(sToDate))	return NaN;

		var oFromDate	= Util.strToDate(sFromDate);
		var oToDate		= Util.strToDate(sToDate);

		return parseInt((oToDate - oFromDate) / (1000 * 60 * 60 * 24), 10);
	}

	/**
	 * 아규먼트로 받은 날짜문자열 월차이를 구하는 함수
	 * @param {String} sFromDate	문자열(날짜)
	 * @param {String} sToDate	문자열(날짜)
	 * @return {Number} 월차이
	 * @example Util.diffMonth("2010620", "20100831")
	 * @memberOf Util
	 */
	Util.diffMonth = function(sFromDate, sToDate)
	{
		if (this.isNull(sFromDate) || this.isNull(sToDate))	return NaN;

		var nFromMonth	= parseInt(sFromDate.substr(0,4), 10)*12 + parseInt(sFromDate.substr(4,2), 10);
		var nToMonth	= parseInt(sToDate.substr(0,4), 10)*12 + parseInt(sToDate.substr(4,2), 10);

		return (nToMonth - nFromMonth);
	}

	/**
	 * 아규먼트로 받은 문자열의 윤년여부를 반환
	 * @param {String} sDate	문자열(날짜)
	 * @return {Boolean} true/false
	 * @example Util.isLeapYear("2010620")
	 * @memberOf Util
	 */
	Util.isLeapYear = function(sDate)
	{
		if (this.isNull(sDate)) return false;
		var nYear = parseInt(sDate.substring(0,4), 10);
		return (((nYear % 4 === 0) && (nYear % 100 !== 0)) || (nYear % 400 === 0));
	}

	/**
	 * 아규먼트로 받은 문자열의 01일의 날짜를 반환
	 * @param {String} sDate	문자열(날짜)
	 * @return {String} 해당월의 01일(yyyyMMdd)
	 * @example Util.getFirstDate("20100620") -> 20100601반환
	 * @memberOf Util
	 */
	Util.getFirstDate = function(sDate)
	{
		if (this.isNull(sDate)) return "";
		return sDate.substr(0,6) + "01";
	}
	
	/**
	 * 아규먼트로 받은 문자열의 마지막 날짜를 반환
	 * @param {String} sDate	문자열(날짜)
	 * @return {String} 해당월의 마지막 날짜(yyyyMMdd)
	 * @example Util.getLastDate("2010620")
	 * @memberOf Util
	 */
	Util.getLastDate = function(sDate)
	{
		if (this.isNull(sDate)) return "";
		var nLastDate = this.getLastDay(sDate);
		return sDate.substr(0,6) + nLastDate.toString();
	}

	/**
	 * 아규먼트로 받은 문자열의 마지막 일자를 반환
	 * @param {String} sDate	문자열(yyyyMMdd)
	 * @return {String} 해당월의 마지막 일자(dd)
	 * @example Util.getLastDay("2010620")
	 * @memberOf Util
	 */
	Util.getLastDay = function(sDate)
	{
		sDate = Util.isDate(sDate) ? Util.getDateFormatString(sDate, "yyyyMMdd") : Util.trim(sDate);
		if (Util.isNull(sDate)) return;
		var nMonth = parseInt(sDate.substr(4,2))-1;
		return [31, (Util.isLeapYear(sDate) ? 29 : 28), 31,30,31,30,31,31,30,31,30,31][nMonth];
	}
	
	
	/**
	 * yyyyMMdd형태의 날짜를 입력하면 해당연도의 날짜에 해당하는 주차반환.
	 * @param {date|string} date Date Object 또는 날짜형 스트링.
	 * @return {number} 주차에 해당하는 숫자  ( 예 : 10 ).
	 * @example
	 * var dt = Util.strToDate("20130331"); // convert Date type from "20130331".
	 * var week = Util.getWeekOfYear(dt);
	 * trace(week); // output : 14
	 * var dtstr = "20130331";
	 * var week = Util.getWeekOfYear(dt);
	 * trace(week); // output : 14
	 * @memberOf Util
	 */
	Util.getWeekOfYear = function(date)
	{
		if (Util.isString(date))
		{
			date = Util.strToDate(date);
		}
		if (!Util.isDate(date))
		{
			return -1;
		}
		
		var onejan = new Date();
			onejan.setYear(date.getFullYear());
			onejan.setMonth(0);
			onejan.setDate(1);
		
		return Math.ceil((((date - onejan) / 86400000) + onejan.getDay()+1)/7);
	}
	
	/**
	 * mask format 변환 정보 반환.
	 * @private
	 * @param {string} sMask mask할 format 문자열.
	 * @return {array} mask format 변환 정보
	 * @memberOf Util
	 */		
	Util._parseDateMask = function(sMask)
	{
		var res = Util._dateMaskCache[sMask];
		if ( res ) return res;

		var arrMask = [], tokenStr, seq = 0,
			bEscape = false, bQuote = false,
			maskArr = sMask.split(""),
			tmpStr;

		for ( var i = 0, len = maskArr.length ; i < len ; )
		{
			tokenStr = maskArr[i];
			//trace(i + "===>" + tokenStr);
			if( bEscape == false && tokenStr == "'" ) 
			{ // Mask가 Quotation이 시작될 경우.
				if( bQuote == false )
					bQuote = true;
				else
					bQuote = false;
				i++;
				continue;
			}
			if( bEscape == false && tokenStr == "\\" && !bQuote ) 
			{ // Mask에서 Escape에 진입할 경우.
				bEscape = true;
				i++;
				continue;
			}
			else if ( bEscape ) 
			{ // Mask에서 Escape를 사용할 경우.
				//trace(i + "(EEE)===>" + tokenStr);
				arrMask[seq] = i;
				seq++;
				bEscape = false;
			}
			else if( bQuote == false ) 
			{// Mask에서 Quotation 밖의 글자에 대해.
				tmpStr = sMask.substr(i, 4);
				if ( tmpStr == "yyyy" || tmpStr == "MMMM" || tmpStr == "dddd" ) //yyyy, MMMM, dddd
				{
					arrMask[seq] = tmpStr;
					i += 4;
					seq++;
					continue;
				}
				tmpStr = sMask.substr(i, 3);
				if ( tmpStr == "MMM" || tmpStr == "ddd" || tmpStr == "sss" ) //MMM, ddd, sss
				{
					arrMask[seq] = tmpStr;
					i += 3;
					seq++;
					continue;
				}
				tmpStr = sMask.substr(i, 2);
				if ( tmpStr == "yy" || tmpStr == "MM" || tmpStr == "dd" ||
					 tmpStr == "HH" || tmpStr == "mm" || tmpStr == "ss" ||
					 tmpStr == "hh" || tmpStr == "tt" || tmpStr == "tt" ) // yy, MM, dd, HH, mm , ss, tt, WW
				{
					arrMask[seq] = tmpStr;
					i += 2;
					seq++;
					continue;
				}

				if ( tokenStr == "M" || tokenStr == "d" || tokenStr == "H" ||
					 tokenStr == "h" || tokenStr == "m" || tokenStr == "s" || tokenStr == "W" ) // M, d, H, h, m, s, W
				{
					arrMask[seq] = tokenStr;
					seq++;
				}
				else
				{
					arrMask[seq] = i;
					seq++;
				}
			}
			i++;
		}
		
		Util._dateMaskCache[sMask] = arrMask;
		
		return arrMask;
	}


	/*********************************************************************************************************
		Date 관련 스크립트 Function (End) 
	*********************************************************************************************************/
	
	/**
	 * Email 적합여부 확인
	 * /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
	 * /^(([^<>()[]\.,;:s@"]+(.[^<>()[]\.,;:s@"]+)*)|(".+"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))$/
	 * @param {String} 		sValue Email
	 * @return {Boolean} 	true/false
	 * @example Util.isEmail("oju@yahoo.co.kr")
	 * @memberOf Util
	 */
	Util.isEmail = function(sValue)
	{
		var oRegExp = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
		return oRegExp.test(sValue);
	}

	/**
	 * 함수 존재 유무를 반환
	 * @param {String} sFunc 	함수명
	 * @return {Boolean} true/false
	 * @example Util.isValidFunc(oContainer, "isNull")
	 * @memberOf Util
	 */
	Util.isValidFunc = function(oContainer, sFunc)
	{
		return NX.Analyzer._typeof(oContainer[sFunc]) == "function";
	}

	/**
	* 공통 trace함수
	* @param {String} sMsg trace내용
	* @example Util.trace("테스트..");
	* @memberOf Util
	*/
	Util.trace = function(sMsg)
	{
		// for exception
		if (arguments.length == 2)
		{
			var o = arguments[0];
			var e = arguments[1];
			NX.getApp().trace(o.name + " [" + e.eventid + "] : " + e.message);
		}
		else
		{
			NX.getApp().trace(sMsg);
		}
	}

	/**
	 * Object의 type을 문자열로 얻어온다.
	 * @param {Dataset} obj		type을 얻어올 Object
	 * @return {String} object type
	 * @example Util.getObjType(obj)
	 * @memberOf Util
	 */
	Util.getObjType = function(obj)
	{
		if (this.isNull(obj))	return "";

		var sType = obj.toString().valueOf();

		if ( sType.substr(1,6).toLowerCase() == "object") {
		
			var startIdx = sType.indexOf(" ");
			var endIdx = sType.indexOf("]");

			return sType.substring(startIdx+1, endIdx);
		}
		
		return "";
	}

	Util.initDsSpliceText = function(objDs, sTextCol, sTargerID)
	{
		objDs.enableevent	= false;
		for (var i=0; i<objDs.getRowCount(); i++)
		{
			var text = this.trim(objDs.getColumn(i, sTextCol));
			var code = this.getSpliceTextE(text);
			objDs.setColumn(i, sTargerID, code);
		}
		objDs.enableevent	= true;
	}

	Util.getSpliceTextK = function(sInput)
	{
		// 한글 자소를 분리하여 리턴한다.
		var aFirst = [12593,12594,12596,12599,12600,12601,12609,12610,12611,12613,12614,12615,12616,12617,12618,12619,12620,12621,12622];
		var aSecond = [12623,12624,12625,12626,12627,12628,12629,12630,12631,12632,12633,12634,12635,12636,12637,12638,12639,12640,12641,12642,12643];
		var aThird = [0,12593,12594,12595,12596,12597,12598,12599,12601,12602,12603,12604,12605,12606,12607,12608,12609,12610,12612,12613,12614,12615,12616,12618,12619,12620,12621,12622];

		var sOut = "";

		for(var i=0; i< sInput.length; i++)
		{
			var nCode = sInput.charCodeAt(i);

			if (nCode >= 44032 && nCode <= 55203)
			{
				var nFirst = Math.floor((nCode - 44032) / 588);
				 sOut += String.fromCharCode(arrFirst[nFirst]);

				var nSecond = Math.floor(((nCode - 44032) % 588) / 28);
				 sOut += String.fromCharCode(arrSecond[nSecond]);

				var nThird = Math.floor((nCode - 44032) % 28) ;
				if (nThird > 0)
					 sOut += String.fromCharCode(arrThird[nThird]);
			}
			else
			{
				 sOut += String.fromCharCode(nCode);
			}
		}
		return sOut;
	}

	Util.getSpliceTextE = function(sInput)
	{
		// 한글 자소를 분리하고 키보드에 매치되는 영문으로 리턴한다.
		var aFirstE	= ["r","R","s","e","E","f","a","q","Q","t","T","d","w","W","c","z","x","v","g"];
		var aSecondE	= ["k","o","i","O","j","p","u","P","h","hk","ho","hl","y","n","nj","np","nl","b","m","ml","l"];
		var aThirdE	= ["","r","R","rt","s","sw","sg","e","f","fr","fa","fq","ft","fx","fv","fg","a","q","qt","t","T","d","w","c","z","x","v","g"];
		var aAllE	= ["r","R","rt","s","sw","sg","e","E","f","fr","fa","fq","ft","fx","fv","fg","a","q","Q","qt","t","T","d","w","W","c","z","x","v","g","k","o","i","O","j","p","u","P","h","hk","ho","hl","y","n","nj","np","nl","b","m","ml","l"];
		var sOutE = "";

		for(var i=0; i< sInput.length; i++)
		{
			var nCode = sInput.charCodeAt(i);

			if (nCode >= 44032 && nCode <= 55203)
			{
				var nFirst = Math.floor((nCode - 44032) / 588);
				 sOutE += aFirstE[nFirst];

				var nSecond = Math.floor(((nCode - 44032) % 588) / 28) ;
				 sOutE += aSecondE[nSecond];

				var nThird = Math.floor((nCode - 44032) % 28) ;
				if (nThird > 0)
				{
					 sOutE += aThirdE[nThird];
				}
			}
			else if(nCode >= 12593 && nCode <= 12643)
			{
				 sOutE += aAllE[nCode-12593];
			}
			else
			{
				 sOutE += String.fromCharCode(nCode);
			}
		}
		return sOutE;
	}
	
	/**
	 * 파일Path의 파일확장자를 반환
	 * @param {String} sPath 파일Path
	 * @return N/A
	 * @example Util.getFileExt("C:\fakepath\test.pptx")
	 * @memberOf Util
	 */
	Util.getFileExt = function(sPath)
	{
		return sPath.substring(sPath.lastIndexOf('.')+1); 
	}

	/**
	 * 브라우저에서 url를 호출한다.
	 * @param {String} sUrl 웹주소
	 * @return N/A
	 * @example Util.execBrowser("http://www.naver.com")
	 * @memberOf Util
	 */
	Util.execBrowser = function(sUrl)
	{
		system.execBrowser(sUrl);
	}
	
	/**
	 * 특정사이트의 주소를 반환
	 * @private
	 * @param {String} sSite 사이트구분
	 * @return N/A
	 * @example Util._getRelUrl("portal")
	 * @memberOf Util
	 */
	Util._getRelUrl = function(sSite)
	{
		return Util.trim(NX.getApp()._gdsRelUrl.lookup("site", sSite, "url"));
	}
	
	Util.toQueryStr = function(value)
	{
	    var rtn = "";
	    
	    for(p in value)
	    {
	        rtn += (Util.isNull(rtn)) ? p+"="+value[p] : "&"+p+"="+value[p];
	    }
	    
	    return rtn;    
	}
	
	/**
	 * 주어진 주소로 POST요청 수행
	 * @param {Object} pThis 실행Context(this)
	 * @param {Object} o 호출관련정보(property : name, url, params, 위치관련(left,top,width,height,right,bottom))
	 *                 name : 대상 WebBrowser컴포넌트명(동적으로 webbrowser를 생성하지 않음)
	 *				   url : POST요청을 호출할 주소
	 *				   params : POST요청시 전달할 parameters ex){key:value,key1:value1} 객체
	 * @return N/A
	 * @example Util.execBrowserWithPost(this, {url:"http://www.naver.com",params:{key:value, key1:value1}})
	 * @memberOf Util
	 */
	Util.execBrowserWithPost = function(pThis, o)
	{
		if (!o) o = {};
		
		var nLeft 	= o.left 	|| 0;
		var nTop 	= o.top 	|| 0;
		var nWidth 	= o.width 	|| 0;
		var nHeight = o.height 	|| 0;
		var nRight 	= o.right 	|| null;
		var nBottom = o.bottom 	|| null;
		var sWbNm 	= o.name 	|| NX.getUniqueId("_wbOpenWithPost_", pThis);
		var sUrl 	= o.url		|| "";
		var oParam 	= o.params	|| "";
		var sTarget = o.name ? "_self" : (o.target || "_blank");
		var bPopup  = o.popup   || false;
		
		
		// for WebBrowser creation
		o.component = "WebBrowser";
		
		var oWB = pThis.components[sWbNm];
		if (o.name && !oWB)
		{
			Util.trace("Util.js :: execBrowserWithPost() => not found WebBrowser Component : " + sWbNm);
			return;
		}
		
		if (NX.isruntime)
		{
			if (oWB)
			{
				pThis.removeChild(sWbNm);
				oWB.destroy();
				oWB = null;
			}
			oWB = NX.Comps.getComponent(pThis, o);
			oWB.set_url("about:blank");
			
			var sHtml = "";
			sHtml +='<html>\n'; 
			sHtml +='<title>execBrowserWithPost';
			sHtml +='</title>\n';
			sHtml +='<head>\n';
			sHtml +='<meta charset="UTF-8">\n';
			sHtml +='<meta http-equiv="X-UA-Compatible" content="IE=edge"/>\n';
			sHtml +='</head>\n';
			sHtml +='<body>\n';
			sHtml +='<form id="postform" name="postform" action="' + sUrl + '" method="post" target="' + sTarget + '" accept-charset="utf-8">\n';
			
			for (var prop in oParam)
			{
				sHtml +='	<input type="hidden" id="' + prop + '" name="' + prop + '" value="' + Util.trim(oParam[prop]) + '">\n';
			}
			
//			sHtml +='	<input type="hidden" id="bb" name="bb" value="PW">';
			sHtml +='</form>\n';
			sHtml +='<script type="text/javascript">\n';
			sHtml +='	document.title = "testWeb";\n';
			sHtml +='	document.postform.submit();\n';
			sHtml +='</script>\n';
			sHtml +='</body>\n';
			sHtml +='</html>';
		
			oWB.getProperty("document").callMethod("Write", sHtml);
	//		oWB.getProperty("document").callMethod("Close");	
		}
		else
		{
			if (oWB)
			{
				//oWB.set_url("about:blank");
			}
			else
			{
				oWB = NX.Comps.getComponent(pThis, o);
				oWB.set_width(0);
				oWB.set_height(0);				
			}
			
			if (nexacro.Browser == "IE") // IE8 (미지원함)	
			{
				if(bPopup)
				{
					window.open(sUrl + "?" + Util.toQueryStr(oParam),sWbNm,"'width="+nWidth+",height="+nHeight+"'");
				}
				else
				{
					oWB.set_url(sUrl + "?" + Util.toQueryStr(oParam)); // 하위버전 호환성유지하려면 WebBrower에서 처리하는 방법으로 jsp/nexa.if.html	
				}
								
			}
			else
			{
				if(sWbNm.indexOf("_wbOpenWithPost_") > -1)
				{
					// html5 : add new webbrowser component to initialize web page.
					var iFrame = document.getElementById(oWB._ifrm_elem._object_id);
					var iFrameDoc;
					var iFrameBody;

					if (iFrame.contentDocument)
					{
						iFrameDoc 	= iFrame.contentDocument;
						iFrameBody 	= iFrameDoc.getElementsByTagName('body')[0];
					}
					else if (iFrame.contentWindow)
					{
						iFrameDoc 	= iFrame.contentWindow.document;
						iFrameBody 	= iFrameDoc.getElementsByTagName('body')[0];
					}
					
					if (!iFrameBody)
					{
						iFrameBody = iFrameDoc.createElement("body");
						iFrameDoc.appendChild(iFrameBody);   
					}
					
					var form = iFrameDoc.getElementsByTagName("form")[0];
					
					if (form)
					{
						iFrameBody.removeChild(form);
					}
					
					
					form = iFrameDoc.createElement("form");
					form.id 	= "postform";
					form.name 	= "postform";
					form.action = sUrl;
					form.target = sTarget;
					form.method = "post";
						
					iFrameBody.appendChild(form);
	
					if(bPopup)
					{
						window.open("",sWbNm,"'width="+nWidth+",height="+nHeight+"'");
						form.target = sWbNm;
					}
					
					var sValue;
					for (var prop in oParam)
					{
						sValue = Util.trim(oParam[prop]);
						if (prop && sValue)
						{
							var input = iFrameDoc.createElement("input");
								input.id 	= prop;
								input.name 	= prop;
								input.type 	= "hidden";			
								input.value	= sValue; 
							form.appendChild(input);   
						}
					}
	
					if (o.crossdomain === true) // for Chrome issue
					{
						try
						{
							var script = iFrameDoc.createElement('script');
								script.type 	= 'text/javascript';
								script.charset 	= 'utf-8';
								script.defer 	= true;
								script.async 	= true;
								script.onload 	= function(){}
							var sDomain = "document.domain = \"" + document.domain + "\";";
							script.text = [sDomain].join('');
						
							iFrameBody.appendChild(script);	
						}
						catch (e){Util.trace(e.message);}
					}
					
					if (iFrameDoc.getElementById('postform'))
					{
						iFrameDoc.getElementById('postform').submit();
					}					
				}
				else
				{				
					if(bPopup)
					{
						window.open(sUrl + "?" + Util.toQueryStr(oParam),sWbNm,"'width="+nWidth+",height="+nHeight+"'");
					}
					else
					{
						oWB.set_url(sUrl + "?" + Util.toQueryStr(oParam));	
					}
					 
				}
			}
		}

	}

	/**
	 * Dataset(gdsMessage)에서 공통 메시지내용 리턴하는 함수
	 * @private
	 * @param {String} sCode	메시지코드 (필수)
	 * @return {String} 메시지내용
	 * @memberOf Util
	 */
	Util._getMsgTxt = function(sCode, oCfg)
	{
		if (oCfg && oCfg.restrict === true) return sCode;
		var oMsgDs = NX.getApp().gdsMessage;
		var nRow = oMsgDs.findRow(Util._MSG_ID_COL, sCode.toUpperCase());
		return nRow < 0 ? sCode : Util.trim(oMsgDs.getColumn(nRow, Util._MSG_CNTN_COL)); // String.fromCharCode(13)
	}

	/**
	 * Dataset(gdsMessage)에서 공통 메시지내용 리턴하는 함수(개행은 \n문자열을 사용해서 처리하기로함 2018.03.02)
	 * @param {String} sCode	메시지코드 (필수)
	 * @return {String} 메시지내용
	 * @example Util.getComMsg("W210", ["테스트"]);
	 * @memberOf Util
	 */
	Util.getComMsg = function(sCode, aAlterMsg, oCfg)
	{
		var sMsg = this._getMsgTxt(sCode, oCfg).replace(/\\n/g, String.fromCharCode(10));
		
		if (aAlterMsg && !Array.isArray(aAlterMsg)) aAlterMsg = [aAlterMsg];
		if (aAlterMsg instanceof Array)
		{
			sMsg = Util.format(sMsg, aAlterMsg);
		}			
		return sMsg;
	}
	
	Util.format = function(sMsg, aAlterStr, oCfg)
	{
		var sMatchWord, nAlterMsgPos;
		for (var i=0, nLen=aAlterStr.length; i<nLen; i++)
		{
			sMatchWord = oCfg && oCfg.matchchar ? oCfg.matchchar : "{" + i + "}";
			nAlterMsgPos = String(sMsg).indexOf(sMatchWord);
			if (nAlterMsgPos >= 0)
			{
				sMsg = sMsg.replace(sMatchWord, aAlterStr[i]);
			}
			else
			{
				Util.trace("Util.xjs :: format() => format exception [not match] : " + sMatchWord);
			}
		}			
		return sMsg;
	}
	
	/**
	 * 브라우저의 local storage 이용하는 key값에 해당하는 값을 반환하는 함수
	 * @param {String} key	키값 (필수)
	 * @return {String} 저장내용
	 * @example Util.getPrivateProfile("key1");
	 * @memberOf Util
	 */
	Util.getPrivateProfile = function(sKey)
	{
		return NX.getApp().getPrivateProfile(sKey);
	}
	
	/**
	 * 브라우저의 local storage에 key값에 해당하는 값을 저장하는 함수
	 * @param {String} key	키값 (필수)
	 * @param {String} value	저장할값- primitive value(integer, boolean, string, float) 와 Date, nexacro.Date 만 지원(필수)
	 * @return {Boolean}  성공여부
	 * @example Util.setPrivateProfile("key1", "value1");
	 * @memberOf Util
	 */
	Util.setPrivateProfile = function(sKey, sValue)
	{
		return NX.getApp().setPrivateProfile(sKey, sValue);
	}
		
	/**
	 * 개발자용 저장공간 초기화
	 * @param {String} sKey 키값
	 * @param {String} sValue 키값
	 * @return {Boolean}  성공여부
	 * @example Util.setProfile("key1", "value1");
	 * @memberOf Util
	 */
	Util.clearProfile = function()
	{
		return NX.getApp().gdsProfile.clearData();
	}
	
	/**
	 * JSON을 문자열로 파싱하며, 파싱된 값을 추가로 변환하기도 하는 함수
	 * @param {String} text JSON으로 파싱할 문자열
	 * @param {Object} replacer 함수가 올 경우, 리턴되기 전에 파싱된 문자열 값이 어떻게 변환될 것인지를 결정함
	 * @return {Object} 주어진 JSON 텍스트에 따라 Object를 리턴함
	 * @example Util.decodeJson('[1, 5, "false"]');
	 * @memberOf Util
	 */
	Util.decodeJson = function(text, reviver)
	{
		return JSON.parse(text, reviver);
	}
	
	/**
	 * 값을 JSON 문자열로 변환
	 * @param {String} value JSON 문자열로 변환할 값
	 * @param {Object} replacer 문자열화 프로세스의 작동을 변경하는 함수 또는 whitelist 배열
	 * @param {Object} space 가독성을 목적으로 JSON 문자열 출력에 공백을 삽입하는데 사용되는 String 또는 Number 객체
	 * @return {String} 변환된 JSON문자열
	 * @example Util.encodeJson({x:5});
	 * @memberOf Util
	 */
	Util.encodeJson = function(value, replacer, space)
	{
		return JSON.stringify(value, replacer, space);
	}
	
	/**
	 * 대상문자열에 지정한 형태의 마스크문자열 반환 
	 * @param {String} sValue 대상문자열
	 * @param {String} sType 구분자형태
	 * @return {String}  mask속성문자열
	 * @example Util.getMaskStr("01032831640", "telno");
	 * @memberOf Util
	 */
	Util.getMaskStr = function(sValue, sType)
	{
		var sMask = "";
		
		switch (String(sType).toLowerCase())
 		{
		
 			case "telno" : 
 			case "celno" : 
 				var sText = Util.trim(sValue).replace(/[-_]/g, "");
				if (sText.length == 8)
				{
					if(sText.indexOf("*") > -1)
					{					
					    sMask = "####-@@@@";
					}
					else
				    {
					    sMask = "####-####";
				    }
				}
				else if (sText.length > 8)
				{
					var sPrefixTxt = sText.substr(0,3);
					if (Util._areaCode.contains(sPrefixTxt) || sPrefixTxt.indexOf("02") == 0)
					{
						/*	지역번호 (02, 0NX)
							서울지역 : 02-NXXX-XXXX (10자리)
							기타지역 : 0NX-NXX-XXXX (N=2~9, X=0~9, 10자리)
			 			 */
						if (sPrefixTxt.substr(0,2) == "02")
						{
							if(sText.indexOf("*") > -1)
							{							
								if(sText.length == 9)
								{
									sMask = "##-@@@-####";
								}
								else
								{
									sMask = "##-@@@@-####";
								}
							}
							else
							{
								if(sText.length == 9)
								{
									sMask = "##-###-####";
								}
								else
								{
									sMask = "##-####-####";
								}								
							}
						}
						else
						{
							if(sText.indexOf("*") > -1)
							{
								if(sText.length == 10)
								{
									sMask = "###-@@@-####";
								}
								else
								{
									sMask = "###-@@@@-####";
								}									
							}
							else
							{
								if(sText.length == 10)
								{
									sMask = "###-###-####";
								}
								else
								{
									sMask = "###-####-####";
								}									
							}
						
						}
					}
					else if (Util._cellCode.contains(sPrefixTxt))
					{
						/*	핸드폰
						010 : 010-XXXX-XXXX (10자리)
						011,016,017,018,019 : 01X-XXX-XXXX, 01X-XXXX-XXXX
						 */
						if(sText.indexOf("*") > -1)
						{						
							if (sText.length == 10)
							{
								sMask = "###-@@@-####";
							}
							else
							{
								sMask = "###-@@@@-####";
							}
						}
						else
						{
							if (sText.length == 10)
							{
								sMask = "###-###-####";
							}
							else
							{
								sMask = "###-####-####";
							}							
						}
					}
				}
				else
				{
					sMask = Util.rpad("", "#", sText.length);
				}
				break;
 		}
		
		return sMask;
	}
	
	// 메뉴URL에서 파일ID를 획득하는 함수
	Util._getFormId = function(sUrl)
	{
		var sFormId = "", nIdx = sUrl.indexOf(NX.FORM_URL_DELIM);
		if (nIdx >= 0)
		{
			sFormId = sUrl.substring(nIdx + NX.FORM_URL_DELIM.length, sUrl.indexOf(NX.FORM_EXTENSION))
		}
		else
		{
			sFormId = sUrl;
		}
		
		return sFormId;
	}
	
	// 넥사크로 오브젝트 id값을 반환하는 함수
	Util.getHolderId = function(obj)
	{
		var sId = "";
		try
		{
			var oHolder = obj.getElement()._dest_handle.firstElementChild || obj.getElement()._dest_handle.firstChild;
			var oChildHolder = oHolder.firstElementChild || oHolder.firstChild;
			sId = oChildHolder.id;
		}
		catch(e)
		{
			Util.trace("Util.getHolderId Exception : " + e.message);
		}
		return sId;
	}
	
	Util.getChartData = function(oDs)
	{
		var oItem, sColId, sColVal, aChartStr = [];
		oDs.set_enableevent(false);
		for (var i=0, nCnt=oDs.rowcount; i<nCnt; i++)
		{
			oItem = {};
			for (var j=0, nColCnt=oDs.colcount; j<nColCnt; j++)
			{
				sColId = oDs.getColID(j); 
				oItem[sColId] = oDs.getColumn(i, sColId);
			}
			aChartStr.push(oItem);
		}
		oDs.set_enableevent(true);
		return aChartStr;
	}
	
	
	/**
	 * 사용자 정보 반환
	 * @param {String} sInfo	조회할 정보컬럼
	 * @return {String} 결과값 
	 * @example Util.getUserInfo("scrnRghCd");
	 */
	Util.getUserInfo = function(sColNm)
	{
		var oDs = NX.getApp().gdsUserInfo;
		switch (Util.trim(sColNm))
		{
			case "clsfCd" 	: return Util.trim(oDs.getColumn(0, "clsfCd")); 	break; 	// 
			case "cttpc" 	: return Util.trim(oDs.getColumn(0, "cttpc")); 		break;
			case "deptNm" 	: return Util.trim(oDs.getColumn(0, "deptNm")); 	break;
			case "dtyCd" 	: return Util.trim(oDs.getColumn(0, "dtyCd")); 		break; 	// 
			case "empNo" 	: return Util.trim(oDs.getColumn(0, "empNo")); 		break;	// 
			case "empTyCd" 	: return Util.trim(oDs.getColumn(0, "empTyCd")); 	break;  // 
			case "hffcYn" 	: return Util.trim(oDs.getColumn(0, "hffcYn"));		break;	// 
			case "useYn" 	: return Util.trim(oDs.getColumn(0, "useYn"));		break; 	// 
			case "usrId" 	: return Util.trim(oDs.getColumn(0, "usrId"));		break;	// 
			case "usrNm" 	: return Util.trim(oDs.getColumn(0, "usrNm"));		break; 	// 
			default : 
				if (oDs.getColumnInfo(sColNm))
				{
					return Util.trim(oDs.getColumn(0, sColNm));
				}
				else
				{
					Util.trace("Util.xjs :: getUserInfo() => 존재하지 않는 사용자정보[" + sColNm +"]입니다.");
				}
				break;
		}
	}
	
//	/**
//	 * JSON string으로 반환되는 서비스Message를 객체로 반환
//	 * @param  {String} sMsg 메시지
//	 * @param  {String} sProp 메시지객체의 속성
//	 * @return {Object}
//	 * @example Util.getSvcMsg("XXX")
//	 */
//	Util.getSvcMsg = function(sMsg, sProp)
//	{
//		return sProp ? Util.decodeJson(sMsg).sProp : Util.decodeJson(sMsg);
//	},
	
	/**
	 * Calendar컴포넌트의 value속성에서 yyyyMM값을 반환
	 * @param  {Calendar} oCal 메시지
	 * @return {String}
	 * @example Util.getMonthForCal(this.calFrom)
	 */
	Util.getMonthForCal = function(oCal)
	{
		return NX.Analyzer._typeof(this.calMonth) ? Util.trim(oCal.value).substring(0, 6) : "";
	},

	//String prototype Redefinition ------------------------------------

	
	Util.copyProperties = function(tarobject, srcobject)
	{
		if (tarobject && srcobject) 
		{
			var p, value;
			
			for (p in srcobject)
			{
				if (srcobject.hasOwnProperty(p))
				{
					value = srcobject[p];
					tarobject[p] = value;
				}
			}
		}
	},
		
	Util.objEach = function(object, func, scope)
	{
		var p,
			scope = scope || object;
		for (p in object)
		{
			if (object.hasOwnProperty(p))
			{
				if (func.call(scope, p, object[p], object) === false)
				{
					return;
				}
			}
		}
	},	
	
	/**
	* Dataset의 필터한 정보를 대상 Dataset으로 Copy하는 기능
	* @param {object} 목적데이타셋dsDs(DataSet)
	* @param {string} 처리데이타셋
	* @param {string} 필터표현
	* @return N/A
	* @memberOf comUtil
	*/   
	Util.dsFilter = function(dsSc,dsTg,sFilterExpr)
	{
		var sKeyString = dsSc.keystring;
		if(!Util.isNull(sKeyString))  sKeyString = sKeyString.toString();
		dsSc.set_keystring("");
		dsSc.filter(sFilterExpr);
		dsTg.copyData(dsSc,true);
		dsSc.filter("");   
		if(!Util.isNull(sKeyString))  dsSc.set_keystring(sKeyString);
	},	
	
	/**
	 * 문자열 좌측에서 치환대상 문자열 제거
	 * @param {String} sTrim	치환대상 문자열(default:" ")
	 * @return {String} 결과값
	 * @example String.ltrim()
	 */
	String.prototype.ltrim = function(sTrim){
		return Util.ltrim(this, sTrim);
	}

	/**
	 * 문자열 우측에서 치환대상 문자열 제거
	 * @param {String} sTrim	치환대상 문자열(default:" ")
	 * @return {String} 결과값
	 * @example String.rtrim()
	 */
	String.prototype.rtrim = function(sTrim){
		return Util.rtrim(this, sTrim);
	}

	/**
	 * 문자열 좌/우측에서 치환대상 문자열 제거
	 * @param {String} sTrim	치환대상 문자열(default:" ")
	 * @return {String} 결과값
	 * @example String.trim()
	 */
// 	String.prototype.trim = function(sTrim){
// 		return Util.trim(this, sTrim);
// 	}

	/**
	 * 문자열을 지정된 길이만큼 좌측부터 채우는 함수
	 * @param {String} sPadChar	왼쪽에 채울 문자(default=" ")
	 * @param {String} nLen 		출력될 문자열의 길이
	 * @return {String} 결과값
	 * @example String.lpad("0", 3)
	 */
	String.prototype.lpad = function(sPadChar, nLen){
		return Util.lpad(this, sPadChar, nLen);
	}

	/**
	 * 문자열을 지정된 길이만큼 우측부터 채우는 함수
	 * @param {String} sPadChar	오른쪽에 채울 문자
	 * @param {Number} nLen			출력될 문자열의 길이
	 * @return {String} 결과값 
	 * @example String.rpad("0", 2);
	 */
	String.prototype.rpad = function(sPadChar, nLen){
		return Util.rpad(this, sPadChar, nLen);
	}

	// 문자열을 왼쪽에서 지정한 길이만큼 가져오기
	String.prototype.left = function(nLen){
		if (this.length < nLen)
			return this;
		else
			return this.substr(0, nLen);
	}

	/**
	 * 문자열의 오른쪽 부분을 지정한 길이만큼 가져오는 함수
	 * @param {String} nLen	얻어올 크기
	 * @return {String} 결과값
	 * @example String.right(2);
	 */
	String.prototype.right = function(nLen){
		return Util.right(this, nLen);
	}

	/**
	 * 현재 로케일을 사용하여 문자열로 변환된 숫자를 반환하는 Method 입니다.
	 * @return {String} true일경우 변환후 반환, false이면 그대로 반환
	 * @example String.numFormat();
	 */
	String.prototype.numFormat = function() {
		if (nexacro.isNumeric(this))
			return Number(this).toLocaleString();
		else
			return this;
	}

	/**
	 * 문자열의 byte수를 반환하는 함수
	 * @return {Number} 문자열의byte수
	 * @example String.getByte();
	 */
	String.prototype.getByte = function()
	{
		for (var b=i=0; c=this.charCodeAt(i++); b+=c>>11?3:c>>7?2:1)	return b;	// for performance
//		return this.replace(/[\0-\x7f]|([0-u07ff]|(.))/g, "$&$1$2").length;
	}


// 	String.prototype.localeCompareForIE = function(right, idx)
// 	{ 
// 		idx = (idx == undefined) ? 0 : idx++;
// 
// 		var run = right.length <= this.length ? (idx < right.length ? true : false) : (idx < this.length ? true : false); 
// 
// 		if (!run) return this[0].localeCompare(right[0]); 
// 
// 		if (this.localeCompare(right) != this[0].localeCompare(right[0])) 
// 		{
// 			var myLeft = this.slice(1, this.length); 
// 			var myRight = right.slice(1, right.length); 
// 			if (myLeft.localeCompare(myRight) != myLeft[0].localeCompare(myRight[0])) 
// 			{ 
// 				return myLeft.localeCompareForIE(myRight, idx); 
// 			} 
// 			else 
// 			{ 
// 				if (this[0].localeCompare(right[0]) == 0) 
// 				{ 
// 					return myLeft.localeCompareForIE(myRight, idx); 
// 				} 
// 				else 
// 				{ 
// 					return this[0].localeCompare(right[0]) 
// 				} 
// 			} 
// 		} 
// 		else 
// 		{ 
// 			return this.localeCompare(right); 
// 		}
// 	}

	/**
	 * from index부터 검색대상 요소의 index를 가져오는 함수
	 * @param {Object} elt	검색대상 요소
	 * @param {String} fromIndex	검색을 시작할 인덱스
	 * @return {String} 결과값
	 * @example Array.indexOf("ab", 0);
	 */
	Array.prototype.indexOf = function(elt , nFromIndex)
	{
		var len = this.length;
		var nFromIndex = Number(arguments[1]) || 0;
			nFromIndex = (nFromIndex < 0) ? Math.ceil(nFromIndex) : Math.floor(nFromIndex);
		if (nFromIndex < 0) nFromIndex += len;

		for (; nFromIndex < len; nFromIndex++)
		{
		  if (nFromIndex in this && this[nFromIndex] === elt) return nFromIndex;
		}
		return -1;
	}

	/**
	 * 마지막index부터 좌측으로 검색대상 요소의 index를 가져오는 함수
	 * @param {Object} elt	검색대상 요소
	 * @param {String} fromIndex	검색을 시작할 인덱스
	 * @return {String} 결과값
	 * @example Array.lastIndexOf("ab", 0);
	 */
	Array.prototype.lastIndexOf = function(elt,nFromIndex)
	{
		if (nFromIndex == null)
		{
			nFromIndex = this.length-1;
		}
		else if(nFromIndex < 0)
		{
			nFromIndex = Math.max(0,this.length+nFromIndex);
		}
		
		for (var i=nFromIndex; i>=0; i--)
		{
			if (this[i] === elt) return i;
		}
		return-1;
	}

	/**
	 * 검색대상 요소가 포함되어 있는지 체크하는 함수
	 * @param {Object} elt	검색대상 요소
	 * @return {Boolean} 결과값(trun/false) 
	 * @example Array.contains("ab");
	 */
	Array.prototype.contains = function(elt)
	{
		return this.indexOf(elt)!= -1;
	}

	/**
	 * 기존배열과 동일한 배열을 반환하는 함수
	 * @return {Array} 결과값 
	 * @example Array.clone(array);
	 */
	Array.prototype.clone = function()
	{
		return this.concat([]);
	}

	/**
	 * 배열의 특정index위치에 배열요소(elt)를 추가하는 함수
	 * @param {Object} elt	추가할 요소
	 * @param {Number} i	추가할 인덱스
	 * @example Array.insertAt("ab",2);
	 */
	Array.prototype.insertAt = function(elt,i)
	{
		this.splice(i,0,elt);
	}

	/**
	 * 배열의 특정index위치(elt2)에 배열요소(elt1)을 추가하는 함수
	 * @param {Object} elt	추가할 요소
	 * @param {Number} i	추가할 인덱스
	 * @example Array.insertAt("ab",2);
	 */
	Array.prototype.insertBefore = function(elt1,elt2)
	{
		var i = this.indexOf(elt2);
		if (i == -1)
			this.push(elt1);
		else 
			this.splice(i,0,elt1);
	}

	/**
	 * 배열에서 i번째 요소를 삭제하는 함수
	 * @param {Number} i	삭제할 인덱스
	 * @return {Boolean} 삭제된 배열 요소 
	 * @example Array.removeAt(2);
	 */
	Array.prototype.removeAt = function(nIdx)
	{
		return this.splice(nIdx,1);
	}

	/**
	 * 배열에서 아규먼트 요소를 삭제하는 함수
	 * @param {Object} elt	삭제할 요소
	 * @example Array.remove("ab");
	 */
	Array.prototype.remove = function(elt)
	{
		var i = this.indexOf(elt);
		if (i!= -1) this.splice(i,1);
	}

	/**
	 * 중복된 배열요소를 제거하고 반환하는 함수
	 * @return {Array} 결과값 
	 * @example Array.unique();
	 */
	Array.prototype.unique = function()
	{
		var retArr = this.concat([]);
		for (var i= retArr.length; --i>-1;)
		{
			for (var j= retArr.length; --j>-1; )
			{
				if (i != j && retArr[i] == retArr[j]) retArr.splice(i,1);
			}
		}
		return retArr;
	}

	/**
	 * 배열요소중 최대값을 반환하는 함수
	 * @return {Object} 결과값 
	 * @example Array.max();
	 */
	Array.prototype.max = function()
	{
		return Math.max.apply(Math, this);
	}

	/**
	 * 배열요소중 최소값을 반환하는 함수
	 * @return {Object} 결과값 
	 * @example Array.min();
	 */
	Array.prototype.min = function()
	{
		return Math.min.apply(Math, this);
	}

	/**
	 * 배열요소의 합계를 반환하는 함수
	 * @return {Object} 결과값 
	 * @example Array.sum();
	 */
	Array.prototype.sum = function()
	{
		for (var i=0,sum=0; i<this.length; sum+=this[i++]); return sum;
	}

		
	/**
	 * 배열요소에 대해서 for문을 수행(skip)
	 * @return {Object} N/A
	 * @example Array.forEach();
	 */
	Array.prototype.forEach = function(f, obj)
	{
		var l = this.length;
		for (var i=0; i<l; i++)
		{
			f.call(obj,this[i],i,this);
		}
	}

	/**
	 * 배열의 요소에대해서 필터처리
	 * @return {Object} 필터처리된 배열
	 * @example Array.filter();
	 */
	Array.prototype.filter = function(f, obj)
	{
		var l = this.length, res = [];
		for (var i=0;i<l;i++)
		{
			if (f.call(obj,this[i],i,this))
			{
				res.push(this[i]);
			}
		}
		return res;
	}

	/**
	 * 특정함수 처리후 결과를 배열로 return
	 * @return {Object} 배열
	 * @example Array.map();
	 */
	Array.prototype.map = function(f,obj)
	{
		var l = this.length, res = [];
		for (var i=0; i<l; i++)
		{
			res.push(f.call(obj,this[i],i,this));
		}
		return res;
	}

	/**
	 * 함수결과에 대한 결과리턴
	 * @return {Object} 결과값
	 * @example Array.some();
	 */
	Array.prototype.some = function(f,obj)
	{
		var l = this.length;
		for (var i=0; i<l; i++)
		{
			if (f.call(obj,this[i],i,this))
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * 함수결과에 대한 결과리턴
	 * @return {Object} 결과값
	 * @example Array.every();
	 */
	Array.prototype.every = function(f,obj)
	{
		var l = this.length;
		for (var i=0; i<l; i++)
		{
			if (!f.call(obj,this[i],i,this))
			{
				return false;
			}
		}
		return true;
	}
}



/**
 * @fileoverview DOM과 관련된 함수.
 */
if ( !JsNamespace.exist("DOM") )
{
	/**
	 * @namespace
	 * @name DOM
	 * @memberof! <global>
	 */
	JsNamespace.declare("DOM", {});
	

	/**
	 * DOM객체를 가져오는 메소드
	 * @param {object} obj WebBrowser컴포넌트
	 * @return {Object} Dom Object
	 * @example var oDom = DOM.getDocument(this.webbrowser);
	 */	
	DOM.getDocument = function(obj)
	{
		return NX.isruntime ? obj.getProperty("document") : obj.document;
	}
	
	/**
	 * DOM객체내에 ID에 해당되는 Element객체 반환
	 * @param {object} obj Dom객체
	 * @param {string} sId 찾을 Element객체 아이디
	 * @return {Object} Element객체
	 * @example var oInput = DOM.getDocument(oDom,"input_test");
	 */		
	DOM.getEleById = function(oDoc, sId)
	{
	  return oDoc.getElementById(sId);
	}
	
	/**
	 * Element객체에 값 셋팅
	 * @param {object} obj Dom객체
	 * @param {array} aData 객체아이디와 값을 셋팅 {id:객체아이디 , value:셋팅할값}
	 * @return N / A
	 * @example DOM.getDocument(oDom,{id:"input_test",value:"테스트");
	 */		
	DOM.setValue = function(obj, aData)
	{
		var oDoc, sId, sValue;
		if (NX.isruntime)
		{
			oDoc = obj.getProperty("document");
			if (oDoc)
			{
				for (var i=0,nCnt=aData.length; i<nCnt; i++)
				{
					sId 	= aData[i].id;
					sValue 	= aData[i].value;
					oDoc.callMethod("getElementById", sId).setProperty("value", sValue);
				}
			}
		}
		else
		{
			oDoc = obj.document;
			if (oDoc)
			{
				for (var i=0,nCnt=aData.length; i<nCnt; i++)
				{
					sId 	= aData[i].id;
					sValue 	= aData[i].value;
					oDoc.getElementById(sId).value	= sValue;
				}
			}
		}
		return oDoc;
	}	
}
